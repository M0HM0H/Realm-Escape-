gdjs.TutorialCode = {};
gdjs.TutorialCode.GDCharacterObjects4_1final = [];

gdjs.TutorialCode.GDNPC_95951Objects4_1final = [];

gdjs.TutorialCode.GDNPC_95952Objects4_1final = [];

gdjs.TutorialCode.forEachIndex5 = 0;

gdjs.TutorialCode.forEachObjects5 = [];

gdjs.TutorialCode.forEachTemporary5 = null;

gdjs.TutorialCode.forEachTotalCount5 = 0;

gdjs.TutorialCode.GDTutorial_95951Objects1= [];
gdjs.TutorialCode.GDTutorial_95951Objects2= [];
gdjs.TutorialCode.GDTutorial_95951Objects3= [];
gdjs.TutorialCode.GDTutorial_95951Objects4= [];
gdjs.TutorialCode.GDTutorial_95951Objects5= [];
gdjs.TutorialCode.GDTutorial_95951Objects6= [];
gdjs.TutorialCode.GDTutorial_95951Objects7= [];
gdjs.TutorialCode.GDTutorial_95953Objects1= [];
gdjs.TutorialCode.GDTutorial_95953Objects2= [];
gdjs.TutorialCode.GDTutorial_95953Objects3= [];
gdjs.TutorialCode.GDTutorial_95953Objects4= [];
gdjs.TutorialCode.GDTutorial_95953Objects5= [];
gdjs.TutorialCode.GDTutorial_95953Objects6= [];
gdjs.TutorialCode.GDTutorial_95953Objects7= [];
gdjs.TutorialCode.GDTutorial_95952Objects1= [];
gdjs.TutorialCode.GDTutorial_95952Objects2= [];
gdjs.TutorialCode.GDTutorial_95952Objects3= [];
gdjs.TutorialCode.GDTutorial_95952Objects4= [];
gdjs.TutorialCode.GDTutorial_95952Objects5= [];
gdjs.TutorialCode.GDTutorial_95952Objects6= [];
gdjs.TutorialCode.GDTutorial_95952Objects7= [];
gdjs.TutorialCode.GDGround_959501Objects1= [];
gdjs.TutorialCode.GDGround_959501Objects2= [];
gdjs.TutorialCode.GDGround_959501Objects3= [];
gdjs.TutorialCode.GDGround_959501Objects4= [];
gdjs.TutorialCode.GDGround_959501Objects5= [];
gdjs.TutorialCode.GDGround_959501Objects6= [];
gdjs.TutorialCode.GDGround_959501Objects7= [];
gdjs.TutorialCode.GDGround_959502Objects1= [];
gdjs.TutorialCode.GDGround_959502Objects2= [];
gdjs.TutorialCode.GDGround_959502Objects3= [];
gdjs.TutorialCode.GDGround_959502Objects4= [];
gdjs.TutorialCode.GDGround_959502Objects5= [];
gdjs.TutorialCode.GDGround_959502Objects6= [];
gdjs.TutorialCode.GDGround_959502Objects7= [];
gdjs.TutorialCode.GDGround_959503Objects1= [];
gdjs.TutorialCode.GDGround_959503Objects2= [];
gdjs.TutorialCode.GDGround_959503Objects3= [];
gdjs.TutorialCode.GDGround_959503Objects4= [];
gdjs.TutorialCode.GDGround_959503Objects5= [];
gdjs.TutorialCode.GDGround_959503Objects6= [];
gdjs.TutorialCode.GDGround_959503Objects7= [];
gdjs.TutorialCode.GDGround_959504Objects1= [];
gdjs.TutorialCode.GDGround_959504Objects2= [];
gdjs.TutorialCode.GDGround_959504Objects3= [];
gdjs.TutorialCode.GDGround_959504Objects4= [];
gdjs.TutorialCode.GDGround_959504Objects5= [];
gdjs.TutorialCode.GDGround_959504Objects6= [];
gdjs.TutorialCode.GDGround_959504Objects7= [];
gdjs.TutorialCode.GDGround_959505Objects1= [];
gdjs.TutorialCode.GDGround_959505Objects2= [];
gdjs.TutorialCode.GDGround_959505Objects3= [];
gdjs.TutorialCode.GDGround_959505Objects4= [];
gdjs.TutorialCode.GDGround_959505Objects5= [];
gdjs.TutorialCode.GDGround_959505Objects6= [];
gdjs.TutorialCode.GDGround_959505Objects7= [];
gdjs.TutorialCode.GDGround_959506Objects1= [];
gdjs.TutorialCode.GDGround_959506Objects2= [];
gdjs.TutorialCode.GDGround_959506Objects3= [];
gdjs.TutorialCode.GDGround_959506Objects4= [];
gdjs.TutorialCode.GDGround_959506Objects5= [];
gdjs.TutorialCode.GDGround_959506Objects6= [];
gdjs.TutorialCode.GDGround_959506Objects7= [];
gdjs.TutorialCode.GDGround_959507Objects1= [];
gdjs.TutorialCode.GDGround_959507Objects2= [];
gdjs.TutorialCode.GDGround_959507Objects3= [];
gdjs.TutorialCode.GDGround_959507Objects4= [];
gdjs.TutorialCode.GDGround_959507Objects5= [];
gdjs.TutorialCode.GDGround_959507Objects6= [];
gdjs.TutorialCode.GDGround_959507Objects7= [];
gdjs.TutorialCode.GDGround_959508Objects1= [];
gdjs.TutorialCode.GDGround_959508Objects2= [];
gdjs.TutorialCode.GDGround_959508Objects3= [];
gdjs.TutorialCode.GDGround_959508Objects4= [];
gdjs.TutorialCode.GDGround_959508Objects5= [];
gdjs.TutorialCode.GDGround_959508Objects6= [];
gdjs.TutorialCode.GDGround_959508Objects7= [];
gdjs.TutorialCode.GDGround_959509Objects1= [];
gdjs.TutorialCode.GDGround_959509Objects2= [];
gdjs.TutorialCode.GDGround_959509Objects3= [];
gdjs.TutorialCode.GDGround_959509Objects4= [];
gdjs.TutorialCode.GDGround_959509Objects5= [];
gdjs.TutorialCode.GDGround_959509Objects6= [];
gdjs.TutorialCode.GDGround_959509Objects7= [];
gdjs.TutorialCode.GDGood_9595WinObjects1= [];
gdjs.TutorialCode.GDGood_9595WinObjects2= [];
gdjs.TutorialCode.GDGood_9595WinObjects3= [];
gdjs.TutorialCode.GDGood_9595WinObjects4= [];
gdjs.TutorialCode.GDGood_9595WinObjects5= [];
gdjs.TutorialCode.GDGood_9595WinObjects6= [];
gdjs.TutorialCode.GDGood_9595WinObjects7= [];
gdjs.TutorialCode.GDVoidObjects1= [];
gdjs.TutorialCode.GDVoidObjects2= [];
gdjs.TutorialCode.GDVoidObjects3= [];
gdjs.TutorialCode.GDVoidObjects4= [];
gdjs.TutorialCode.GDVoidObjects5= [];
gdjs.TutorialCode.GDVoidObjects6= [];
gdjs.TutorialCode.GDVoidObjects7= [];
gdjs.TutorialCode.GDGood_9595GateObjects1= [];
gdjs.TutorialCode.GDGood_9595GateObjects2= [];
gdjs.TutorialCode.GDGood_9595GateObjects3= [];
gdjs.TutorialCode.GDGood_9595GateObjects4= [];
gdjs.TutorialCode.GDGood_9595GateObjects5= [];
gdjs.TutorialCode.GDGood_9595GateObjects6= [];
gdjs.TutorialCode.GDGood_9595GateObjects7= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects1= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects2= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects3= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects4= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects5= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects6= [];
gdjs.TutorialCode.GDMove_9595TriggerObjects7= [];
gdjs.TutorialCode.GDCharacterObjects1= [];
gdjs.TutorialCode.GDCharacterObjects2= [];
gdjs.TutorialCode.GDCharacterObjects3= [];
gdjs.TutorialCode.GDCharacterObjects4= [];
gdjs.TutorialCode.GDCharacterObjects5= [];
gdjs.TutorialCode.GDCharacterObjects6= [];
gdjs.TutorialCode.GDCharacterObjects7= [];
gdjs.TutorialCode.GDMove_9595CardObjects1= [];
gdjs.TutorialCode.GDMove_9595CardObjects2= [];
gdjs.TutorialCode.GDMove_9595CardObjects3= [];
gdjs.TutorialCode.GDMove_9595CardObjects4= [];
gdjs.TutorialCode.GDMove_9595CardObjects5= [];
gdjs.TutorialCode.GDMove_9595CardObjects6= [];
gdjs.TutorialCode.GDMove_9595CardObjects7= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects1= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects2= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects3= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects4= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects5= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects6= [];
gdjs.TutorialCode.GDAmount_9595MoveObjects7= [];
gdjs.TutorialCode.GDMoveObjects1= [];
gdjs.TutorialCode.GDMoveObjects2= [];
gdjs.TutorialCode.GDMoveObjects3= [];
gdjs.TutorialCode.GDMoveObjects4= [];
gdjs.TutorialCode.GDMoveObjects5= [];
gdjs.TutorialCode.GDMoveObjects6= [];
gdjs.TutorialCode.GDMoveObjects7= [];
gdjs.TutorialCode.GDSword_9595CardObjects1= [];
gdjs.TutorialCode.GDSword_9595CardObjects2= [];
gdjs.TutorialCode.GDSword_9595CardObjects3= [];
gdjs.TutorialCode.GDSword_9595CardObjects4= [];
gdjs.TutorialCode.GDSword_9595CardObjects5= [];
gdjs.TutorialCode.GDSword_9595CardObjects6= [];
gdjs.TutorialCode.GDSword_9595CardObjects7= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects1= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects2= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects3= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects4= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects5= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects6= [];
gdjs.TutorialCode.GDAmount_9595SwordObjects7= [];
gdjs.TutorialCode.GDSwordObjects1= [];
gdjs.TutorialCode.GDSwordObjects2= [];
gdjs.TutorialCode.GDSwordObjects3= [];
gdjs.TutorialCode.GDSwordObjects4= [];
gdjs.TutorialCode.GDSwordObjects5= [];
gdjs.TutorialCode.GDSwordObjects6= [];
gdjs.TutorialCode.GDSwordObjects7= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects1= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects2= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects3= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects4= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects5= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects6= [];
gdjs.TutorialCode.GDTeleport_9595CardObjects7= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects1= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects2= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects3= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects4= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects5= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects6= [];
gdjs.TutorialCode.GDAmount_9595TeleportObjects7= [];
gdjs.TutorialCode.GDTeleportObjects1= [];
gdjs.TutorialCode.GDTeleportObjects2= [];
gdjs.TutorialCode.GDTeleportObjects3= [];
gdjs.TutorialCode.GDTeleportObjects4= [];
gdjs.TutorialCode.GDTeleportObjects5= [];
gdjs.TutorialCode.GDTeleportObjects6= [];
gdjs.TutorialCode.GDTeleportObjects7= [];
gdjs.TutorialCode.GDCurserObjects1= [];
gdjs.TutorialCode.GDCurserObjects2= [];
gdjs.TutorialCode.GDCurserObjects3= [];
gdjs.TutorialCode.GDCurserObjects4= [];
gdjs.TutorialCode.GDCurserObjects5= [];
gdjs.TutorialCode.GDCurserObjects6= [];
gdjs.TutorialCode.GDCurserObjects7= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects1= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects2= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects3= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects4= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects5= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects6= [];
gdjs.TutorialCode.GDFade_9595ScreenObjects7= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects1= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects2= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects3= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects4= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects5= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects6= [];
gdjs.TutorialCode.GDSlash_9595EffectObjects7= [];
gdjs.TutorialCode.GDBackgroundObjects1= [];
gdjs.TutorialCode.GDBackgroundObjects2= [];
gdjs.TutorialCode.GDBackgroundObjects3= [];
gdjs.TutorialCode.GDBackgroundObjects4= [];
gdjs.TutorialCode.GDBackgroundObjects5= [];
gdjs.TutorialCode.GDBackgroundObjects6= [];
gdjs.TutorialCode.GDBackgroundObjects7= [];
gdjs.TutorialCode.GDMonsterObjects1= [];
gdjs.TutorialCode.GDMonsterObjects2= [];
gdjs.TutorialCode.GDMonsterObjects3= [];
gdjs.TutorialCode.GDMonsterObjects4= [];
gdjs.TutorialCode.GDMonsterObjects5= [];
gdjs.TutorialCode.GDMonsterObjects6= [];
gdjs.TutorialCode.GDMonsterObjects7= [];
gdjs.TutorialCode.GDPadObjects1= [];
gdjs.TutorialCode.GDPadObjects2= [];
gdjs.TutorialCode.GDPadObjects3= [];
gdjs.TutorialCode.GDPadObjects4= [];
gdjs.TutorialCode.GDPadObjects5= [];
gdjs.TutorialCode.GDPadObjects6= [];
gdjs.TutorialCode.GDPadObjects7= [];
gdjs.TutorialCode.GDUI_9595TextObjects1= [];
gdjs.TutorialCode.GDUI_9595TextObjects2= [];
gdjs.TutorialCode.GDUI_9595TextObjects3= [];
gdjs.TutorialCode.GDUI_9595TextObjects4= [];
gdjs.TutorialCode.GDUI_9595TextObjects5= [];
gdjs.TutorialCode.GDUI_9595TextObjects6= [];
gdjs.TutorialCode.GDUI_9595TextObjects7= [];
gdjs.TutorialCode.GDDebugObjects1= [];
gdjs.TutorialCode.GDDebugObjects2= [];
gdjs.TutorialCode.GDDebugObjects3= [];
gdjs.TutorialCode.GDDebugObjects4= [];
gdjs.TutorialCode.GDDebugObjects5= [];
gdjs.TutorialCode.GDDebugObjects6= [];
gdjs.TutorialCode.GDDebugObjects7= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects1= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects3= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects6= [];
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects7= [];
gdjs.TutorialCode.GDRenderObjects1= [];
gdjs.TutorialCode.GDRenderObjects2= [];
gdjs.TutorialCode.GDRenderObjects3= [];
gdjs.TutorialCode.GDRenderObjects4= [];
gdjs.TutorialCode.GDRenderObjects5= [];
gdjs.TutorialCode.GDRenderObjects6= [];
gdjs.TutorialCode.GDRenderObjects7= [];
gdjs.TutorialCode.GDReset_9595buttonObjects1= [];
gdjs.TutorialCode.GDReset_9595buttonObjects2= [];
gdjs.TutorialCode.GDReset_9595buttonObjects3= [];
gdjs.TutorialCode.GDReset_9595buttonObjects4= [];
gdjs.TutorialCode.GDReset_9595buttonObjects5= [];
gdjs.TutorialCode.GDReset_9595buttonObjects6= [];
gdjs.TutorialCode.GDReset_9595buttonObjects7= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects1= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects2= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects3= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects4= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects5= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects6= [];
gdjs.TutorialCode.GDUI_9595Text_95952Objects7= [];
gdjs.TutorialCode.GDRight_9595ClickObjects1= [];
gdjs.TutorialCode.GDRight_9595ClickObjects2= [];
gdjs.TutorialCode.GDRight_9595ClickObjects3= [];
gdjs.TutorialCode.GDRight_9595ClickObjects4= [];
gdjs.TutorialCode.GDRight_9595ClickObjects5= [];
gdjs.TutorialCode.GDRight_9595ClickObjects6= [];
gdjs.TutorialCode.GDRight_9595ClickObjects7= [];
gdjs.TutorialCode.GDGround_959510Objects1= [];
gdjs.TutorialCode.GDGround_959510Objects2= [];
gdjs.TutorialCode.GDGround_959510Objects3= [];
gdjs.TutorialCode.GDGround_959510Objects4= [];
gdjs.TutorialCode.GDGround_959510Objects5= [];
gdjs.TutorialCode.GDGround_959510Objects6= [];
gdjs.TutorialCode.GDGround_959510Objects7= [];
gdjs.TutorialCode.GDGround_959511Objects1= [];
gdjs.TutorialCode.GDGround_959511Objects2= [];
gdjs.TutorialCode.GDGround_959511Objects3= [];
gdjs.TutorialCode.GDGround_959511Objects4= [];
gdjs.TutorialCode.GDGround_959511Objects5= [];
gdjs.TutorialCode.GDGround_959511Objects6= [];
gdjs.TutorialCode.GDGround_959511Objects7= [];
gdjs.TutorialCode.GDSwap_9595CardObjects1= [];
gdjs.TutorialCode.GDSwap_9595CardObjects2= [];
gdjs.TutorialCode.GDSwap_9595CardObjects3= [];
gdjs.TutorialCode.GDSwap_9595CardObjects4= [];
gdjs.TutorialCode.GDSwap_9595CardObjects5= [];
gdjs.TutorialCode.GDSwap_9595CardObjects6= [];
gdjs.TutorialCode.GDSwap_9595CardObjects7= [];
gdjs.TutorialCode.GDBomb_9595CardObjects1= [];
gdjs.TutorialCode.GDBomb_9595CardObjects2= [];
gdjs.TutorialCode.GDBomb_9595CardObjects3= [];
gdjs.TutorialCode.GDBomb_9595CardObjects4= [];
gdjs.TutorialCode.GDBomb_9595CardObjects5= [];
gdjs.TutorialCode.GDBomb_9595CardObjects6= [];
gdjs.TutorialCode.GDBomb_9595CardObjects7= [];
gdjs.TutorialCode.GDNPC_95951Objects1= [];
gdjs.TutorialCode.GDNPC_95951Objects2= [];
gdjs.TutorialCode.GDNPC_95951Objects3= [];
gdjs.TutorialCode.GDNPC_95951Objects4= [];
gdjs.TutorialCode.GDNPC_95951Objects5= [];
gdjs.TutorialCode.GDNPC_95951Objects6= [];
gdjs.TutorialCode.GDNPC_95951Objects7= [];
gdjs.TutorialCode.GDBad_9595WinObjects1= [];
gdjs.TutorialCode.GDBad_9595WinObjects2= [];
gdjs.TutorialCode.GDBad_9595WinObjects3= [];
gdjs.TutorialCode.GDBad_9595WinObjects4= [];
gdjs.TutorialCode.GDBad_9595WinObjects5= [];
gdjs.TutorialCode.GDBad_9595WinObjects6= [];
gdjs.TutorialCode.GDBad_9595WinObjects7= [];
gdjs.TutorialCode.GDBad_9595GateObjects1= [];
gdjs.TutorialCode.GDBad_9595GateObjects2= [];
gdjs.TutorialCode.GDBad_9595GateObjects3= [];
gdjs.TutorialCode.GDBad_9595GateObjects4= [];
gdjs.TutorialCode.GDBad_9595GateObjects5= [];
gdjs.TutorialCode.GDBad_9595GateObjects6= [];
gdjs.TutorialCode.GDBad_9595GateObjects7= [];
gdjs.TutorialCode.GDWeight_9595PadObjects1= [];
gdjs.TutorialCode.GDWeight_9595PadObjects2= [];
gdjs.TutorialCode.GDWeight_9595PadObjects3= [];
gdjs.TutorialCode.GDWeight_9595PadObjects4= [];
gdjs.TutorialCode.GDWeight_9595PadObjects5= [];
gdjs.TutorialCode.GDWeight_9595PadObjects6= [];
gdjs.TutorialCode.GDWeight_9595PadObjects7= [];
gdjs.TutorialCode.GDNPC_95952Objects1= [];
gdjs.TutorialCode.GDNPC_95952Objects2= [];
gdjs.TutorialCode.GDNPC_95952Objects3= [];
gdjs.TutorialCode.GDNPC_95952Objects4= [];
gdjs.TutorialCode.GDNPC_95952Objects5= [];
gdjs.TutorialCode.GDNPC_95952Objects6= [];
gdjs.TutorialCode.GDNPC_95952Objects7= [];
gdjs.TutorialCode.GDCard_9595UIObjects1= [];
gdjs.TutorialCode.GDCard_9595UIObjects2= [];
gdjs.TutorialCode.GDCard_9595UIObjects3= [];
gdjs.TutorialCode.GDCard_9595UIObjects4= [];
gdjs.TutorialCode.GDCard_9595UIObjects5= [];
gdjs.TutorialCode.GDCard_9595UIObjects6= [];
gdjs.TutorialCode.GDCard_9595UIObjects7= [];
gdjs.TutorialCode.GDSmokeObjects1= [];
gdjs.TutorialCode.GDSmokeObjects2= [];
gdjs.TutorialCode.GDSmokeObjects3= [];
gdjs.TutorialCode.GDSmokeObjects4= [];
gdjs.TutorialCode.GDSmokeObjects5= [];
gdjs.TutorialCode.GDSmokeObjects6= [];
gdjs.TutorialCode.GDSmokeObjects7= [];


gdjs.TutorialCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17629196);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Looped Ambince sound.mp3", 1, true, 10, 1);
}}

}


};gdjs.TutorialCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Tutorial";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9174020);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Ambient - Dream World.mp3", 1, true, 25, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.TutorialCode.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.TutorialCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].activateBehavior("SmoothCamera", true);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].setPosition((( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getPointX("Point_Fix")) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getPointX("Point_Fix")) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getPointX("Point_Fix")),(( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getPointY("Point_Fix")) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getPointY("Point_Fix")) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getPointY("Point_Fix")));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].activateBehavior("SmoothCamera", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.TutorialCode.GDVoidObjects5);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.TutorialCode.GDWeight_9595PadObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects5[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDWeight_9595PadObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDWeight_9595PadObjects5[i].getBehavior("Scale").setScale(0.8);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Scale").setScale(0.9);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDVoidObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDVoidObjects5[i].rotate(10, runtimeScene);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDVoidObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDVoidObjects5[i].getBehavior("Scale").setScale(0.9);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Reset_button"), gdjs.TutorialCode.GDReset_9595buttonObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.TutorialCode.GDVoidObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDReset_9595buttonObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDReset_9595buttonObjects5[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDVoidObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDVoidObjects5[i].getBehavior("Opacity").setOpacity(180);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bad_Win"), gdjs.TutorialCode.GDBad_9595WinObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.TutorialCode.GDGood_9595WinObjects5);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.TutorialCode.GDGood_9595WinObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGood_9595WinObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDBad_9595WinObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBad_9595WinObjects5[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.TutorialCode.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.TutorialCode.GDMoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Smoke"), gdjs.TutorialCode.GDSmokeObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects5[i].setZOrder(9999);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].setZOrder(999);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].setZOrder(999);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].setZOrder(999);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSmokeObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSmokeObjects5[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMoveObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].setZOrder(99999);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects5[i].setZOrder(999999);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.TutorialCode.GDMoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects5[i].setPosition((( gdjs.TutorialCode.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMoveObjects5[i].setPosition((( gdjs.TutorialCode.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects5[i].setPosition((( gdjs.TutorialCode.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDBomb_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.TutorialCode.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.TutorialCode.GDMoveObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDMoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMoveObjects5[i].setPosition((( gdjs.TutorialCode.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDBomb_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDBomb_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects5[i].setPosition((( gdjs.TutorialCode.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDBomb_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDBomb_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects5[i].setPosition((( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].setPosition((( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects5[i].setPosition((( gdjs.TutorialCode.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSwap_9595CardObjects5[0].getPointX("Contact")),(( gdjs.TutorialCode.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSwap_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].setPosition((( gdjs.TutorialCode.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSwap_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSwap_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDBomb_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.TutorialCode.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects5[i].setPosition((( gdjs.TutorialCode.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects5[i].getBehavior("Text").setText(((gdjs.TutorialCode.GDMove_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TutorialCode.GDMove_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].setPosition((( gdjs.TutorialCode.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].getBehavior("Text").setText(((gdjs.TutorialCode.GDSword_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TutorialCode.GDSword_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].setPosition((( gdjs.TutorialCode.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects5[0].getPointX("Amount")),(( gdjs.TutorialCode.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].getBehavior("Text").setText(((gdjs.TutorialCode.GDTeleport_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.TutorialCode.GDTeleport_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects4);
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDMove_9595CardObjects4[i].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDMove_9595CardObjects4[i].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.TutorialCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.TutorialCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595CardObjects4[0].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDSword_9595CardObjects4[i].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDSword_9595CardObjects4[i].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.TutorialCode.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.TutorialCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.TutorialCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects4[0].getCenterYInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDBomb_95959595CardObjects5Objects = Hashtable.newFrom({"Move_Card": gdjs.TutorialCode.GDMove_9595CardObjects5, "Sword_Card": gdjs.TutorialCode.GDSword_9595CardObjects5, "Teleport_Card": gdjs.TutorialCode.GDTeleport_9595CardObjects5, "TeleportBlade_Card": gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5, "Swap_Card": gdjs.TutorialCode.GDSwap_9595CardObjects5, "Bomb_Card": gdjs.TutorialCode.GDBomb_9595CardObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDBomb_95959595CardObjects5Objects = Hashtable.newFrom({"Move_Card": gdjs.TutorialCode.GDMove_9595CardObjects5, "Sword_Card": gdjs.TutorialCode.GDSword_9595CardObjects5, "Teleport_Card": gdjs.TutorialCode.GDTeleport_9595CardObjects5, "TeleportBlade_Card": gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5, "Swap_Card": gdjs.TutorialCode.GDSwap_9595CardObjects5, "Bomb_Card": gdjs.TutorialCode.GDBomb_9595CardObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546TutorialCode_9546GDVoidObjects5ObjectsGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546TutorialCode_9546GDPadObjects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546TutorialCode_9546GDBad_95959595GateObjects5Objects = Hashtable.newFrom({"Ground_01": gdjs.TutorialCode.GDGround_959501Objects5, "Ground_02": gdjs.TutorialCode.GDGround_959502Objects5, "Ground_03": gdjs.TutorialCode.GDGround_959503Objects5, "Ground_04": gdjs.TutorialCode.GDGround_959504Objects5, "Ground_05": gdjs.TutorialCode.GDGround_959505Objects5, "Ground_06": gdjs.TutorialCode.GDGround_959506Objects5, "Ground_07": gdjs.TutorialCode.GDGround_959507Objects5, "Ground_08": gdjs.TutorialCode.GDGround_959508Objects5, "Ground_09": gdjs.TutorialCode.GDGround_959509Objects5, "Good_Gate": gdjs.TutorialCode.GDGood_9595GateObjects5, "Void": gdjs.TutorialCode.GDVoidObjects5, "Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects5, "Pad": gdjs.TutorialCode.GDPadObjects5, "Ground_10": gdjs.TutorialCode.GDGround_959510Objects5, "Ground_11": gdjs.TutorialCode.GDGround_959511Objects5, "Bad_Gate": gdjs.TutorialCode.GDBad_9595GateObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546TutorialCode_9546GDVoidObjects5ObjectsGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546TutorialCode_9546GDPadObjects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546TutorialCode_9546GDBad_95959595GateObjects5Objects = Hashtable.newFrom({"Ground_01": gdjs.TutorialCode.GDGround_959501Objects5, "Ground_02": gdjs.TutorialCode.GDGround_959502Objects5, "Ground_03": gdjs.TutorialCode.GDGround_959503Objects5, "Ground_04": gdjs.TutorialCode.GDGround_959504Objects5, "Ground_05": gdjs.TutorialCode.GDGround_959505Objects5, "Ground_06": gdjs.TutorialCode.GDGround_959506Objects5, "Ground_07": gdjs.TutorialCode.GDGround_959507Objects5, "Ground_08": gdjs.TutorialCode.GDGround_959508Objects5, "Ground_09": gdjs.TutorialCode.GDGround_959509Objects5, "Good_Gate": gdjs.TutorialCode.GDGood_9595GateObjects5, "Void": gdjs.TutorialCode.GDVoidObjects5, "Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects5, "Pad": gdjs.TutorialCode.GDPadObjects5, "Ground_10": gdjs.TutorialCode.GDGround_959510Objects5, "Ground_11": gdjs.TutorialCode.GDGround_959511Objects5, "Bad_Gate": gdjs.TutorialCode.GDBad_9595GateObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCurserObjects5Objects = Hashtable.newFrom({"Curser": gdjs.TutorialCode.GDCurserObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects5});
gdjs.TutorialCode.asyncCallback17881276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects6);

{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects6.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects6[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects6.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects6[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.5, "bounce", 0.1, false, false);
}
}}
gdjs.TutorialCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDCurserObjects5) asyncObjectsList.addObject("Curser", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17881276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDBomb_95959595CardObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects5[k] = gdjs.TutorialCode.GDMove_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects5[k] = gdjs.TutorialCode.GDSword_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects5[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[k] = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSwap_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSwap_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSwap_9595CardObjects5[k] = gdjs.TutorialCode.GDSwap_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSwap_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDBomb_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDBomb_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDBomb_9595CardObjects5[k] = gdjs.TutorialCode.GDBomb_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDBomb_9595CardObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects5[k] = gdjs.TutorialCode.GDMove_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects5[k] = gdjs.TutorialCode.GDSword_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects5[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[k] = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSwap_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSwap_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSwap_9595CardObjects5[k] = gdjs.TutorialCode.GDSwap_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSwap_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDBomb_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDBomb_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDBomb_9595CardObjects5[k] = gdjs.TutorialCode.GDBomb_9595CardObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDBomb_9595CardObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8210740);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDBomb_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDMove_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDSwap_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDSword_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDTeleport_9595CardObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Swipe.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546TutorialCode_9546GDBomb_95959595CardObjects5Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDBomb_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDMove_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDSwap_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDSword_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5 */
/* Reuse gdjs.TutorialCode.GDTeleport_9595CardObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.TutorialCode.GDBad_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.TutorialCode.GDGood_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.TutorialCode.GDGround_959501Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.TutorialCode.GDGround_959502Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.TutorialCode.GDGround_959503Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.TutorialCode.GDGround_959504Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.TutorialCode.GDGround_959505Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.TutorialCode.GDGround_959506Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.TutorialCode.GDGround_959507Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.TutorialCode.GDGround_959508Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.TutorialCode.GDGround_959509Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.TutorialCode.GDGround_959510Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.TutorialCode.GDGround_959511Objects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.TutorialCode.GDPadObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.TutorialCode.GDVoidObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546TutorialCode_9546GDVoidObjects5ObjectsGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546TutorialCode_9546GDPadObjects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546TutorialCode_9546GDBad_95959595GateObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDBad_9595GateObjects5 */
/* Reuse gdjs.TutorialCode.GDGood_9595GateObjects5 */
/* Reuse gdjs.TutorialCode.GDGround_959501Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959502Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959503Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959504Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959505Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959506Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959507Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959508Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959509Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959510Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959511Objects5 */
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects5 */
/* Reuse gdjs.TutorialCode.GDPadObjects5 */
/* Reuse gdjs.TutorialCode.GDVoidObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDGround_959501Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959501Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959502Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959502Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959503Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959503Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959504Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959504Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959505Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959505Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959506Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959506Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959507Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959507Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959508Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959508Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959509Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959509Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGood_9595GateObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGood_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDVoidObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDVoidObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDPadObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDPadObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959510Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959510Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959511Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959511Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDBad_9595GateObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBad_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1.1, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.TutorialCode.GDBad_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.TutorialCode.GDGood_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.TutorialCode.GDGround_959501Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.TutorialCode.GDGround_959502Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.TutorialCode.GDGround_959503Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.TutorialCode.GDGround_959504Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.TutorialCode.GDGround_959505Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.TutorialCode.GDGround_959506Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.TutorialCode.GDGround_959507Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.TutorialCode.GDGround_959508Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.TutorialCode.GDGround_959509Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.TutorialCode.GDGround_959510Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.TutorialCode.GDGround_959511Objects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.TutorialCode.GDPadObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.TutorialCode.GDVoidObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546TutorialCode_9546GDVoidObjects5ObjectsGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546TutorialCode_9546GDPadObjects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546TutorialCode_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546TutorialCode_9546GDBad_95959595GateObjects5Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDBad_9595GateObjects5 */
/* Reuse gdjs.TutorialCode.GDGood_9595GateObjects5 */
/* Reuse gdjs.TutorialCode.GDGround_959501Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959502Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959503Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959504Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959505Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959506Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959507Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959508Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959509Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959510Objects5 */
/* Reuse gdjs.TutorialCode.GDGround_959511Objects5 */
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects5 */
/* Reuse gdjs.TutorialCode.GDPadObjects5 */
/* Reuse gdjs.TutorialCode.GDVoidObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDGround_959501Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959501Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959502Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959502Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959503Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959503Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959504Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959504Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959505Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959505Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959506Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959506Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959507Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959507Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959508Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959508Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959509Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959509Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGood_9595GateObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGood_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDVoidObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDVoidObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDPadObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDPadObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959510Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959510Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDGround_959511Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDGround_959511Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDBad_9595GateObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDBad_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCurserObjects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects5[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects5.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCurserObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCurserObjects5[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCurserObjects5[k] = gdjs.TutorialCode.GDCurserObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCurserObjects5.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCurserObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects5[i].getBehavior("Animation").setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects5[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.4, "bounce", 0.1, false, false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16144236);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600924);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMonsterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMonsterObjects5[k] = gdjs.TutorialCode.GDMonsterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMonsterObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMonsterObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMonsterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMonsterObjects5[k] = gdjs.TutorialCode.GDMonsterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMonsterObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMonsterObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.TutorialCode.GDSlash_9595EffectObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSlash_9595EffectObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSlash_9595EffectObjects5[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSlash_9595EffectObjects5[k] = gdjs.TutorialCode.GDSlash_9595EffectObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSlash_9595EffectObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDSlash_9595EffectObjects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDSlash_9595EffectObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSlash_9595EffectObjects5[i].getBehavior("Tween").addObjectScaleTween3("Slash", 1.2, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.TutorialCode.GDSlash_9595EffectObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSlash_9595EffectObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSlash_9595EffectObjects4[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSlash_9595EffectObjects4[k] = gdjs.TutorialCode.GDSlash_9595EffectObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSlash_9595EffectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDSlash_9595EffectObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDSlash_9595EffectObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSlash_9595EffectObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects6Objects = Hashtable.newFrom({"NPC_1": gdjs.TutorialCode.GDNPC_95951Objects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"NPC_2": gdjs.TutorialCode.GDNPC_95952Objects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects5});
gdjs.TutorialCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects6);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects6Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects6 */
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects6.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects6Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"NPC_2": gdjs.TutorialCode.GDNPC_95952Objects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects5});
gdjs.TutorialCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects6);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects6Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects6 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects6.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5Objects = Hashtable.newFrom({"NPC_1": gdjs.TutorialCode.GDNPC_95951Objects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects6Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects6});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5Objects = Hashtable.newFrom({"NPC_1": gdjs.TutorialCode.GDNPC_95951Objects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects5});
gdjs.TutorialCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects6);
gdjs.copyArray(gdjs.TutorialCode.GDRenderObjects5, gdjs.TutorialCode.GDRenderObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects6Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects6 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects6.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
/* Reuse gdjs.TutorialCode.GDRenderObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects5 */
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.TutorialCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects5[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects5[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects5 */
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects5[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


};gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.TutorialCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects5[i].getBehavior("Text").setText("TeleportBlade");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.TutorialCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects5[i].getBehavior("Text").setText("Swap");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.TutorialCode.eventsList11 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects4[k] = gdjs.TutorialCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.TutorialCode.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.TutorialCode.GDMoveObjects4);
/* Reuse gdjs.TutorialCode.GDMove_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMoveObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects4[k] = gdjs.TutorialCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.TutorialCode.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.TutorialCode.GDMoveObjects4);
/* Reuse gdjs.TutorialCode.GDMove_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMoveObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595MoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects4);
/* Reuse gdjs.TutorialCode.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.TutorialCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.TutorialCode.GDTeleportObjects4);
/* Reuse gdjs.TutorialCode.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects4[k] = gdjs.TutorialCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects4);
/* Reuse gdjs.TutorialCode.GDSword_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects4[i].getVariableNumber(gdjs.TutorialCode.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects4[k] = gdjs.TutorialCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.TutorialCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.TutorialCode.GDSwordObjects4);
/* Reuse gdjs.TutorialCode.GDSword_9595CardObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


};gdjs.TutorialCode.eventsList12 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList1(runtimeScene);
}


{


gdjs.TutorialCode.eventsList2(runtimeScene);
}


{


gdjs.TutorialCode.eventsList4(runtimeScene);
}


{


gdjs.TutorialCode.eventsList8(runtimeScene);
}


{


gdjs.TutorialCode.eventsList11(runtimeScene);
}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects4, "NPC_1": gdjs.TutorialCode.GDNPC_95951Objects4, "NPC_2": gdjs.TutorialCode.GDNPC_95952Objects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.TutorialCode.GDMonsterObjects4});
gdjs.TutorialCode.asyncCallback17570068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.TutorialCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17570068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17478396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.TutorialCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17478396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17591172 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.TutorialCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17591172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17590828 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.TutorialCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17590828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17580308 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.TutorialCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17580308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17588068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.TutorialCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17588068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17517908 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.TutorialCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17517908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17555844 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.TutorialCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17555844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17587268 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.TutorialCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17587268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17589124 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.TutorialCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17589124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TutorialCode.GDFade_9595ScreenObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects4, "NPC_1": gdjs.TutorialCode.GDNPC_95951Objects4, "NPC_2": gdjs.TutorialCode.GDNPC_95952Objects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGood_95959595WinObjects4Objects = Hashtable.newFrom({"Good_Win": gdjs.TutorialCode.GDGood_9595WinObjects4});
gdjs.TutorialCode.asyncCallback17524412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.TutorialCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17524412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17531004 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.TutorialCode.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17531004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17547340 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.TutorialCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17547340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17585228 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.TutorialCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17585228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17569212 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.TutorialCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17569212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17482412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.TutorialCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17482412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17653996 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.TutorialCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17653996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17605492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.TutorialCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17605492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17582204 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.TutorialCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17582204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17491628 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.TutorialCode.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17491628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17548388 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}}
gdjs.TutorialCode.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17548388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects4, gdjs.TutorialCode.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects5[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList33(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TutorialCode.GDFade_9595ScreenObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.TutorialCode.GDGood_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.TutorialCode.GDGood_9595WinObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDGood_9595GateObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDGood_9595GateObjects4[i].getBehavior("Opacity").getOpacity() > 200 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDGood_9595GateObjects4[k] = gdjs.TutorialCode.GDGood_9595GateObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDGood_9595GateObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDGood_95959595WinObjects4Objects, 64, false);
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.TutorialCode.GDFade_9595ScreenObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.asyncCallback17590284 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.TutorialCode.eventsList37 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17590284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17660820 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.TutorialCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17660820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17594188 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.TutorialCode.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17594188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17606556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.TutorialCode.eventsList40 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17606556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17614460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.TutorialCode.eventsList41 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17614460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17565716 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.TutorialCode.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17565716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17474948 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.TutorialCode.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17474948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17651364 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.TutorialCode.eventsList44 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17651364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17544500 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.TutorialCode.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17544500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.asyncCallback17671588 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.TutorialCode.eventsList46 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17671588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList37(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList38(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList40(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList44(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.TutorialCode.GDFade_9595ScreenObjects3, gdjs.TutorialCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects4[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList45(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.TutorialCode.GDFade_9595ScreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDFade_9595ScreenObjects3[k] = gdjs.TutorialCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.TutorialCode.GDFade_9595ScreenObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDFade_9595ScreenObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.eventsList49 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMonsterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMonsterObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDMonsterObjects4[k] = gdjs.TutorialCode.GDMonsterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMonsterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.TutorialCode.GDFade_9595ScreenObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDFade_9595ScreenObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList36(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.TutorialCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.TutorialCode.GDRenderObjects4});
gdjs.TutorialCode.eventsList50 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 0, "linear", 0.05, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.TutorialCode.GDCharacterObjects4_1final.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects4_1final.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4, gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4, gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4, gdjs.TutorialCode.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects5[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects5[k] = gdjs.TutorialCode.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects5[k] = gdjs.TutorialCode.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects5[k] = gdjs.TutorialCode.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.TutorialCode.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDCharacterObjects4_1final.indexOf(gdjs.TutorialCode.GDCharacterObjects5[j]) === -1 )
            gdjs.TutorialCode.GDCharacterObjects4_1final.push(gdjs.TutorialCode.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95951Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95951Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95951Objects4_1final.push(gdjs.TutorialCode.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.TutorialCode.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.TutorialCode.GDNPC_95952Objects4_1final.indexOf(gdjs.TutorialCode.GDNPC_95952Objects5[j]) === -1 )
            gdjs.TutorialCode.GDNPC_95952Objects4_1final.push(gdjs.TutorialCode.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.TutorialCode.GDCharacterObjects4_1final, gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(gdjs.TutorialCode.GDNPC_95951Objects4_1final, gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(gdjs.TutorialCode.GDNPC_95952Objects4_1final, gdjs.TutorialCode.GDNPC_95952Objects4);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.TutorialCode.GDRight_9595ClickObjects4);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.TutorialCode.GDUI_9595TextObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDUI_9595TextObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDUI_9595TextObjects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRight_9595ClickObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRight_9595ClickObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.TutorialCode.GDRight_9595ClickObjects3);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.TutorialCode.GDUI_9595TextObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDUI_9595TextObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDUI_9595TextObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRight_9595ClickObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDRight_9595ClickObjects3[i].hide();
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects5ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects5, "NPC_1": gdjs.TutorialCode.GDNPC_95951Objects5, "NPC_2": gdjs.TutorialCode.GDNPC_95952Objects5});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPadObjects5Objects = Hashtable.newFrom({"Pad": gdjs.TutorialCode.GDPadObjects5});
gdjs.TutorialCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17473404);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}}

}


};gdjs.TutorialCode.eventsList52 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.TutorialCode.GDPadObjects4);

for (gdjs.TutorialCode.forEachIndex5 = 0;gdjs.TutorialCode.forEachIndex5 < gdjs.TutorialCode.GDPadObjects4.length;++gdjs.TutorialCode.forEachIndex5) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);
gdjs.TutorialCode.GDPadObjects5.length = 0;


gdjs.TutorialCode.forEachTemporary5 = gdjs.TutorialCode.GDPadObjects4[gdjs.TutorialCode.forEachIndex5];
gdjs.TutorialCode.GDPadObjects5.push(gdjs.TutorialCode.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDPadObjects5.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDPadObjects5[i].getBehavior("Animation").getAnimationName() == "Inactive" ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDPadObjects5[k] = gdjs.TutorialCode.GDPadObjects5[i];
        ++k;
    }
}
gdjs.TutorialCode.GDPadObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects5ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects5ObjectsGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects5Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDPadObjects5Objects, false, runtimeScene, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.TutorialCode.GDPadObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDPadObjects5[i].getBehavior("Animation").setAnimationName("Active");
}
}
{ //Subevents: 
gdjs.TutorialCode.eventsList51(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


{



}


};gdjs.TutorialCode.eventsList53 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(3.1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(9);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(6.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects3[i].getBehavior("Scale").setScale(12);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects4Objects = Hashtable.newFrom({"Move_Card": gdjs.TutorialCode.GDMove_9595CardObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCurserObjects4Objects = Hashtable.newFrom({"Curser": gdjs.TutorialCode.GDCurserObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects3});
gdjs.TutorialCode.eventsList54 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects4[k] = gdjs.TutorialCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595CardObjects4[k] = gdjs.TutorialCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600004);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCurserObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17599684);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects4);
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Moveing.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects3[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17694652);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects3);
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects4Objects = Hashtable.newFrom({"Teleport_Card": gdjs.TutorialCode.GDTeleport_9595CardObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSmokeObjects5Objects = Hashtable.newFrom({"Smoke": gdjs.TutorialCode.GDSmokeObjects5});
gdjs.TutorialCode.asyncCallback17620180 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects5);
gdjs.TutorialCode.GDSmokeObjects5.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSmokeObjects5Objects, (( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].hide(false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].returnVariable(gdjs.TutorialCode.GDTeleport_9595CardObjects5[i].getVariables().getFromIndex(0)).sub(1);
}
}}
gdjs.TutorialCode.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDCharacterObjects4) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.TutorialCode.GDNPC_95951Objects4) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.TutorialCode.GDNPC_95952Objects4) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17620180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects4Objects = Hashtable.newFrom({"Swap_Card": gdjs.TutorialCode.GDSwap_9595CardObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.TutorialCode.GDNPC_95951Objects4});
gdjs.TutorialCode.eventsList56 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17554812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects4});
gdjs.TutorialCode.eventsList57 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17619252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.TutorialCode.GDNPC_95952Objects4});
gdjs.TutorialCode.eventsList58 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17615948);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.TutorialCode.GDNPC_95951Objects4});
gdjs.TutorialCode.eventsList59 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17484196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects4});
gdjs.TutorialCode.eventsList60 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17608228);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.TutorialCode.GDNPC_95952Objects4});
gdjs.TutorialCode.eventsList61 = function(runtimeScene) {

{

/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17627196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects3});
gdjs.TutorialCode.eventsList62 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleport_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDTeleport_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleport_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17653100);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17695108);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].hide();
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].hide();
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].hide();
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17613716);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDSwap_9595CardObjects4[k] = gdjs.TutorialCode.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSwap_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSwap_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDSwap_9595CardObjects4[k] = gdjs.TutorialCode.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSwap_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17546188);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17476508);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList56(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17685636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList57(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17479260);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList58(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595951Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17474636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList59(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17633124);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList60(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDNPC_959595952Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17579292);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList61(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects3[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17609988);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects4Objects = Hashtable.newFrom({"Sword_Card": gdjs.TutorialCode.GDSword_9595CardObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.TutorialCode.GDMonsterObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSlash_95959595EffectObjects4Objects = Hashtable.newFrom({"Slash_Effect": gdjs.TutorialCode.GDSlash_9595EffectObjects4});
gdjs.TutorialCode.asyncCallback17665004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.TutorialCode.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDMonsterObjects4) asyncObjectsList.addObject("Monster", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17665004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects4Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.TutorialCode.GDMonsterObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSlash_95959595EffectObjects4Objects = Hashtable.newFrom({"Slash_Effect": gdjs.TutorialCode.GDSlash_9595EffectObjects4});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSmokeObjects5Objects = Hashtable.newFrom({"Smoke": gdjs.TutorialCode.GDSmokeObjects5});
gdjs.TutorialCode.asyncCallback17537804 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects5);
gdjs.TutorialCode.GDSmokeObjects5.length = 0;

{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSmokeObjects5Objects, (( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getCenterXInScene()) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getCenterXInScene()), (( gdjs.TutorialCode.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.TutorialCode.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.TutorialCode.GDCharacterObjects5[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95951Objects5[0].getCenterYInScene()) :gdjs.TutorialCode.GDNPC_95952Objects5[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects5[i].hide(false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects5[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects5.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.TutorialCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.TutorialCode.GDCharacterObjects4) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.TutorialCode.GDMonsterObjects4) asyncObjectsList.addObject("Monster", obj);
for (const obj of gdjs.TutorialCode.GDMove_9595TriggerObjects4) asyncObjectsList.addObject("Move_Trigger", obj);
for (const obj of gdjs.TutorialCode.GDNPC_95951Objects4) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.TutorialCode.GDNPC_95952Objects4) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.TutorialCode.asyncCallback17537804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.TutorialCode.GDMove_9595TriggerObjects3});
gdjs.TutorialCode.eventsList65 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSword_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects4[k] = gdjs.TutorialCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDSword_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDSword_9595CardObjects4[k] = gdjs.TutorialCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDSword_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17507548);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17665324);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDMonsterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);
gdjs.TutorialCode.GDSlash_9595EffectObjects4.length = 0;

{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].returnVariable(gdjs.TutorialCode.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSlash_95959595EffectObjects4Objects, (( gdjs.TutorialCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMonsterObjects4[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.TutorialCode.eventsList63(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17466468);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[k] = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17529924);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMonsterObjects4Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects4[k] = gdjs.TutorialCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects4[k] = gdjs.TutorialCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects4[k] = gdjs.TutorialCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects4[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17467148);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects4 */
/* Reuse gdjs.TutorialCode.GDMonsterObjects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects4 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects4 */
gdjs.TutorialCode.GDSlash_9595EffectObjects4.length = 0;

{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects4[i].hide();
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects4[i].hide();
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects4[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSlash_95959595EffectObjects4Objects, (( gdjs.TutorialCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.TutorialCode.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.TutorialCode.GDMonsterObjects4[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.TutorialCode.eventsList64(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDMove_9595TriggerObjects3[k] = gdjs.TutorialCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17624076);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.TutorialCode.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects3);
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.TutorialCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects3Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.TutorialCode.GDTeleportBlade_9595CardObjects3});
gdjs.TutorialCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10633164);
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects3);
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTeleportBlade_95959595CardObjects3Objects, (( gdjs.TutorialCode.GDSword_9595CardObjects3.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects3[0].getCenterXInScene()), (( gdjs.TutorialCode.GDSword_9595CardObjects3.length === 0 ) ? 0 :gdjs.TutorialCode.GDSword_9595CardObjects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects3[i].returnVariable(gdjs.TutorialCode.GDSword_9595CardObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects3[i].returnVariable(gdjs.TutorialCode.GDTeleport_9595CardObjects3[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects2Objects = Hashtable.newFrom({"Swap_Card": gdjs.TutorialCode.GDSwap_9595CardObjects2});
gdjs.TutorialCode.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17497196);
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects2);
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects2 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects2);
gdjs.TutorialCode.GDSwap_9595CardObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDSwap_95959595CardObjects2Objects, (( gdjs.TutorialCode.GDTeleport_9595CardObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects2[0].getCenterXInScene()), (( gdjs.TutorialCode.GDTeleport_9595CardObjects2.length === 0 ) ? 0 :gdjs.TutorialCode.GDTeleport_9595CardObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].returnVariable(gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects2[i].returnVariable(gdjs.TutorialCode.GDMove_9595CardObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.TutorialCode.eventsList68 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects3[k] = gdjs.TutorialCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects3[k] = gdjs.TutorialCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects3[k] = gdjs.TutorialCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects3.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects3 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList66(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.TutorialCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects2[k] = gdjs.TutorialCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects2[k] = gdjs.TutorialCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects2[k] = gdjs.TutorialCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects2[k] = gdjs.TutorialCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects2[k] = gdjs.TutorialCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects2[k] = gdjs.TutorialCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDCharacterObjects2[k] = gdjs.TutorialCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95951Objects2[k] = gdjs.TutorialCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.TutorialCode.GDNPC_95952Objects2[k] = gdjs.TutorialCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDNPC_95952Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCharacterObjects2 */
/* Reuse gdjs.TutorialCode.GDNPC_95951Objects2 */
/* Reuse gdjs.TutorialCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.TutorialCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.TutorialCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.TutorialCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false);
}
}
{ //Subevents
gdjs.TutorialCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.TutorialCode.eventsList69 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList52(runtimeScene);
}


{


gdjs.TutorialCode.eventsList53(runtimeScene);
}


{


gdjs.TutorialCode.eventsList54(runtimeScene);
}


{


gdjs.TutorialCode.eventsList62(runtimeScene);
}


{


gdjs.TutorialCode.eventsList65(runtimeScene);
}


{


gdjs.TutorialCode.eventsList68(runtimeScene);
}


};gdjs.TutorialCode.eventsList70 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList49(runtimeScene);
}


{


gdjs.TutorialCode.eventsList50(runtimeScene);
}


{


gdjs.TutorialCode.eventsList69(runtimeScene);
}


};gdjs.TutorialCode.eventsList71 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList12(runtimeScene);
}


{


gdjs.TutorialCode.eventsList70(runtimeScene);
}


};gdjs.TutorialCode.mapOfEmptyGDMonsterObjects = Hashtable.newFrom({"Monster": []});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTutorial_959595952Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595951Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595953Objects2Objects = Hashtable.newFrom({"Tutorial_2": gdjs.TutorialCode.GDTutorial_95952Objects2, "Tutorial_1": gdjs.TutorialCode.GDTutorial_95951Objects2, "Tutorial_3": gdjs.TutorialCode.GDTutorial_95953Objects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCard_95959595UIObjects2Objects = Hashtable.newFrom({"Card_UI": gdjs.TutorialCode.GDCard_9595UIObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTutorial_959595952Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595951Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595953Objects2Objects = Hashtable.newFrom({"Tutorial_2": gdjs.TutorialCode.GDTutorial_95952Objects2, "Tutorial_1": gdjs.TutorialCode.GDTutorial_95951Objects2, "Tutorial_3": gdjs.TutorialCode.GDTutorial_95953Objects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects2});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCard_95959595UIObjects1Objects = Hashtable.newFrom({"Card_UI": gdjs.TutorialCode.GDCard_9595UIObjects1});
gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects1Objects = Hashtable.newFrom({"Character": gdjs.TutorialCode.GDCharacterObjects1});
gdjs.TutorialCode.eventsList72 = function(runtimeScene) {

{



}


{


gdjs.TutorialCode.eventsList71(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.TutorialCode.GDBomb_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Card_UI"), gdjs.TutorialCode.GDCard_9595UIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.TutorialCode.GDCurserObjects2);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.TutorialCode.GDGood_9595GateObjects2);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.TutorialCode.GDMonsterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.TutorialCode.GDMove_9595TriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.TutorialCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.TutorialCode.GDSwap_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_1"), gdjs.TutorialCode.GDTutorial_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_2"), gdjs.TutorialCode.GDTutorial_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_3"), gdjs.TutorialCode.GDTutorial_95953Objects2);
{gdjs.evtTools.window.setWindowSize(runtimeScene, 1280, 720, false);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Background/fade", 0, 0, 0);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{for(var i = 0, len = gdjs.TutorialCode.GDCurserObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCurserObjects2[i].getBehavior("Scale").setScale(0.5);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects2[i].getBehavior("Scale").setScale(0.7);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95951Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95952Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95953Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95953Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDCard_9595UIObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCard_9595UIObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595TriggerObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595TriggerObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.TutorialCode.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSwap_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.TutorialCode.GDBomb_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDBomb_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMonsterObjects2[i].getBehavior("Opacity").setOpacity(200);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Tutorial");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{for(var i = 0, len = gdjs.TutorialCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCharacterObjects2[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDNPC_95951Objects2[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.85, "", 0);
}{for(var i = 0, len = gdjs.TutorialCode.GDGood_9595GateObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDGood_9595GateObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16887116);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.TutorialCode.GDFade_9595ScreenObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDFade_9595ScreenObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDFade_9595ScreenObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Fade_In", 0, "linear", 2, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16888180);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.TutorialCode.GDMove_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.TutorialCode.GDSword_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.TutorialCode.GDTeleport_9595CardObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].returnVariable(gdjs.TutorialCode.GDTeleport_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDMove_9595CardObjects2[i].returnVariable(gdjs.TutorialCode.GDMove_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(5);
}
}{for(var i = 0, len = gdjs.TutorialCode.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDSword_9595CardObjects2[i].returnVariable(gdjs.TutorialCode.GDSword_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(1);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.TutorialCode.mapOfEmptyGDMonsterObjects) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.TutorialCode.GDGood_9595GateObjects2);
{for(var i = 0, len = gdjs.TutorialCode.GDGood_9595GateObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDGood_9595GateObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 255, "linear", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card_UI"), gdjs.TutorialCode.GDCard_9595UIObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCard_9595UIObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCard_9595UIObjects2[i].getZOrder() == 500 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCard_9595UIObjects2[k] = gdjs.TutorialCode.GDCard_9595UIObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCard_9595UIObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCard_9595UIObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDCard_9595UIObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCard_9595UIObjects2[i].getBehavior("Animation").setAnimationName("Sowrd");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card_UI"), gdjs.TutorialCode.GDCard_9595UIObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.TutorialCode.GDCard_9595UIObjects2.length;i<l;++i) {
    if ( gdjs.TutorialCode.GDCard_9595UIObjects2[i].getZOrder() == 600 ) {
        isConditionTrue_0 = true;
        gdjs.TutorialCode.GDCard_9595UIObjects2[k] = gdjs.TutorialCode.GDCard_9595UIObjects2[i];
        ++k;
    }
}
gdjs.TutorialCode.GDCard_9595UIObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCard_9595UIObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDCard_9595UIObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCard_9595UIObjects2[i].getBehavior("Animation").setAnimationName("Teleport");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_1"), gdjs.TutorialCode.GDTutorial_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_2"), gdjs.TutorialCode.GDTutorial_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_3"), gdjs.TutorialCode.GDTutorial_95953Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTutorial_959595952Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595951Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595953Objects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects, 192, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDTutorial_95951Objects2 */
/* Reuse gdjs.TutorialCode.GDTutorial_95952Objects2 */
/* Reuse gdjs.TutorialCode.GDTutorial_95953Objects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95952Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 255, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95951Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 255, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95953Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95953Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 255, "linear", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card_UI"), gdjs.TutorialCode.GDCard_9595UIObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCard_95959595UIObjects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects, 192, false);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCard_9595UIObjects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDCard_9595UIObjects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDCard_9595UIObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 180, "linear", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_1"), gdjs.TutorialCode.GDTutorial_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_2"), gdjs.TutorialCode.GDTutorial_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_3"), gdjs.TutorialCode.GDTutorial_95953Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDTutorial_959595952Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595951Objects2ObjectsGDgdjs_9546TutorialCode_9546GDTutorial_959595953Objects2Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects2Objects, 192, true);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDTutorial_95951Objects2 */
/* Reuse gdjs.TutorialCode.GDTutorial_95952Objects2 */
/* Reuse gdjs.TutorialCode.GDTutorial_95953Objects2 */
{for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95952Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95952Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 0, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95951Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95951Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 0, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.TutorialCode.GDTutorial_95953Objects2.length ;i < len;++i) {
    gdjs.TutorialCode.GDTutorial_95953Objects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 0, "linear", 0.5, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Card_UI"), gdjs.TutorialCode.GDCard_9595UIObjects1);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.TutorialCode.GDCharacterObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCard_95959595UIObjects1Objects, gdjs.TutorialCode.mapOfGDgdjs_9546TutorialCode_9546GDCharacterObjects1Objects, 192, true);
if (isConditionTrue_0) {
/* Reuse gdjs.TutorialCode.GDCard_9595UIObjects1 */
{for(var i = 0, len = gdjs.TutorialCode.GDCard_9595UIObjects1.length ;i < len;++i) {
    gdjs.TutorialCode.GDCard_9595UIObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Show", 0, "linear", 0.5, false);
}
}}

}


};gdjs.TutorialCode.eventsList73 = function(runtimeScene) {

{


gdjs.TutorialCode.eventsList72(runtimeScene);
}


};

gdjs.TutorialCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.TutorialCode.GDTutorial_95951Objects1.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects2.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects3.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects4.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects5.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects6.length = 0;
gdjs.TutorialCode.GDTutorial_95951Objects7.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects1.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects2.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects3.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects4.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects5.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects6.length = 0;
gdjs.TutorialCode.GDTutorial_95953Objects7.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects1.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects2.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects3.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects4.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects5.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects6.length = 0;
gdjs.TutorialCode.GDTutorial_95952Objects7.length = 0;
gdjs.TutorialCode.GDGround_959501Objects1.length = 0;
gdjs.TutorialCode.GDGround_959501Objects2.length = 0;
gdjs.TutorialCode.GDGround_959501Objects3.length = 0;
gdjs.TutorialCode.GDGround_959501Objects4.length = 0;
gdjs.TutorialCode.GDGround_959501Objects5.length = 0;
gdjs.TutorialCode.GDGround_959501Objects6.length = 0;
gdjs.TutorialCode.GDGround_959501Objects7.length = 0;
gdjs.TutorialCode.GDGround_959502Objects1.length = 0;
gdjs.TutorialCode.GDGround_959502Objects2.length = 0;
gdjs.TutorialCode.GDGround_959502Objects3.length = 0;
gdjs.TutorialCode.GDGround_959502Objects4.length = 0;
gdjs.TutorialCode.GDGround_959502Objects5.length = 0;
gdjs.TutorialCode.GDGround_959502Objects6.length = 0;
gdjs.TutorialCode.GDGround_959502Objects7.length = 0;
gdjs.TutorialCode.GDGround_959503Objects1.length = 0;
gdjs.TutorialCode.GDGround_959503Objects2.length = 0;
gdjs.TutorialCode.GDGround_959503Objects3.length = 0;
gdjs.TutorialCode.GDGround_959503Objects4.length = 0;
gdjs.TutorialCode.GDGround_959503Objects5.length = 0;
gdjs.TutorialCode.GDGround_959503Objects6.length = 0;
gdjs.TutorialCode.GDGround_959503Objects7.length = 0;
gdjs.TutorialCode.GDGround_959504Objects1.length = 0;
gdjs.TutorialCode.GDGround_959504Objects2.length = 0;
gdjs.TutorialCode.GDGround_959504Objects3.length = 0;
gdjs.TutorialCode.GDGround_959504Objects4.length = 0;
gdjs.TutorialCode.GDGround_959504Objects5.length = 0;
gdjs.TutorialCode.GDGround_959504Objects6.length = 0;
gdjs.TutorialCode.GDGround_959504Objects7.length = 0;
gdjs.TutorialCode.GDGround_959505Objects1.length = 0;
gdjs.TutorialCode.GDGround_959505Objects2.length = 0;
gdjs.TutorialCode.GDGround_959505Objects3.length = 0;
gdjs.TutorialCode.GDGround_959505Objects4.length = 0;
gdjs.TutorialCode.GDGround_959505Objects5.length = 0;
gdjs.TutorialCode.GDGround_959505Objects6.length = 0;
gdjs.TutorialCode.GDGround_959505Objects7.length = 0;
gdjs.TutorialCode.GDGround_959506Objects1.length = 0;
gdjs.TutorialCode.GDGround_959506Objects2.length = 0;
gdjs.TutorialCode.GDGround_959506Objects3.length = 0;
gdjs.TutorialCode.GDGround_959506Objects4.length = 0;
gdjs.TutorialCode.GDGround_959506Objects5.length = 0;
gdjs.TutorialCode.GDGround_959506Objects6.length = 0;
gdjs.TutorialCode.GDGround_959506Objects7.length = 0;
gdjs.TutorialCode.GDGround_959507Objects1.length = 0;
gdjs.TutorialCode.GDGround_959507Objects2.length = 0;
gdjs.TutorialCode.GDGround_959507Objects3.length = 0;
gdjs.TutorialCode.GDGround_959507Objects4.length = 0;
gdjs.TutorialCode.GDGround_959507Objects5.length = 0;
gdjs.TutorialCode.GDGround_959507Objects6.length = 0;
gdjs.TutorialCode.GDGround_959507Objects7.length = 0;
gdjs.TutorialCode.GDGround_959508Objects1.length = 0;
gdjs.TutorialCode.GDGround_959508Objects2.length = 0;
gdjs.TutorialCode.GDGround_959508Objects3.length = 0;
gdjs.TutorialCode.GDGround_959508Objects4.length = 0;
gdjs.TutorialCode.GDGround_959508Objects5.length = 0;
gdjs.TutorialCode.GDGround_959508Objects6.length = 0;
gdjs.TutorialCode.GDGround_959508Objects7.length = 0;
gdjs.TutorialCode.GDGround_959509Objects1.length = 0;
gdjs.TutorialCode.GDGround_959509Objects2.length = 0;
gdjs.TutorialCode.GDGround_959509Objects3.length = 0;
gdjs.TutorialCode.GDGround_959509Objects4.length = 0;
gdjs.TutorialCode.GDGround_959509Objects5.length = 0;
gdjs.TutorialCode.GDGround_959509Objects6.length = 0;
gdjs.TutorialCode.GDGround_959509Objects7.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects1.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects2.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects3.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects4.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects5.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects6.length = 0;
gdjs.TutorialCode.GDGood_9595WinObjects7.length = 0;
gdjs.TutorialCode.GDVoidObjects1.length = 0;
gdjs.TutorialCode.GDVoidObjects2.length = 0;
gdjs.TutorialCode.GDVoidObjects3.length = 0;
gdjs.TutorialCode.GDVoidObjects4.length = 0;
gdjs.TutorialCode.GDVoidObjects5.length = 0;
gdjs.TutorialCode.GDVoidObjects6.length = 0;
gdjs.TutorialCode.GDVoidObjects7.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects1.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects2.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects3.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects4.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects5.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects6.length = 0;
gdjs.TutorialCode.GDGood_9595GateObjects7.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects1.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects2.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects3.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects4.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects5.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects6.length = 0;
gdjs.TutorialCode.GDMove_9595TriggerObjects7.length = 0;
gdjs.TutorialCode.GDCharacterObjects1.length = 0;
gdjs.TutorialCode.GDCharacterObjects2.length = 0;
gdjs.TutorialCode.GDCharacterObjects3.length = 0;
gdjs.TutorialCode.GDCharacterObjects4.length = 0;
gdjs.TutorialCode.GDCharacterObjects5.length = 0;
gdjs.TutorialCode.GDCharacterObjects6.length = 0;
gdjs.TutorialCode.GDCharacterObjects7.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDMove_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects1.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects2.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects3.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects4.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects5.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects6.length = 0;
gdjs.TutorialCode.GDAmount_9595MoveObjects7.length = 0;
gdjs.TutorialCode.GDMoveObjects1.length = 0;
gdjs.TutorialCode.GDMoveObjects2.length = 0;
gdjs.TutorialCode.GDMoveObjects3.length = 0;
gdjs.TutorialCode.GDMoveObjects4.length = 0;
gdjs.TutorialCode.GDMoveObjects5.length = 0;
gdjs.TutorialCode.GDMoveObjects6.length = 0;
gdjs.TutorialCode.GDMoveObjects7.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDSword_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects1.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects2.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects3.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects4.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects5.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects6.length = 0;
gdjs.TutorialCode.GDAmount_9595SwordObjects7.length = 0;
gdjs.TutorialCode.GDSwordObjects1.length = 0;
gdjs.TutorialCode.GDSwordObjects2.length = 0;
gdjs.TutorialCode.GDSwordObjects3.length = 0;
gdjs.TutorialCode.GDSwordObjects4.length = 0;
gdjs.TutorialCode.GDSwordObjects5.length = 0;
gdjs.TutorialCode.GDSwordObjects6.length = 0;
gdjs.TutorialCode.GDSwordObjects7.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDTeleport_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects1.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects2.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects3.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects4.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects5.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects6.length = 0;
gdjs.TutorialCode.GDAmount_9595TeleportObjects7.length = 0;
gdjs.TutorialCode.GDTeleportObjects1.length = 0;
gdjs.TutorialCode.GDTeleportObjects2.length = 0;
gdjs.TutorialCode.GDTeleportObjects3.length = 0;
gdjs.TutorialCode.GDTeleportObjects4.length = 0;
gdjs.TutorialCode.GDTeleportObjects5.length = 0;
gdjs.TutorialCode.GDTeleportObjects6.length = 0;
gdjs.TutorialCode.GDTeleportObjects7.length = 0;
gdjs.TutorialCode.GDCurserObjects1.length = 0;
gdjs.TutorialCode.GDCurserObjects2.length = 0;
gdjs.TutorialCode.GDCurserObjects3.length = 0;
gdjs.TutorialCode.GDCurserObjects4.length = 0;
gdjs.TutorialCode.GDCurserObjects5.length = 0;
gdjs.TutorialCode.GDCurserObjects6.length = 0;
gdjs.TutorialCode.GDCurserObjects7.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects1.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects2.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects3.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects4.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects5.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects6.length = 0;
gdjs.TutorialCode.GDFade_9595ScreenObjects7.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects1.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects2.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects3.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects4.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects5.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects6.length = 0;
gdjs.TutorialCode.GDSlash_9595EffectObjects7.length = 0;
gdjs.TutorialCode.GDBackgroundObjects1.length = 0;
gdjs.TutorialCode.GDBackgroundObjects2.length = 0;
gdjs.TutorialCode.GDBackgroundObjects3.length = 0;
gdjs.TutorialCode.GDBackgroundObjects4.length = 0;
gdjs.TutorialCode.GDBackgroundObjects5.length = 0;
gdjs.TutorialCode.GDBackgroundObjects6.length = 0;
gdjs.TutorialCode.GDBackgroundObjects7.length = 0;
gdjs.TutorialCode.GDMonsterObjects1.length = 0;
gdjs.TutorialCode.GDMonsterObjects2.length = 0;
gdjs.TutorialCode.GDMonsterObjects3.length = 0;
gdjs.TutorialCode.GDMonsterObjects4.length = 0;
gdjs.TutorialCode.GDMonsterObjects5.length = 0;
gdjs.TutorialCode.GDMonsterObjects6.length = 0;
gdjs.TutorialCode.GDMonsterObjects7.length = 0;
gdjs.TutorialCode.GDPadObjects1.length = 0;
gdjs.TutorialCode.GDPadObjects2.length = 0;
gdjs.TutorialCode.GDPadObjects3.length = 0;
gdjs.TutorialCode.GDPadObjects4.length = 0;
gdjs.TutorialCode.GDPadObjects5.length = 0;
gdjs.TutorialCode.GDPadObjects6.length = 0;
gdjs.TutorialCode.GDPadObjects7.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects1.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects2.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects3.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects4.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects5.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects6.length = 0;
gdjs.TutorialCode.GDUI_9595TextObjects7.length = 0;
gdjs.TutorialCode.GDDebugObjects1.length = 0;
gdjs.TutorialCode.GDDebugObjects2.length = 0;
gdjs.TutorialCode.GDDebugObjects3.length = 0;
gdjs.TutorialCode.GDDebugObjects4.length = 0;
gdjs.TutorialCode.GDDebugObjects5.length = 0;
gdjs.TutorialCode.GDDebugObjects6.length = 0;
gdjs.TutorialCode.GDDebugObjects7.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDTeleportBlade_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDRenderObjects1.length = 0;
gdjs.TutorialCode.GDRenderObjects2.length = 0;
gdjs.TutorialCode.GDRenderObjects3.length = 0;
gdjs.TutorialCode.GDRenderObjects4.length = 0;
gdjs.TutorialCode.GDRenderObjects5.length = 0;
gdjs.TutorialCode.GDRenderObjects6.length = 0;
gdjs.TutorialCode.GDRenderObjects7.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects1.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects2.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects3.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects4.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects5.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects6.length = 0;
gdjs.TutorialCode.GDReset_9595buttonObjects7.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects1.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects2.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects3.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects4.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects5.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects6.length = 0;
gdjs.TutorialCode.GDUI_9595Text_95952Objects7.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects1.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects2.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects3.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects4.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects5.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects6.length = 0;
gdjs.TutorialCode.GDRight_9595ClickObjects7.length = 0;
gdjs.TutorialCode.GDGround_959510Objects1.length = 0;
gdjs.TutorialCode.GDGround_959510Objects2.length = 0;
gdjs.TutorialCode.GDGround_959510Objects3.length = 0;
gdjs.TutorialCode.GDGround_959510Objects4.length = 0;
gdjs.TutorialCode.GDGround_959510Objects5.length = 0;
gdjs.TutorialCode.GDGround_959510Objects6.length = 0;
gdjs.TutorialCode.GDGround_959510Objects7.length = 0;
gdjs.TutorialCode.GDGround_959511Objects1.length = 0;
gdjs.TutorialCode.GDGround_959511Objects2.length = 0;
gdjs.TutorialCode.GDGround_959511Objects3.length = 0;
gdjs.TutorialCode.GDGround_959511Objects4.length = 0;
gdjs.TutorialCode.GDGround_959511Objects5.length = 0;
gdjs.TutorialCode.GDGround_959511Objects6.length = 0;
gdjs.TutorialCode.GDGround_959511Objects7.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDSwap_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects1.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects2.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects3.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects4.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects5.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects6.length = 0;
gdjs.TutorialCode.GDBomb_9595CardObjects7.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects1.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects2.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects3.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects4.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects5.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects6.length = 0;
gdjs.TutorialCode.GDNPC_95951Objects7.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects1.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects2.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects3.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects4.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects5.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects6.length = 0;
gdjs.TutorialCode.GDBad_9595WinObjects7.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects1.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects2.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects3.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects4.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects5.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects6.length = 0;
gdjs.TutorialCode.GDBad_9595GateObjects7.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects1.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects2.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects3.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects4.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects5.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects6.length = 0;
gdjs.TutorialCode.GDWeight_9595PadObjects7.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects1.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects2.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects3.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects4.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects5.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects6.length = 0;
gdjs.TutorialCode.GDNPC_95952Objects7.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects1.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects2.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects3.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects4.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects5.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects6.length = 0;
gdjs.TutorialCode.GDCard_9595UIObjects7.length = 0;
gdjs.TutorialCode.GDSmokeObjects1.length = 0;
gdjs.TutorialCode.GDSmokeObjects2.length = 0;
gdjs.TutorialCode.GDSmokeObjects3.length = 0;
gdjs.TutorialCode.GDSmokeObjects4.length = 0;
gdjs.TutorialCode.GDSmokeObjects5.length = 0;
gdjs.TutorialCode.GDSmokeObjects6.length = 0;
gdjs.TutorialCode.GDSmokeObjects7.length = 0;

gdjs.TutorialCode.eventsList73(runtimeScene);

return;

}

gdjs['TutorialCode'] = gdjs.TutorialCode;
