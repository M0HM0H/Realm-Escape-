gdjs.Stage8Code = {};
gdjs.Stage8Code.GDCharacterObjects4_1final = [];

gdjs.Stage8Code.GDNPC_95951Objects4_1final = [];

gdjs.Stage8Code.GDNPC_95952Objects4_1final = [];

gdjs.Stage8Code.forEachIndex5 = 0;

gdjs.Stage8Code.forEachObjects5 = [];

gdjs.Stage8Code.forEachTemporary5 = null;

gdjs.Stage8Code.forEachTotalCount5 = 0;

gdjs.Stage8Code.GDTutorial_95952Objects1= [];
gdjs.Stage8Code.GDTutorial_95952Objects2= [];
gdjs.Stage8Code.GDTutorial_95952Objects3= [];
gdjs.Stage8Code.GDTutorial_95952Objects4= [];
gdjs.Stage8Code.GDTutorial_95952Objects5= [];
gdjs.Stage8Code.GDTutorial_95952Objects6= [];
gdjs.Stage8Code.GDTutorial_95952Objects7= [];
gdjs.Stage8Code.GDTutorial_95951Objects1= [];
gdjs.Stage8Code.GDTutorial_95951Objects2= [];
gdjs.Stage8Code.GDTutorial_95951Objects3= [];
gdjs.Stage8Code.GDTutorial_95951Objects4= [];
gdjs.Stage8Code.GDTutorial_95951Objects5= [];
gdjs.Stage8Code.GDTutorial_95951Objects6= [];
gdjs.Stage8Code.GDTutorial_95951Objects7= [];
gdjs.Stage8Code.GDGround_959501Objects1= [];
gdjs.Stage8Code.GDGround_959501Objects2= [];
gdjs.Stage8Code.GDGround_959501Objects3= [];
gdjs.Stage8Code.GDGround_959501Objects4= [];
gdjs.Stage8Code.GDGround_959501Objects5= [];
gdjs.Stage8Code.GDGround_959501Objects6= [];
gdjs.Stage8Code.GDGround_959501Objects7= [];
gdjs.Stage8Code.GDGround_959502Objects1= [];
gdjs.Stage8Code.GDGround_959502Objects2= [];
gdjs.Stage8Code.GDGround_959502Objects3= [];
gdjs.Stage8Code.GDGround_959502Objects4= [];
gdjs.Stage8Code.GDGround_959502Objects5= [];
gdjs.Stage8Code.GDGround_959502Objects6= [];
gdjs.Stage8Code.GDGround_959502Objects7= [];
gdjs.Stage8Code.GDGround_959503Objects1= [];
gdjs.Stage8Code.GDGround_959503Objects2= [];
gdjs.Stage8Code.GDGround_959503Objects3= [];
gdjs.Stage8Code.GDGround_959503Objects4= [];
gdjs.Stage8Code.GDGround_959503Objects5= [];
gdjs.Stage8Code.GDGround_959503Objects6= [];
gdjs.Stage8Code.GDGround_959503Objects7= [];
gdjs.Stage8Code.GDGround_959504Objects1= [];
gdjs.Stage8Code.GDGround_959504Objects2= [];
gdjs.Stage8Code.GDGround_959504Objects3= [];
gdjs.Stage8Code.GDGround_959504Objects4= [];
gdjs.Stage8Code.GDGround_959504Objects5= [];
gdjs.Stage8Code.GDGround_959504Objects6= [];
gdjs.Stage8Code.GDGround_959504Objects7= [];
gdjs.Stage8Code.GDGround_959505Objects1= [];
gdjs.Stage8Code.GDGround_959505Objects2= [];
gdjs.Stage8Code.GDGround_959505Objects3= [];
gdjs.Stage8Code.GDGround_959505Objects4= [];
gdjs.Stage8Code.GDGround_959505Objects5= [];
gdjs.Stage8Code.GDGround_959505Objects6= [];
gdjs.Stage8Code.GDGround_959505Objects7= [];
gdjs.Stage8Code.GDGround_959506Objects1= [];
gdjs.Stage8Code.GDGround_959506Objects2= [];
gdjs.Stage8Code.GDGround_959506Objects3= [];
gdjs.Stage8Code.GDGround_959506Objects4= [];
gdjs.Stage8Code.GDGround_959506Objects5= [];
gdjs.Stage8Code.GDGround_959506Objects6= [];
gdjs.Stage8Code.GDGround_959506Objects7= [];
gdjs.Stage8Code.GDGround_959507Objects1= [];
gdjs.Stage8Code.GDGround_959507Objects2= [];
gdjs.Stage8Code.GDGround_959507Objects3= [];
gdjs.Stage8Code.GDGround_959507Objects4= [];
gdjs.Stage8Code.GDGround_959507Objects5= [];
gdjs.Stage8Code.GDGround_959507Objects6= [];
gdjs.Stage8Code.GDGround_959507Objects7= [];
gdjs.Stage8Code.GDGround_959508Objects1= [];
gdjs.Stage8Code.GDGround_959508Objects2= [];
gdjs.Stage8Code.GDGround_959508Objects3= [];
gdjs.Stage8Code.GDGround_959508Objects4= [];
gdjs.Stage8Code.GDGround_959508Objects5= [];
gdjs.Stage8Code.GDGround_959508Objects6= [];
gdjs.Stage8Code.GDGround_959508Objects7= [];
gdjs.Stage8Code.GDGround_959509Objects1= [];
gdjs.Stage8Code.GDGround_959509Objects2= [];
gdjs.Stage8Code.GDGround_959509Objects3= [];
gdjs.Stage8Code.GDGround_959509Objects4= [];
gdjs.Stage8Code.GDGround_959509Objects5= [];
gdjs.Stage8Code.GDGround_959509Objects6= [];
gdjs.Stage8Code.GDGround_959509Objects7= [];
gdjs.Stage8Code.GDGood_9595WinObjects1= [];
gdjs.Stage8Code.GDGood_9595WinObjects2= [];
gdjs.Stage8Code.GDGood_9595WinObjects3= [];
gdjs.Stage8Code.GDGood_9595WinObjects4= [];
gdjs.Stage8Code.GDGood_9595WinObjects5= [];
gdjs.Stage8Code.GDGood_9595WinObjects6= [];
gdjs.Stage8Code.GDGood_9595WinObjects7= [];
gdjs.Stage8Code.GDVoidObjects1= [];
gdjs.Stage8Code.GDVoidObjects2= [];
gdjs.Stage8Code.GDVoidObjects3= [];
gdjs.Stage8Code.GDVoidObjects4= [];
gdjs.Stage8Code.GDVoidObjects5= [];
gdjs.Stage8Code.GDVoidObjects6= [];
gdjs.Stage8Code.GDVoidObjects7= [];
gdjs.Stage8Code.GDGood_9595GateObjects1= [];
gdjs.Stage8Code.GDGood_9595GateObjects2= [];
gdjs.Stage8Code.GDGood_9595GateObjects3= [];
gdjs.Stage8Code.GDGood_9595GateObjects4= [];
gdjs.Stage8Code.GDGood_9595GateObjects5= [];
gdjs.Stage8Code.GDGood_9595GateObjects6= [];
gdjs.Stage8Code.GDGood_9595GateObjects7= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects1= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects2= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects3= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects4= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects5= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects6= [];
gdjs.Stage8Code.GDMove_9595TriggerObjects7= [];
gdjs.Stage8Code.GDCharacterObjects1= [];
gdjs.Stage8Code.GDCharacterObjects2= [];
gdjs.Stage8Code.GDCharacterObjects3= [];
gdjs.Stage8Code.GDCharacterObjects4= [];
gdjs.Stage8Code.GDCharacterObjects5= [];
gdjs.Stage8Code.GDCharacterObjects6= [];
gdjs.Stage8Code.GDCharacterObjects7= [];
gdjs.Stage8Code.GDMove_9595CardObjects1= [];
gdjs.Stage8Code.GDMove_9595CardObjects2= [];
gdjs.Stage8Code.GDMove_9595CardObjects3= [];
gdjs.Stage8Code.GDMove_9595CardObjects4= [];
gdjs.Stage8Code.GDMove_9595CardObjects5= [];
gdjs.Stage8Code.GDMove_9595CardObjects6= [];
gdjs.Stage8Code.GDMove_9595CardObjects7= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects1= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects2= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects3= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects4= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects5= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects6= [];
gdjs.Stage8Code.GDAmount_9595MoveObjects7= [];
gdjs.Stage8Code.GDMoveObjects1= [];
gdjs.Stage8Code.GDMoveObjects2= [];
gdjs.Stage8Code.GDMoveObjects3= [];
gdjs.Stage8Code.GDMoveObjects4= [];
gdjs.Stage8Code.GDMoveObjects5= [];
gdjs.Stage8Code.GDMoveObjects6= [];
gdjs.Stage8Code.GDMoveObjects7= [];
gdjs.Stage8Code.GDSword_9595CardObjects1= [];
gdjs.Stage8Code.GDSword_9595CardObjects2= [];
gdjs.Stage8Code.GDSword_9595CardObjects3= [];
gdjs.Stage8Code.GDSword_9595CardObjects4= [];
gdjs.Stage8Code.GDSword_9595CardObjects5= [];
gdjs.Stage8Code.GDSword_9595CardObjects6= [];
gdjs.Stage8Code.GDSword_9595CardObjects7= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects1= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects2= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects3= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects4= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects5= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects6= [];
gdjs.Stage8Code.GDAmount_9595SwordObjects7= [];
gdjs.Stage8Code.GDSwordObjects1= [];
gdjs.Stage8Code.GDSwordObjects2= [];
gdjs.Stage8Code.GDSwordObjects3= [];
gdjs.Stage8Code.GDSwordObjects4= [];
gdjs.Stage8Code.GDSwordObjects5= [];
gdjs.Stage8Code.GDSwordObjects6= [];
gdjs.Stage8Code.GDSwordObjects7= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects1= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects2= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects3= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects4= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects5= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects6= [];
gdjs.Stage8Code.GDTeleport_9595CardObjects7= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects1= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects2= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects3= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects4= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects5= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects6= [];
gdjs.Stage8Code.GDAmount_9595TeleportObjects7= [];
gdjs.Stage8Code.GDTeleportObjects1= [];
gdjs.Stage8Code.GDTeleportObjects2= [];
gdjs.Stage8Code.GDTeleportObjects3= [];
gdjs.Stage8Code.GDTeleportObjects4= [];
gdjs.Stage8Code.GDTeleportObjects5= [];
gdjs.Stage8Code.GDTeleportObjects6= [];
gdjs.Stage8Code.GDTeleportObjects7= [];
gdjs.Stage8Code.GDCurserObjects1= [];
gdjs.Stage8Code.GDCurserObjects2= [];
gdjs.Stage8Code.GDCurserObjects3= [];
gdjs.Stage8Code.GDCurserObjects4= [];
gdjs.Stage8Code.GDCurserObjects5= [];
gdjs.Stage8Code.GDCurserObjects6= [];
gdjs.Stage8Code.GDCurserObjects7= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects1= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects2= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects3= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects4= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects5= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects6= [];
gdjs.Stage8Code.GDFade_9595ScreenObjects7= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects1= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects2= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects3= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects4= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects5= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects6= [];
gdjs.Stage8Code.GDSlash_9595EffectObjects7= [];
gdjs.Stage8Code.GDBackgroundObjects1= [];
gdjs.Stage8Code.GDBackgroundObjects2= [];
gdjs.Stage8Code.GDBackgroundObjects3= [];
gdjs.Stage8Code.GDBackgroundObjects4= [];
gdjs.Stage8Code.GDBackgroundObjects5= [];
gdjs.Stage8Code.GDBackgroundObjects6= [];
gdjs.Stage8Code.GDBackgroundObjects7= [];
gdjs.Stage8Code.GDMonsterObjects1= [];
gdjs.Stage8Code.GDMonsterObjects2= [];
gdjs.Stage8Code.GDMonsterObjects3= [];
gdjs.Stage8Code.GDMonsterObjects4= [];
gdjs.Stage8Code.GDMonsterObjects5= [];
gdjs.Stage8Code.GDMonsterObjects6= [];
gdjs.Stage8Code.GDMonsterObjects7= [];
gdjs.Stage8Code.GDPadObjects1= [];
gdjs.Stage8Code.GDPadObjects2= [];
gdjs.Stage8Code.GDPadObjects3= [];
gdjs.Stage8Code.GDPadObjects4= [];
gdjs.Stage8Code.GDPadObjects5= [];
gdjs.Stage8Code.GDPadObjects6= [];
gdjs.Stage8Code.GDPadObjects7= [];
gdjs.Stage8Code.GDUI_9595TextObjects1= [];
gdjs.Stage8Code.GDUI_9595TextObjects2= [];
gdjs.Stage8Code.GDUI_9595TextObjects3= [];
gdjs.Stage8Code.GDUI_9595TextObjects4= [];
gdjs.Stage8Code.GDUI_9595TextObjects5= [];
gdjs.Stage8Code.GDUI_9595TextObjects6= [];
gdjs.Stage8Code.GDUI_9595TextObjects7= [];
gdjs.Stage8Code.GDDebugObjects1= [];
gdjs.Stage8Code.GDDebugObjects2= [];
gdjs.Stage8Code.GDDebugObjects3= [];
gdjs.Stage8Code.GDDebugObjects4= [];
gdjs.Stage8Code.GDDebugObjects5= [];
gdjs.Stage8Code.GDDebugObjects6= [];
gdjs.Stage8Code.GDDebugObjects7= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects1= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects3= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects6= [];
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects7= [];
gdjs.Stage8Code.GDRenderObjects1= [];
gdjs.Stage8Code.GDRenderObjects2= [];
gdjs.Stage8Code.GDRenderObjects3= [];
gdjs.Stage8Code.GDRenderObjects4= [];
gdjs.Stage8Code.GDRenderObjects5= [];
gdjs.Stage8Code.GDRenderObjects6= [];
gdjs.Stage8Code.GDRenderObjects7= [];
gdjs.Stage8Code.GDReset_9595buttonObjects1= [];
gdjs.Stage8Code.GDReset_9595buttonObjects2= [];
gdjs.Stage8Code.GDReset_9595buttonObjects3= [];
gdjs.Stage8Code.GDReset_9595buttonObjects4= [];
gdjs.Stage8Code.GDReset_9595buttonObjects5= [];
gdjs.Stage8Code.GDReset_9595buttonObjects6= [];
gdjs.Stage8Code.GDReset_9595buttonObjects7= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects1= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects2= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects3= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects4= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects5= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects6= [];
gdjs.Stage8Code.GDUI_9595Text_95952Objects7= [];
gdjs.Stage8Code.GDRight_9595ClickObjects1= [];
gdjs.Stage8Code.GDRight_9595ClickObjects2= [];
gdjs.Stage8Code.GDRight_9595ClickObjects3= [];
gdjs.Stage8Code.GDRight_9595ClickObjects4= [];
gdjs.Stage8Code.GDRight_9595ClickObjects5= [];
gdjs.Stage8Code.GDRight_9595ClickObjects6= [];
gdjs.Stage8Code.GDRight_9595ClickObjects7= [];
gdjs.Stage8Code.GDGround_959510Objects1= [];
gdjs.Stage8Code.GDGround_959510Objects2= [];
gdjs.Stage8Code.GDGround_959510Objects3= [];
gdjs.Stage8Code.GDGround_959510Objects4= [];
gdjs.Stage8Code.GDGround_959510Objects5= [];
gdjs.Stage8Code.GDGround_959510Objects6= [];
gdjs.Stage8Code.GDGround_959510Objects7= [];
gdjs.Stage8Code.GDGround_959511Objects1= [];
gdjs.Stage8Code.GDGround_959511Objects2= [];
gdjs.Stage8Code.GDGround_959511Objects3= [];
gdjs.Stage8Code.GDGround_959511Objects4= [];
gdjs.Stage8Code.GDGround_959511Objects5= [];
gdjs.Stage8Code.GDGround_959511Objects6= [];
gdjs.Stage8Code.GDGround_959511Objects7= [];
gdjs.Stage8Code.GDSwap_9595CardObjects1= [];
gdjs.Stage8Code.GDSwap_9595CardObjects2= [];
gdjs.Stage8Code.GDSwap_9595CardObjects3= [];
gdjs.Stage8Code.GDSwap_9595CardObjects4= [];
gdjs.Stage8Code.GDSwap_9595CardObjects5= [];
gdjs.Stage8Code.GDSwap_9595CardObjects6= [];
gdjs.Stage8Code.GDSwap_9595CardObjects7= [];
gdjs.Stage8Code.GDBomb_9595CardObjects1= [];
gdjs.Stage8Code.GDBomb_9595CardObjects2= [];
gdjs.Stage8Code.GDBomb_9595CardObjects3= [];
gdjs.Stage8Code.GDBomb_9595CardObjects4= [];
gdjs.Stage8Code.GDBomb_9595CardObjects5= [];
gdjs.Stage8Code.GDBomb_9595CardObjects6= [];
gdjs.Stage8Code.GDBomb_9595CardObjects7= [];
gdjs.Stage8Code.GDNPC_95951Objects1= [];
gdjs.Stage8Code.GDNPC_95951Objects2= [];
gdjs.Stage8Code.GDNPC_95951Objects3= [];
gdjs.Stage8Code.GDNPC_95951Objects4= [];
gdjs.Stage8Code.GDNPC_95951Objects5= [];
gdjs.Stage8Code.GDNPC_95951Objects6= [];
gdjs.Stage8Code.GDNPC_95951Objects7= [];
gdjs.Stage8Code.GDBad_9595WinObjects1= [];
gdjs.Stage8Code.GDBad_9595WinObjects2= [];
gdjs.Stage8Code.GDBad_9595WinObjects3= [];
gdjs.Stage8Code.GDBad_9595WinObjects4= [];
gdjs.Stage8Code.GDBad_9595WinObjects5= [];
gdjs.Stage8Code.GDBad_9595WinObjects6= [];
gdjs.Stage8Code.GDBad_9595WinObjects7= [];
gdjs.Stage8Code.GDBad_9595GateObjects1= [];
gdjs.Stage8Code.GDBad_9595GateObjects2= [];
gdjs.Stage8Code.GDBad_9595GateObjects3= [];
gdjs.Stage8Code.GDBad_9595GateObjects4= [];
gdjs.Stage8Code.GDBad_9595GateObjects5= [];
gdjs.Stage8Code.GDBad_9595GateObjects6= [];
gdjs.Stage8Code.GDBad_9595GateObjects7= [];
gdjs.Stage8Code.GDWeight_9595PadObjects1= [];
gdjs.Stage8Code.GDWeight_9595PadObjects2= [];
gdjs.Stage8Code.GDWeight_9595PadObjects3= [];
gdjs.Stage8Code.GDWeight_9595PadObjects4= [];
gdjs.Stage8Code.GDWeight_9595PadObjects5= [];
gdjs.Stage8Code.GDWeight_9595PadObjects6= [];
gdjs.Stage8Code.GDWeight_9595PadObjects7= [];
gdjs.Stage8Code.GDNPC_95952Objects1= [];
gdjs.Stage8Code.GDNPC_95952Objects2= [];
gdjs.Stage8Code.GDNPC_95952Objects3= [];
gdjs.Stage8Code.GDNPC_95952Objects4= [];
gdjs.Stage8Code.GDNPC_95952Objects5= [];
gdjs.Stage8Code.GDNPC_95952Objects6= [];
gdjs.Stage8Code.GDNPC_95952Objects7= [];
gdjs.Stage8Code.GDCard_9595UIObjects1= [];
gdjs.Stage8Code.GDCard_9595UIObjects2= [];
gdjs.Stage8Code.GDCard_9595UIObjects3= [];
gdjs.Stage8Code.GDCard_9595UIObjects4= [];
gdjs.Stage8Code.GDCard_9595UIObjects5= [];
gdjs.Stage8Code.GDCard_9595UIObjects6= [];
gdjs.Stage8Code.GDCard_9595UIObjects7= [];
gdjs.Stage8Code.GDSmokeObjects1= [];
gdjs.Stage8Code.GDSmokeObjects2= [];
gdjs.Stage8Code.GDSmokeObjects3= [];
gdjs.Stage8Code.GDSmokeObjects4= [];
gdjs.Stage8Code.GDSmokeObjects5= [];
gdjs.Stage8Code.GDSmokeObjects6= [];
gdjs.Stage8Code.GDSmokeObjects7= [];


gdjs.Stage8Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17629196);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Looped Ambince sound.mp3", 1, true, 10, 1);
}}

}


};gdjs.Stage8Code.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Tutorial";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9174020);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Ambient - Dream World.mp3", 1, true, 25, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Stage8Code.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Stage8Code.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].activateBehavior("SmoothCamera", true);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].setPosition((( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getPointX("Point_Fix")) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getPointX("Point_Fix")) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getPointX("Point_Fix")),(( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getPointY("Point_Fix")) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getPointY("Point_Fix")) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getPointY("Point_Fix")));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].activateBehavior("SmoothCamera", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Stage8Code.GDVoidObjects5);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects5[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.Stage8Code.GDWeight_9595PadObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDWeight_9595PadObjects5[i].getBehavior("Scale").setScale(0.8);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Scale").setScale(0.9);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDVoidObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDVoidObjects5[i].rotate(10, runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDVoidObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDVoidObjects5[i].getBehavior("Scale").setScale(0.9);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Reset_button"), gdjs.Stage8Code.GDReset_9595buttonObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Stage8Code.GDVoidObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDReset_9595buttonObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDReset_9595buttonObjects5[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDVoidObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDVoidObjects5[i].getBehavior("Opacity").setOpacity(180);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bad_Win"), gdjs.Stage8Code.GDBad_9595WinObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.Stage8Code.GDGood_9595WinObjects5);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Stage8Code.GDGood_9595WinObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595WinObjects5[i].hide();
}
}{for(var i = 0, len = gdjs.Stage8Code.GDBad_9595WinObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBad_9595WinObjects5[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Stage8Code.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Stage8Code.GDMoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Smoke"), gdjs.Stage8Code.GDSmokeObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects5[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects5[i].setZOrder(9999);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].setZOrder(999);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].setZOrder(999);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].setZOrder(999);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSmokeObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSmokeObjects5[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMoveObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].setZOrder(99999);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects5[i].setZOrder(999999);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Stage8Code.GDMoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects5[i].setPosition((( gdjs.Stage8Code.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMoveObjects5[i].setPosition((( gdjs.Stage8Code.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects5[i].setPosition((( gdjs.Stage8Code.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDBomb_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Stage8Code.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Stage8Code.GDMoveObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDMoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMoveObjects5[i].setPosition((( gdjs.Stage8Code.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDBomb_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDBomb_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects5[i].setPosition((( gdjs.Stage8Code.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDBomb_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDBomb_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDBomb_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects5[i].setPosition((( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].setPosition((( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects5[i].setPosition((( gdjs.Stage8Code.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSwap_9595CardObjects5[0].getPointX("Contact")),(( gdjs.Stage8Code.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSwap_9595CardObjects5[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].setPosition((( gdjs.Stage8Code.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSwap_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDSwap_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSwap_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDBomb_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Stage8Code.GDAmount_9595MoveObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects5[i].setPosition((( gdjs.Stage8Code.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDMove_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects5[i].getBehavior("Text").setText(((gdjs.Stage8Code.GDMove_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Stage8Code.GDMove_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].setPosition((( gdjs.Stage8Code.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDSword_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].getBehavior("Text").setText(((gdjs.Stage8Code.GDSword_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Stage8Code.GDSword_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].setPosition((( gdjs.Stage8Code.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects5[0].getPointX("Amount")),(( gdjs.Stage8Code.GDTeleport_9595CardObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects5[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].getBehavior("Text").setText(((gdjs.Stage8Code.GDTeleport_9595CardObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Stage8Code.GDTeleport_9595CardObjects5[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects4);
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDMove_9595CardObjects4[i].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDMove_9595CardObjects4[i].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Stage8Code.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.Stage8Code.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595CardObjects4[0].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDSword_9595CardObjects4[i].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDSword_9595CardObjects4[i].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Stage8Code.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Stage8Code.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.Stage8Code.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects4[0].getCenterYInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects4[0].getCenterYInScene()) + 480, 0.05));
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDBomb_95959595CardObjects5Objects = Hashtable.newFrom({"Move_Card": gdjs.Stage8Code.GDMove_9595CardObjects5, "Sword_Card": gdjs.Stage8Code.GDSword_9595CardObjects5, "Teleport_Card": gdjs.Stage8Code.GDTeleport_9595CardObjects5, "TeleportBlade_Card": gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5, "Swap_Card": gdjs.Stage8Code.GDSwap_9595CardObjects5, "Bomb_Card": gdjs.Stage8Code.GDBomb_9595CardObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDBomb_95959595CardObjects5Objects = Hashtable.newFrom({"Move_Card": gdjs.Stage8Code.GDMove_9595CardObjects5, "Sword_Card": gdjs.Stage8Code.GDSword_9595CardObjects5, "Teleport_Card": gdjs.Stage8Code.GDTeleport_9595CardObjects5, "TeleportBlade_Card": gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5, "Swap_Card": gdjs.Stage8Code.GDSwap_9595CardObjects5, "Bomb_Card": gdjs.Stage8Code.GDBomb_9595CardObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546Stage8Code_9546GDVoidObjects5ObjectsGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546Stage8Code_9546GDPadObjects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546Stage8Code_9546GDBad_95959595GateObjects5Objects = Hashtable.newFrom({"Ground_01": gdjs.Stage8Code.GDGround_959501Objects5, "Ground_02": gdjs.Stage8Code.GDGround_959502Objects5, "Ground_03": gdjs.Stage8Code.GDGround_959503Objects5, "Ground_04": gdjs.Stage8Code.GDGround_959504Objects5, "Ground_05": gdjs.Stage8Code.GDGround_959505Objects5, "Ground_06": gdjs.Stage8Code.GDGround_959506Objects5, "Ground_07": gdjs.Stage8Code.GDGround_959507Objects5, "Ground_08": gdjs.Stage8Code.GDGround_959508Objects5, "Ground_09": gdjs.Stage8Code.GDGround_959509Objects5, "Good_Gate": gdjs.Stage8Code.GDGood_9595GateObjects5, "Void": gdjs.Stage8Code.GDVoidObjects5, "Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects5, "Pad": gdjs.Stage8Code.GDPadObjects5, "Ground_10": gdjs.Stage8Code.GDGround_959510Objects5, "Ground_11": gdjs.Stage8Code.GDGround_959511Objects5, "Bad_Gate": gdjs.Stage8Code.GDBad_9595GateObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546Stage8Code_9546GDVoidObjects5ObjectsGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546Stage8Code_9546GDPadObjects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546Stage8Code_9546GDBad_95959595GateObjects5Objects = Hashtable.newFrom({"Ground_01": gdjs.Stage8Code.GDGround_959501Objects5, "Ground_02": gdjs.Stage8Code.GDGround_959502Objects5, "Ground_03": gdjs.Stage8Code.GDGround_959503Objects5, "Ground_04": gdjs.Stage8Code.GDGround_959504Objects5, "Ground_05": gdjs.Stage8Code.GDGround_959505Objects5, "Ground_06": gdjs.Stage8Code.GDGround_959506Objects5, "Ground_07": gdjs.Stage8Code.GDGround_959507Objects5, "Ground_08": gdjs.Stage8Code.GDGround_959508Objects5, "Ground_09": gdjs.Stage8Code.GDGround_959509Objects5, "Good_Gate": gdjs.Stage8Code.GDGood_9595GateObjects5, "Void": gdjs.Stage8Code.GDVoidObjects5, "Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects5, "Pad": gdjs.Stage8Code.GDPadObjects5, "Ground_10": gdjs.Stage8Code.GDGround_959510Objects5, "Ground_11": gdjs.Stage8Code.GDGround_959511Objects5, "Bad_Gate": gdjs.Stage8Code.GDBad_9595GateObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCurserObjects5Objects = Hashtable.newFrom({"Curser": gdjs.Stage8Code.GDCurserObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects5});
gdjs.Stage8Code.asyncCallback17881276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects6);

{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects6.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects6[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects6.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects6[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.5, "bounce", 0.1, false, false);
}
}}
gdjs.Stage8Code.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage8Code.GDCurserObjects5) asyncObjectsList.addObject("Curser", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17881276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDBomb_95959595CardObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects5[k] = gdjs.Stage8Code.GDMove_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects5[k] = gdjs.Stage8Code.GDSword_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects5[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[k] = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSwap_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSwap_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSwap_9595CardObjects5[k] = gdjs.Stage8Code.GDSwap_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSwap_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDBomb_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDBomb_9595CardObjects5[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDBomb_9595CardObjects5[k] = gdjs.Stage8Code.GDBomb_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDBomb_9595CardObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects5[k] = gdjs.Stage8Code.GDMove_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects5[k] = gdjs.Stage8Code.GDSword_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects5[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[k] = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSwap_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSwap_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSwap_9595CardObjects5[k] = gdjs.Stage8Code.GDSwap_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSwap_9595CardObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDBomb_9595CardObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDBomb_9595CardObjects5[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDBomb_9595CardObjects5[k] = gdjs.Stage8Code.GDBomb_9595CardObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDBomb_9595CardObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8210740);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDBomb_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDMove_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDSwap_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDSword_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDTeleport_9595CardObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Swipe.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects5ObjectsGDgdjs_9546Stage8Code_9546GDBomb_95959595CardObjects5Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDBomb_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDMove_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDSwap_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDSword_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5 */
/* Reuse gdjs.Stage8Code.GDTeleport_9595CardObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.Stage8Code.GDBad_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.Stage8Code.GDGround_959501Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.Stage8Code.GDGround_959502Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.Stage8Code.GDGround_959503Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.Stage8Code.GDGround_959504Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.Stage8Code.GDGround_959505Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.Stage8Code.GDGround_959506Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.Stage8Code.GDGround_959507Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.Stage8Code.GDGround_959508Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.Stage8Code.GDGround_959509Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.Stage8Code.GDGround_959510Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.Stage8Code.GDGround_959511Objects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Stage8Code.GDPadObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Stage8Code.GDVoidObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546Stage8Code_9546GDVoidObjects5ObjectsGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546Stage8Code_9546GDPadObjects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546Stage8Code_9546GDBad_95959595GateObjects5Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDBad_9595GateObjects5 */
/* Reuse gdjs.Stage8Code.GDGood_9595GateObjects5 */
/* Reuse gdjs.Stage8Code.GDGround_959501Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959502Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959503Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959504Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959505Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959506Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959507Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959508Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959509Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959510Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959511Objects5 */
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects5 */
/* Reuse gdjs.Stage8Code.GDPadObjects5 */
/* Reuse gdjs.Stage8Code.GDVoidObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDGround_959501Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959501Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959502Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959502Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959503Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959503Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959504Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959504Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959505Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959505Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959506Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959506Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959507Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959507Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959508Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959508Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959509Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959509Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGood_9595GateObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDVoidObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDVoidObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDPadObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDPadObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959510Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959510Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959511Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959511Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDBad_9595GateObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBad_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1.1, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.Stage8Code.GDBad_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.Stage8Code.GDGround_959501Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.Stage8Code.GDGround_959502Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.Stage8Code.GDGround_959503Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.Stage8Code.GDGround_959504Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.Stage8Code.GDGround_959505Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.Stage8Code.GDGround_959506Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.Stage8Code.GDGround_959507Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.Stage8Code.GDGround_959508Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.Stage8Code.GDGround_959509Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.Stage8Code.GDGround_959510Objects5);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.Stage8Code.GDGround_959511Objects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Stage8Code.GDPadObjects5);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Stage8Code.GDVoidObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGround_9595959501Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959502Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959503Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959504Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959505Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959506Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959507Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959508Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959509Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGood_95959595GateObjects5ObjectsGDgdjs_9546Stage8Code_9546GDVoidObjects5ObjectsGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5ObjectsGDgdjs_9546Stage8Code_9546GDPadObjects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959510Objects5ObjectsGDgdjs_9546Stage8Code_9546GDGround_9595959511Objects5ObjectsGDgdjs_9546Stage8Code_9546GDBad_95959595GateObjects5Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDBad_9595GateObjects5 */
/* Reuse gdjs.Stage8Code.GDGood_9595GateObjects5 */
/* Reuse gdjs.Stage8Code.GDGround_959501Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959502Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959503Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959504Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959505Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959506Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959507Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959508Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959509Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959510Objects5 */
/* Reuse gdjs.Stage8Code.GDGround_959511Objects5 */
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects5 */
/* Reuse gdjs.Stage8Code.GDPadObjects5 */
/* Reuse gdjs.Stage8Code.GDVoidObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDGround_959501Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959501Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959502Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959502Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959503Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959503Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959504Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959504Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959505Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959505Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959506Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959506Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959507Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959507Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959508Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959508Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959509Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959509Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGood_9595GateObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDVoidObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDVoidObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDPadObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDPadObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959510Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959510Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDGround_959511Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDGround_959511Objects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDBad_9595GateObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDBad_9595GateObjects5[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCurserObjects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects5[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects5.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCurserObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCurserObjects5[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCurserObjects5[k] = gdjs.Stage8Code.GDCurserObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCurserObjects5.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCurserObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects5[i].getBehavior("Animation").setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects5[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.4, "bounce", 0.1, false, false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16144236);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600924);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMonsterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMonsterObjects5[k] = gdjs.Stage8Code.GDMonsterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMonsterObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMonsterObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMonsterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMonsterObjects5[k] = gdjs.Stage8Code.GDMonsterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMonsterObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMonsterObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.Stage8Code.GDSlash_9595EffectObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSlash_9595EffectObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSlash_9595EffectObjects5[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSlash_9595EffectObjects5[k] = gdjs.Stage8Code.GDSlash_9595EffectObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSlash_9595EffectObjects5.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDSlash_9595EffectObjects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDSlash_9595EffectObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSlash_9595EffectObjects5[i].getBehavior("Tween").addObjectScaleTween3("Slash", 1.2, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.Stage8Code.GDSlash_9595EffectObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSlash_9595EffectObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSlash_9595EffectObjects4[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSlash_9595EffectObjects4[k] = gdjs.Stage8Code.GDSlash_9595EffectObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSlash_9595EffectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDSlash_9595EffectObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDSlash_9595EffectObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSlash_9595EffectObjects4[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects6Objects = Hashtable.newFrom({"NPC_1": gdjs.Stage8Code.GDNPC_95951Objects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects5});
gdjs.Stage8Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects6);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects6Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects6 */
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects6.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects6Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects5});
gdjs.Stage8Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects6);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects6);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects6Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects6 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects6.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5Objects = Hashtable.newFrom({"NPC_1": gdjs.Stage8Code.GDNPC_95951Objects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects6Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects6});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5Objects = Hashtable.newFrom({"NPC_1": gdjs.Stage8Code.GDNPC_95951Objects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects5});
gdjs.Stage8Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects6);
gdjs.copyArray(gdjs.Stage8Code.GDRenderObjects5, gdjs.Stage8Code.GDRenderObjects6);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects6Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects6Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects6 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects6.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects6[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
/* Reuse gdjs.Stage8Code.GDRenderObjects5 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects5 */
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Stage8Code.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects5[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects5[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects5.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects5 */
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects5[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects5[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


};gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Stage8Code.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects5);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects5[i].getBehavior("Text").setText("TeleportBlade");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Stage8Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects5);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects5[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects5[i].getBehavior("Text").setText("Swap");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.Stage8Code.eventsList11 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects4[k] = gdjs.Stage8Code.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Stage8Code.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Stage8Code.GDMoveObjects4);
/* Reuse gdjs.Stage8Code.GDMove_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMoveObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects4[k] = gdjs.Stage8Code.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Stage8Code.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Stage8Code.GDMoveObjects4);
/* Reuse gdjs.Stage8Code.GDMove_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMoveObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595MoveObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects4);
/* Reuse gdjs.Stage8Code.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Stage8Code.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Stage8Code.GDTeleportObjects4);
/* Reuse gdjs.Stage8Code.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects4[k] = gdjs.Stage8Code.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects4);
/* Reuse gdjs.Stage8Code.GDSword_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects4[i].getVariableNumber(gdjs.Stage8Code.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects4[k] = gdjs.Stage8Code.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Stage8Code.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Stage8Code.GDSwordObjects4);
/* Reuse gdjs.Stage8Code.GDSword_9595CardObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


};gdjs.Stage8Code.eventsList12 = function(runtimeScene) {

{


gdjs.Stage8Code.eventsList1(runtimeScene);
}


{


gdjs.Stage8Code.eventsList2(runtimeScene);
}


{


gdjs.Stage8Code.eventsList4(runtimeScene);
}


{


gdjs.Stage8Code.eventsList8(runtimeScene);
}


{


gdjs.Stage8Code.eventsList11(runtimeScene);
}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects4, "NPC_1": gdjs.Stage8Code.GDNPC_95951Objects4, "NPC_2": gdjs.Stage8Code.GDNPC_95952Objects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.Stage8Code.GDMonsterObjects4});
gdjs.Stage8Code.asyncCallback17570068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Stage8Code.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17570068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17478396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Stage8Code.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17478396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17591172 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Stage8Code.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17591172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17590828 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Stage8Code.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17590828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17580308 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Stage8Code.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17580308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17588068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Stage8Code.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17588068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17517908 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Stage8Code.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17517908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17555844 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Stage8Code.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17555844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17587268 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Stage8Code.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17587268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17589124 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Stage8Code.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17589124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList21(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Stage8Code.GDFade_9595ScreenObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects4, "NPC_1": gdjs.Stage8Code.GDNPC_95951Objects4, "NPC_2": gdjs.Stage8Code.GDNPC_95952Objects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGood_95959595WinObjects4Objects = Hashtable.newFrom({"Good_Win": gdjs.Stage8Code.GDGood_9595WinObjects4});
gdjs.Stage8Code.asyncCallback17524412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Stage8Code.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17524412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17531004 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Stage8Code.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17531004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17547340 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Stage8Code.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17547340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17585228 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Stage8Code.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17585228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17569212 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Stage8Code.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17569212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17482412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Stage8Code.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17482412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17653996 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Stage8Code.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17653996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17605492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Stage8Code.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17605492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17582204 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Stage8Code.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17582204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17491628 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Stage8Code.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17491628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17548388 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}}
gdjs.Stage8Code.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17548388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects4, gdjs.Stage8Code.GDFade_9595ScreenObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects5[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects5[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList33(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Stage8Code.GDFade_9595ScreenObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.Stage8Code.GDGood_9595WinObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDGood_9595GateObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDGood_9595GateObjects4[i].getBehavior("Opacity").getOpacity() > 200 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDGood_9595GateObjects4[k] = gdjs.Stage8Code.GDGood_9595GateObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDGood_9595GateObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDGood_95959595WinObjects4Objects, 64, false);
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Stage8Code.GDFade_9595ScreenObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.asyncCallback17590284 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Stage8Code.eventsList37 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17590284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17660820 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Stage8Code.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17660820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17594188 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Stage8Code.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17594188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17606556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Stage8Code.eventsList40 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17606556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17614460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Stage8Code.eventsList41 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17614460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17565716 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Stage8Code.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17565716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17474948 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Stage8Code.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17474948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17651364 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Stage8Code.eventsList44 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17651364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17544500 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Stage8Code.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17544500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.asyncCallback17671588 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Stage8Code.eventsList46 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17671588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList37(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList38(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList40(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList44(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Stage8Code.GDFade_9595ScreenObjects3, gdjs.Stage8Code.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects4[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList45(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Stage8Code.GDFade_9595ScreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDFade_9595ScreenObjects3[k] = gdjs.Stage8Code.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Stage8Code.GDFade_9595ScreenObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDFade_9595ScreenObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDFade_9595ScreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.eventsList49 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMonsterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMonsterObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMonsterObjects4[k] = gdjs.Stage8Code.GDMonsterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMonsterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Stage8Code.GDFade_9595ScreenObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDFade_9595ScreenObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDFade_9595ScreenObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList36(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Stage8Code.GDRenderObjects4});
gdjs.Stage8Code.eventsList50 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 0, "linear", 0.05, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Stage8Code.GDCharacterObjects4_1final.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects4_1final.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects4_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4, gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4, gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4, gdjs.Stage8Code.GDNPC_95952Objects5);

for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects5[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects5[k] = gdjs.Stage8Code.GDCharacterObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects5[k] = gdjs.Stage8Code.GDNPC_95951Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects5.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects5[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects5[k] = gdjs.Stage8Code.GDNPC_95952Objects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects5.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Stage8Code.GDCharacterObjects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDCharacterObjects4_1final.indexOf(gdjs.Stage8Code.GDCharacterObjects5[j]) === -1 )
            gdjs.Stage8Code.GDCharacterObjects4_1final.push(gdjs.Stage8Code.GDCharacterObjects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95951Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95951Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95951Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95951Objects4_1final.push(gdjs.Stage8Code.GDNPC_95951Objects5[j]);
    }
    for (let j = 0, jLen = gdjs.Stage8Code.GDNPC_95952Objects5.length; j < jLen ; ++j) {
        if ( gdjs.Stage8Code.GDNPC_95952Objects4_1final.indexOf(gdjs.Stage8Code.GDNPC_95952Objects5[j]) === -1 )
            gdjs.Stage8Code.GDNPC_95952Objects4_1final.push(gdjs.Stage8Code.GDNPC_95952Objects5[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Stage8Code.GDCharacterObjects4_1final, gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(gdjs.Stage8Code.GDNPC_95951Objects4_1final, gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(gdjs.Stage8Code.GDNPC_95952Objects4_1final, gdjs.Stage8Code.GDNPC_95952Objects4);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.Stage8Code.GDRight_9595ClickObjects4);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.Stage8Code.GDUI_9595TextObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDUI_9595TextObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDUI_9595TextObjects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRight_9595ClickObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRight_9595ClickObjects4[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.Stage8Code.GDRight_9595ClickObjects3);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.Stage8Code.GDUI_9595TextObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDUI_9595TextObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDUI_9595TextObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRight_9595ClickObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDRight_9595ClickObjects3[i].hide();
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects5ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects5, "NPC_1": gdjs.Stage8Code.GDNPC_95951Objects5, "NPC_2": gdjs.Stage8Code.GDNPC_95952Objects5});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDPadObjects5Objects = Hashtable.newFrom({"Pad": gdjs.Stage8Code.GDPadObjects5});
gdjs.Stage8Code.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17473404);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}}

}


};gdjs.Stage8Code.eventsList52 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Stage8Code.GDPadObjects4);

for (gdjs.Stage8Code.forEachIndex5 = 0;gdjs.Stage8Code.forEachIndex5 < gdjs.Stage8Code.GDPadObjects4.length;++gdjs.Stage8Code.forEachIndex5) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);
gdjs.Stage8Code.GDPadObjects5.length = 0;


gdjs.Stage8Code.forEachTemporary5 = gdjs.Stage8Code.GDPadObjects4[gdjs.Stage8Code.forEachIndex5];
gdjs.Stage8Code.GDPadObjects5.push(gdjs.Stage8Code.forEachTemporary5);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDPadObjects5.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDPadObjects5[i].getBehavior("Animation").getAnimationName() == "Inactive" ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDPadObjects5[k] = gdjs.Stage8Code.GDPadObjects5[i];
        ++k;
    }
}
gdjs.Stage8Code.GDPadObjects5.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects5ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects5ObjectsGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects5Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDPadObjects5Objects, false, runtimeScene, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Stage8Code.GDPadObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDPadObjects5[i].getBehavior("Animation").setAnimationName("Active");
}
}
{ //Subevents: 
gdjs.Stage8Code.eventsList51(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


{



}


};gdjs.Stage8Code.eventsList53 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(3.1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(9);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(6.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects3[i].getBehavior("Scale").setScale(12);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects4Objects = Hashtable.newFrom({"Move_Card": gdjs.Stage8Code.GDMove_9595CardObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCurserObjects4Objects = Hashtable.newFrom({"Curser": gdjs.Stage8Code.GDCurserObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects3});
gdjs.Stage8Code.eventsList54 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects4[k] = gdjs.Stage8Code.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595CardObjects4[k] = gdjs.Stage8Code.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600004);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCurserObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17599684);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects4);
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Moveing.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDMove_9595CardObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects3[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17694652);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects3);
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects4Objects = Hashtable.newFrom({"Teleport_Card": gdjs.Stage8Code.GDTeleport_9595CardObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSmokeObjects5Objects = Hashtable.newFrom({"Smoke": gdjs.Stage8Code.GDSmokeObjects5});
gdjs.Stage8Code.asyncCallback17620180 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects5);
gdjs.Stage8Code.GDSmokeObjects5.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSmokeObjects5Objects, (( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].hide(false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].hide(false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].returnVariable(gdjs.Stage8Code.GDTeleport_9595CardObjects5[i].getVariables().getFromIndex(0)).sub(1);
}
}}
gdjs.Stage8Code.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage8Code.GDCharacterObjects4) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.Stage8Code.GDNPC_95951Objects4) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.Stage8Code.GDNPC_95952Objects4) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17620180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects4Objects = Hashtable.newFrom({"Swap_Card": gdjs.Stage8Code.GDSwap_9595CardObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.Stage8Code.GDNPC_95951Objects4});
gdjs.Stage8Code.eventsList56 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17554812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects4});
gdjs.Stage8Code.eventsList57 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17619252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects4});
gdjs.Stage8Code.eventsList58 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17615948);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.Stage8Code.GDNPC_95951Objects4});
gdjs.Stage8Code.eventsList59 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17484196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects4});
gdjs.Stage8Code.eventsList60 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17608228);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects4});
gdjs.Stage8Code.eventsList61 = function(runtimeScene) {

{

/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17627196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects3});
gdjs.Stage8Code.eventsList62 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleport_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDTeleport_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleport_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17653100);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17695108);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].hide();
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].hide();
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].hide();
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17613716);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDSwap_9595CardObjects4[k] = gdjs.Stage8Code.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSwap_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSwap_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDSwap_9595CardObjects4[k] = gdjs.Stage8Code.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSwap_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17546188);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17476508);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList56(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17685636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList57(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17479260);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList58(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595951Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17474636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList59(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17633124);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList60(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17579292);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSwap_9595CardObjects4[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList61(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects3[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17609988);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects4Objects = Hashtable.newFrom({"Sword_Card": gdjs.Stage8Code.GDSword_9595CardObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.Stage8Code.GDMonsterObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSlash_95959595EffectObjects4Objects = Hashtable.newFrom({"Slash_Effect": gdjs.Stage8Code.GDSlash_9595EffectObjects4});
gdjs.Stage8Code.asyncCallback17665004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.Stage8Code.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage8Code.GDMonsterObjects4) asyncObjectsList.addObject("Monster", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17665004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects4Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects = Hashtable.newFrom({"Monster": gdjs.Stage8Code.GDMonsterObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSlash_95959595EffectObjects4Objects = Hashtable.newFrom({"Slash_Effect": gdjs.Stage8Code.GDSlash_9595EffectObjects4});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSmokeObjects5Objects = Hashtable.newFrom({"Smoke": gdjs.Stage8Code.GDSmokeObjects5});
gdjs.Stage8Code.asyncCallback17537804 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects5);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects5);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects5);
gdjs.Stage8Code.GDSmokeObjects5.length = 0;

{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMove_9595TriggerObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDMove_9595TriggerObjects5[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSmokeObjects5Objects, (( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getCenterXInScene()) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getCenterXInScene()), (( gdjs.Stage8Code.GDNPC_95952Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDNPC_95951Objects5.length === 0 ) ? (( gdjs.Stage8Code.GDCharacterObjects5.length === 0 ) ? 0 :gdjs.Stage8Code.GDCharacterObjects5[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95951Objects5[0].getCenterYInScene()) :gdjs.Stage8Code.GDNPC_95952Objects5[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects5[i].hide(false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects5[i].hide(false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects5[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects5[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects5.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects5[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.Stage8Code.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Stage8Code.GDCharacterObjects4) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.Stage8Code.GDMonsterObjects4) asyncObjectsList.addObject("Monster", obj);
for (const obj of gdjs.Stage8Code.GDMove_9595TriggerObjects4) asyncObjectsList.addObject("Move_Trigger", obj);
for (const obj of gdjs.Stage8Code.GDNPC_95951Objects4) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.Stage8Code.GDNPC_95952Objects4) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Stage8Code.asyncCallback17537804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Stage8Code.GDMove_9595TriggerObjects3});
gdjs.Stage8Code.eventsList65 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSword_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects4[k] = gdjs.Stage8Code.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDSword_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDSword_9595CardObjects4[k] = gdjs.Stage8Code.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDSword_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17507548);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17665324);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDMonsterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);
gdjs.Stage8Code.GDSlash_9595EffectObjects4.length = 0;

{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].returnVariable(gdjs.Stage8Code.GDSword_9595CardObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSlash_95959595EffectObjects4Objects, (( gdjs.Stage8Code.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMonsterObjects4[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.Stage8Code.eventsList63(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17466468);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[k] = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17529924);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMonsterObjects4Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects4[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects4[k] = gdjs.Stage8Code.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects4[k] = gdjs.Stage8Code.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects4[k] = gdjs.Stage8Code.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects4[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17467148);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects4 */
/* Reuse gdjs.Stage8Code.GDMonsterObjects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects4 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects4 */
gdjs.Stage8Code.GDSlash_9595EffectObjects4.length = 0;

{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects4[i].hide();
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects4[i].hide();
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects4[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSlash_95959595EffectObjects4Objects, (( gdjs.Stage8Code.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMonsterObjects4[0].getCenterXInScene()), (( gdjs.Stage8Code.GDMonsterObjects4.length === 0 ) ? 0 :gdjs.Stage8Code.GDMonsterObjects4[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.Stage8Code.eventsList64(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects3[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17624076);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Stage8Code.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects3);
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Stage8Code.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects3Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.Stage8Code.GDTeleportBlade_9595CardObjects3});
gdjs.Stage8Code.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10633164);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects3);
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDTeleportBlade_95959595CardObjects3Objects, (( gdjs.Stage8Code.GDSword_9595CardObjects3.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects3[0].getCenterXInScene()), (( gdjs.Stage8Code.GDSword_9595CardObjects3.length === 0 ) ? 0 :gdjs.Stage8Code.GDSword_9595CardObjects3[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects3[i].returnVariable(gdjs.Stage8Code.GDSword_9595CardObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects3[i].returnVariable(gdjs.Stage8Code.GDTeleport_9595CardObjects3[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects2Objects = Hashtable.newFrom({"Swap_Card": gdjs.Stage8Code.GDSwap_9595CardObjects2});
gdjs.Stage8Code.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17497196);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects2);
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects2 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects2);
gdjs.Stage8Code.GDSwap_9595CardObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDSwap_95959595CardObjects2Objects, (( gdjs.Stage8Code.GDTeleport_9595CardObjects2.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects2[0].getCenterXInScene()), (( gdjs.Stage8Code.GDTeleport_9595CardObjects2.length === 0 ) ? 0 :gdjs.Stage8Code.GDTeleport_9595CardObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects2[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects2[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].returnVariable(gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects2[i].returnVariable(gdjs.Stage8Code.GDMove_9595CardObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.Stage8Code.eventsList68 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects3[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects3[k] = gdjs.Stage8Code.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects3[k] = gdjs.Stage8Code.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects3[k] = gdjs.Stage8Code.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects3.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects3 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects3[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList66(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects2[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects2[k] = gdjs.Stage8Code.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects2[k] = gdjs.Stage8Code.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects2[k] = gdjs.Stage8Code.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects2[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects2[k] = gdjs.Stage8Code.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects2[k] = gdjs.Stage8Code.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects2[k] = gdjs.Stage8Code.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDCharacterObjects2[i].getVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDCharacterObjects2[k] = gdjs.Stage8Code.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95951Objects2[k] = gdjs.Stage8Code.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Stage8Code.GDNPC_95952Objects2[k] = gdjs.Stage8Code.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDNPC_95952Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDCharacterObjects2 */
/* Reuse gdjs.Stage8Code.GDNPC_95951Objects2 */
/* Reuse gdjs.Stage8Code.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects2[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false);
}
}
{ //Subevents
gdjs.Stage8Code.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.Stage8Code.eventsList69 = function(runtimeScene) {

{


gdjs.Stage8Code.eventsList52(runtimeScene);
}


{


gdjs.Stage8Code.eventsList53(runtimeScene);
}


{


gdjs.Stage8Code.eventsList54(runtimeScene);
}


{


gdjs.Stage8Code.eventsList62(runtimeScene);
}


{


gdjs.Stage8Code.eventsList65(runtimeScene);
}


{


gdjs.Stage8Code.eventsList68(runtimeScene);
}


};gdjs.Stage8Code.eventsList70 = function(runtimeScene) {

{


gdjs.Stage8Code.eventsList49(runtimeScene);
}


{


gdjs.Stage8Code.eventsList50(runtimeScene);
}


{


gdjs.Stage8Code.eventsList69(runtimeScene);
}


};gdjs.Stage8Code.eventsList71 = function(runtimeScene) {

{


gdjs.Stage8Code.eventsList12(runtimeScene);
}


{


gdjs.Stage8Code.eventsList70(runtimeScene);
}


};gdjs.Stage8Code.mapOfEmptyGDMonsterObjects = Hashtable.newFrom({"Monster": []});
gdjs.Stage8Code.mapOfEmptyGDMonsterObjects = Hashtable.newFrom({"Monster": []});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects2});
gdjs.Stage8Code.eventsList72 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects2);
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMonsterObjects2[i].getZOrder() == 24 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMonsterObjects2[k] = gdjs.Stage8Code.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMonsterObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 200, "linear", 0.5, false);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects2Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects2});
gdjs.Stage8Code.eventsList73 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects2);
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects2Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMonsterObjects2[i].getZOrder() == 25 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMonsterObjects2[k] = gdjs.Stage8Code.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMonsterObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDMonsterObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 200, "linear", 0.5, false);
}
}}

}


};gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects = Hashtable.newFrom({"NPC_2": gdjs.Stage8Code.GDNPC_95952Objects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects2Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects2});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects1Objects = Hashtable.newFrom({"Character": gdjs.Stage8Code.GDCharacterObjects1});
gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects1Objects = Hashtable.newFrom({"Weight_Pad": gdjs.Stage8Code.GDWeight_9595PadObjects1});
gdjs.Stage8Code.eventsList74 = function(runtimeScene) {

{



}


{


gdjs.Stage8Code.eventsList71(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Stage8Code.GDBomb_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Stage8Code.GDCurserObjects2);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects2);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Stage8Code.GDMonsterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Stage8Code.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Stage8Code.GDSwap_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_1"), gdjs.Stage8Code.GDTutorial_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Tutorial_2"), gdjs.Stage8Code.GDTutorial_95952Objects2);
{gdjs.evtTools.window.setWindowSize(runtimeScene, 1280, 720, false);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Background/fade", 0, 0, 0);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{for(var i = 0, len = gdjs.Stage8Code.GDCurserObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCurserObjects2[i].getBehavior("Scale").setScale(0.7);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects2[i].getBehavior("Scale").setScale(0.6);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTutorial_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTutorial_95951Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDTutorial_95952Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTutorial_95952Objects2[i].getBehavior("Opacity").setOpacity(0);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Stage8Code.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDSwap_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
for(var i = 0, len = gdjs.Stage8Code.GDBomb_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDBomb_9595CardObjects2[i].getBehavior("Opacity").setOpacity(180);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMonsterObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Stage8");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(0);
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects2[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects2[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95952Objects2[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 0.85, "", 0);
}{for(var i = 0, len = gdjs.Stage8Code.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDCharacterObjects2[i].setVariableBoolean(gdjs.Stage8Code.GDCharacterObjects2[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Stage8Code.GDNPC_95951Objects2[i].getVariables().getFromIndex(6), true);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDGood_9595GateObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595GateObjects2[i].getBehavior("Opacity").setOpacity(0);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17306028);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Stage8Code.GDFade_9595ScreenObjects2);
{for(var i = 0, len = gdjs.Stage8Code.GDFade_9595ScreenObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDFade_9595ScreenObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Fade_In", 0, "linear", 2, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17306948);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Stage8Code.GDMove_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Stage8Code.GDSword_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Stage8Code.GDTeleport_9595CardObjects2);
{for(var i = 0, len = gdjs.Stage8Code.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].returnVariable(gdjs.Stage8Code.GDTeleport_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(4);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595CardObjects2[i].returnVariable(gdjs.Stage8Code.GDMove_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(4);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDSword_9595CardObjects2[i].returnVariable(gdjs.Stage8Code.GDSword_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).setNumber(2);
}{runtimeScene.getGame().getVariables().getFromIndex(6).setNumber(4);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDMonsterObjects) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects2);
{for(var i = 0, len = gdjs.Stage8Code.GDGood_9595GateObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595GateObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 255, "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects2[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Stage8Code.GDMove_9595TriggerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Stage8Code.mapOfEmptyGDMonsterObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDMove_9595TriggerObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDMove_9595TriggerObjects2[i].getZOrder() == 16 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDMove_9595TriggerObjects2[k] = gdjs.Stage8Code.GDMove_9595TriggerObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDMove_9595TriggerObjects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Stage8Code.GDGood_9595GateObjects2);
/* Reuse gdjs.Stage8Code.GDMove_9595TriggerObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDGood_9595GateObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDGood_9595GateObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Show", 0, "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.Stage8Code.GDMove_9595TriggerObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDMove_9595TriggerObjects2[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getZOrder() == 20 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects2[k] = gdjs.Stage8Code.GDWeight_9595PadObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList72(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getZOrder() == 21 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects2[k] = gdjs.Stage8Code.GDWeight_9595PadObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Stage8Code.eventsList73(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getZOrder() == 20 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects2[k] = gdjs.Stage8Code.GDWeight_9595PadObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDWeight_9595PadObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getBehavior("Animation").setAnimationName("Active");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Stage8Code.GDNPC_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDNPC_959595952Objects2Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getZOrder() == 20 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects2[k] = gdjs.Stage8Code.GDWeight_9595PadObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDWeight_9595PadObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getBehavior("Animation").setAnimationName("Inactive");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects2Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects2.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getZOrder() == 21 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects2[k] = gdjs.Stage8Code.GDWeight_9595PadObjects2[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects2 */
{for(var i = 0, len = gdjs.Stage8Code.GDWeight_9595PadObjects2.length ;i < len;++i) {
    gdjs.Stage8Code.GDWeight_9595PadObjects2[i].getBehavior("Animation").setAnimationName("Active");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Stage8Code.GDCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Stage8Code.GDWeight_9595PadObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDCharacterObjects1Objects, gdjs.Stage8Code.mapOfGDgdjs_9546Stage8Code_9546GDWeight_95959595PadObjects1Objects, true, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Stage8Code.GDWeight_9595PadObjects1.length;i<l;++i) {
    if ( gdjs.Stage8Code.GDWeight_9595PadObjects1[i].getZOrder() == 21 ) {
        isConditionTrue_0 = true;
        gdjs.Stage8Code.GDWeight_9595PadObjects1[k] = gdjs.Stage8Code.GDWeight_9595PadObjects1[i];
        ++k;
    }
}
gdjs.Stage8Code.GDWeight_9595PadObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Stage8Code.GDWeight_9595PadObjects1 */
{for(var i = 0, len = gdjs.Stage8Code.GDWeight_9595PadObjects1.length ;i < len;++i) {
    gdjs.Stage8Code.GDWeight_9595PadObjects1[i].getBehavior("Animation").setAnimationName("Inactive");
}
}}

}


};gdjs.Stage8Code.eventsList75 = function(runtimeScene) {

{


gdjs.Stage8Code.eventsList74(runtimeScene);
}


};

gdjs.Stage8Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Stage8Code.GDTutorial_95952Objects1.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects2.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects3.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects4.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects5.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects6.length = 0;
gdjs.Stage8Code.GDTutorial_95952Objects7.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects1.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects2.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects3.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects4.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects5.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects6.length = 0;
gdjs.Stage8Code.GDTutorial_95951Objects7.length = 0;
gdjs.Stage8Code.GDGround_959501Objects1.length = 0;
gdjs.Stage8Code.GDGround_959501Objects2.length = 0;
gdjs.Stage8Code.GDGround_959501Objects3.length = 0;
gdjs.Stage8Code.GDGround_959501Objects4.length = 0;
gdjs.Stage8Code.GDGround_959501Objects5.length = 0;
gdjs.Stage8Code.GDGround_959501Objects6.length = 0;
gdjs.Stage8Code.GDGround_959501Objects7.length = 0;
gdjs.Stage8Code.GDGround_959502Objects1.length = 0;
gdjs.Stage8Code.GDGround_959502Objects2.length = 0;
gdjs.Stage8Code.GDGround_959502Objects3.length = 0;
gdjs.Stage8Code.GDGround_959502Objects4.length = 0;
gdjs.Stage8Code.GDGround_959502Objects5.length = 0;
gdjs.Stage8Code.GDGround_959502Objects6.length = 0;
gdjs.Stage8Code.GDGround_959502Objects7.length = 0;
gdjs.Stage8Code.GDGround_959503Objects1.length = 0;
gdjs.Stage8Code.GDGround_959503Objects2.length = 0;
gdjs.Stage8Code.GDGround_959503Objects3.length = 0;
gdjs.Stage8Code.GDGround_959503Objects4.length = 0;
gdjs.Stage8Code.GDGround_959503Objects5.length = 0;
gdjs.Stage8Code.GDGround_959503Objects6.length = 0;
gdjs.Stage8Code.GDGround_959503Objects7.length = 0;
gdjs.Stage8Code.GDGround_959504Objects1.length = 0;
gdjs.Stage8Code.GDGround_959504Objects2.length = 0;
gdjs.Stage8Code.GDGround_959504Objects3.length = 0;
gdjs.Stage8Code.GDGround_959504Objects4.length = 0;
gdjs.Stage8Code.GDGround_959504Objects5.length = 0;
gdjs.Stage8Code.GDGround_959504Objects6.length = 0;
gdjs.Stage8Code.GDGround_959504Objects7.length = 0;
gdjs.Stage8Code.GDGround_959505Objects1.length = 0;
gdjs.Stage8Code.GDGround_959505Objects2.length = 0;
gdjs.Stage8Code.GDGround_959505Objects3.length = 0;
gdjs.Stage8Code.GDGround_959505Objects4.length = 0;
gdjs.Stage8Code.GDGround_959505Objects5.length = 0;
gdjs.Stage8Code.GDGround_959505Objects6.length = 0;
gdjs.Stage8Code.GDGround_959505Objects7.length = 0;
gdjs.Stage8Code.GDGround_959506Objects1.length = 0;
gdjs.Stage8Code.GDGround_959506Objects2.length = 0;
gdjs.Stage8Code.GDGround_959506Objects3.length = 0;
gdjs.Stage8Code.GDGround_959506Objects4.length = 0;
gdjs.Stage8Code.GDGround_959506Objects5.length = 0;
gdjs.Stage8Code.GDGround_959506Objects6.length = 0;
gdjs.Stage8Code.GDGround_959506Objects7.length = 0;
gdjs.Stage8Code.GDGround_959507Objects1.length = 0;
gdjs.Stage8Code.GDGround_959507Objects2.length = 0;
gdjs.Stage8Code.GDGround_959507Objects3.length = 0;
gdjs.Stage8Code.GDGround_959507Objects4.length = 0;
gdjs.Stage8Code.GDGround_959507Objects5.length = 0;
gdjs.Stage8Code.GDGround_959507Objects6.length = 0;
gdjs.Stage8Code.GDGround_959507Objects7.length = 0;
gdjs.Stage8Code.GDGround_959508Objects1.length = 0;
gdjs.Stage8Code.GDGround_959508Objects2.length = 0;
gdjs.Stage8Code.GDGround_959508Objects3.length = 0;
gdjs.Stage8Code.GDGround_959508Objects4.length = 0;
gdjs.Stage8Code.GDGround_959508Objects5.length = 0;
gdjs.Stage8Code.GDGround_959508Objects6.length = 0;
gdjs.Stage8Code.GDGround_959508Objects7.length = 0;
gdjs.Stage8Code.GDGround_959509Objects1.length = 0;
gdjs.Stage8Code.GDGround_959509Objects2.length = 0;
gdjs.Stage8Code.GDGround_959509Objects3.length = 0;
gdjs.Stage8Code.GDGround_959509Objects4.length = 0;
gdjs.Stage8Code.GDGround_959509Objects5.length = 0;
gdjs.Stage8Code.GDGround_959509Objects6.length = 0;
gdjs.Stage8Code.GDGround_959509Objects7.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects1.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects2.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects3.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects4.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects5.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects6.length = 0;
gdjs.Stage8Code.GDGood_9595WinObjects7.length = 0;
gdjs.Stage8Code.GDVoidObjects1.length = 0;
gdjs.Stage8Code.GDVoidObjects2.length = 0;
gdjs.Stage8Code.GDVoidObjects3.length = 0;
gdjs.Stage8Code.GDVoidObjects4.length = 0;
gdjs.Stage8Code.GDVoidObjects5.length = 0;
gdjs.Stage8Code.GDVoidObjects6.length = 0;
gdjs.Stage8Code.GDVoidObjects7.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects1.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects2.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects3.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects4.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects5.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects6.length = 0;
gdjs.Stage8Code.GDGood_9595GateObjects7.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects1.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects2.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects3.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects4.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects5.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects6.length = 0;
gdjs.Stage8Code.GDMove_9595TriggerObjects7.length = 0;
gdjs.Stage8Code.GDCharacterObjects1.length = 0;
gdjs.Stage8Code.GDCharacterObjects2.length = 0;
gdjs.Stage8Code.GDCharacterObjects3.length = 0;
gdjs.Stage8Code.GDCharacterObjects4.length = 0;
gdjs.Stage8Code.GDCharacterObjects5.length = 0;
gdjs.Stage8Code.GDCharacterObjects6.length = 0;
gdjs.Stage8Code.GDCharacterObjects7.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDMove_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects1.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects2.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects3.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects4.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects5.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects6.length = 0;
gdjs.Stage8Code.GDAmount_9595MoveObjects7.length = 0;
gdjs.Stage8Code.GDMoveObjects1.length = 0;
gdjs.Stage8Code.GDMoveObjects2.length = 0;
gdjs.Stage8Code.GDMoveObjects3.length = 0;
gdjs.Stage8Code.GDMoveObjects4.length = 0;
gdjs.Stage8Code.GDMoveObjects5.length = 0;
gdjs.Stage8Code.GDMoveObjects6.length = 0;
gdjs.Stage8Code.GDMoveObjects7.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDSword_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects1.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects2.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects3.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects4.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects5.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects6.length = 0;
gdjs.Stage8Code.GDAmount_9595SwordObjects7.length = 0;
gdjs.Stage8Code.GDSwordObjects1.length = 0;
gdjs.Stage8Code.GDSwordObjects2.length = 0;
gdjs.Stage8Code.GDSwordObjects3.length = 0;
gdjs.Stage8Code.GDSwordObjects4.length = 0;
gdjs.Stage8Code.GDSwordObjects5.length = 0;
gdjs.Stage8Code.GDSwordObjects6.length = 0;
gdjs.Stage8Code.GDSwordObjects7.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDTeleport_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects1.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects2.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects3.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects4.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects5.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects6.length = 0;
gdjs.Stage8Code.GDAmount_9595TeleportObjects7.length = 0;
gdjs.Stage8Code.GDTeleportObjects1.length = 0;
gdjs.Stage8Code.GDTeleportObjects2.length = 0;
gdjs.Stage8Code.GDTeleportObjects3.length = 0;
gdjs.Stage8Code.GDTeleportObjects4.length = 0;
gdjs.Stage8Code.GDTeleportObjects5.length = 0;
gdjs.Stage8Code.GDTeleportObjects6.length = 0;
gdjs.Stage8Code.GDTeleportObjects7.length = 0;
gdjs.Stage8Code.GDCurserObjects1.length = 0;
gdjs.Stage8Code.GDCurserObjects2.length = 0;
gdjs.Stage8Code.GDCurserObjects3.length = 0;
gdjs.Stage8Code.GDCurserObjects4.length = 0;
gdjs.Stage8Code.GDCurserObjects5.length = 0;
gdjs.Stage8Code.GDCurserObjects6.length = 0;
gdjs.Stage8Code.GDCurserObjects7.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects1.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects2.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects3.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects4.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects5.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects6.length = 0;
gdjs.Stage8Code.GDFade_9595ScreenObjects7.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects1.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects2.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects3.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects4.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects5.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects6.length = 0;
gdjs.Stage8Code.GDSlash_9595EffectObjects7.length = 0;
gdjs.Stage8Code.GDBackgroundObjects1.length = 0;
gdjs.Stage8Code.GDBackgroundObjects2.length = 0;
gdjs.Stage8Code.GDBackgroundObjects3.length = 0;
gdjs.Stage8Code.GDBackgroundObjects4.length = 0;
gdjs.Stage8Code.GDBackgroundObjects5.length = 0;
gdjs.Stage8Code.GDBackgroundObjects6.length = 0;
gdjs.Stage8Code.GDBackgroundObjects7.length = 0;
gdjs.Stage8Code.GDMonsterObjects1.length = 0;
gdjs.Stage8Code.GDMonsterObjects2.length = 0;
gdjs.Stage8Code.GDMonsterObjects3.length = 0;
gdjs.Stage8Code.GDMonsterObjects4.length = 0;
gdjs.Stage8Code.GDMonsterObjects5.length = 0;
gdjs.Stage8Code.GDMonsterObjects6.length = 0;
gdjs.Stage8Code.GDMonsterObjects7.length = 0;
gdjs.Stage8Code.GDPadObjects1.length = 0;
gdjs.Stage8Code.GDPadObjects2.length = 0;
gdjs.Stage8Code.GDPadObjects3.length = 0;
gdjs.Stage8Code.GDPadObjects4.length = 0;
gdjs.Stage8Code.GDPadObjects5.length = 0;
gdjs.Stage8Code.GDPadObjects6.length = 0;
gdjs.Stage8Code.GDPadObjects7.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects1.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects2.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects3.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects4.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects5.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects6.length = 0;
gdjs.Stage8Code.GDUI_9595TextObjects7.length = 0;
gdjs.Stage8Code.GDDebugObjects1.length = 0;
gdjs.Stage8Code.GDDebugObjects2.length = 0;
gdjs.Stage8Code.GDDebugObjects3.length = 0;
gdjs.Stage8Code.GDDebugObjects4.length = 0;
gdjs.Stage8Code.GDDebugObjects5.length = 0;
gdjs.Stage8Code.GDDebugObjects6.length = 0;
gdjs.Stage8Code.GDDebugObjects7.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDTeleportBlade_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDRenderObjects1.length = 0;
gdjs.Stage8Code.GDRenderObjects2.length = 0;
gdjs.Stage8Code.GDRenderObjects3.length = 0;
gdjs.Stage8Code.GDRenderObjects4.length = 0;
gdjs.Stage8Code.GDRenderObjects5.length = 0;
gdjs.Stage8Code.GDRenderObjects6.length = 0;
gdjs.Stage8Code.GDRenderObjects7.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects1.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects2.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects3.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects4.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects5.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects6.length = 0;
gdjs.Stage8Code.GDReset_9595buttonObjects7.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects1.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects2.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects3.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects4.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects5.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects6.length = 0;
gdjs.Stage8Code.GDUI_9595Text_95952Objects7.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects1.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects2.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects3.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects4.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects5.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects6.length = 0;
gdjs.Stage8Code.GDRight_9595ClickObjects7.length = 0;
gdjs.Stage8Code.GDGround_959510Objects1.length = 0;
gdjs.Stage8Code.GDGround_959510Objects2.length = 0;
gdjs.Stage8Code.GDGround_959510Objects3.length = 0;
gdjs.Stage8Code.GDGround_959510Objects4.length = 0;
gdjs.Stage8Code.GDGround_959510Objects5.length = 0;
gdjs.Stage8Code.GDGround_959510Objects6.length = 0;
gdjs.Stage8Code.GDGround_959510Objects7.length = 0;
gdjs.Stage8Code.GDGround_959511Objects1.length = 0;
gdjs.Stage8Code.GDGround_959511Objects2.length = 0;
gdjs.Stage8Code.GDGround_959511Objects3.length = 0;
gdjs.Stage8Code.GDGround_959511Objects4.length = 0;
gdjs.Stage8Code.GDGround_959511Objects5.length = 0;
gdjs.Stage8Code.GDGround_959511Objects6.length = 0;
gdjs.Stage8Code.GDGround_959511Objects7.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDSwap_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects1.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects2.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects3.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects4.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects5.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects6.length = 0;
gdjs.Stage8Code.GDBomb_9595CardObjects7.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects1.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects2.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects3.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects4.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects5.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects6.length = 0;
gdjs.Stage8Code.GDNPC_95951Objects7.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects1.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects2.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects3.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects4.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects5.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects6.length = 0;
gdjs.Stage8Code.GDBad_9595WinObjects7.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects1.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects2.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects3.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects4.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects5.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects6.length = 0;
gdjs.Stage8Code.GDBad_9595GateObjects7.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects1.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects2.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects3.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects4.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects5.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects6.length = 0;
gdjs.Stage8Code.GDWeight_9595PadObjects7.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects1.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects2.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects3.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects4.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects5.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects6.length = 0;
gdjs.Stage8Code.GDNPC_95952Objects7.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects1.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects2.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects3.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects4.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects5.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects6.length = 0;
gdjs.Stage8Code.GDCard_9595UIObjects7.length = 0;
gdjs.Stage8Code.GDSmokeObjects1.length = 0;
gdjs.Stage8Code.GDSmokeObjects2.length = 0;
gdjs.Stage8Code.GDSmokeObjects3.length = 0;
gdjs.Stage8Code.GDSmokeObjects4.length = 0;
gdjs.Stage8Code.GDSmokeObjects5.length = 0;
gdjs.Stage8Code.GDSmokeObjects6.length = 0;
gdjs.Stage8Code.GDSmokeObjects7.length = 0;

gdjs.Stage8Code.eventsList75(runtimeScene);

return;

}

gdjs['Stage8Code'] = gdjs.Stage8Code;
