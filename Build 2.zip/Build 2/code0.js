gdjs.Main_32MenuCode = {};
gdjs.Main_32MenuCode.GDAboutObjects1_1final = [];

gdjs.Main_32MenuCode.GDBackObjects1_1final = [];

gdjs.Main_32MenuCode.GDCharacterObjects3_1final = [];

gdjs.Main_32MenuCode.GDExitObjects1_1final = [];

gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final = [];

gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final = [];

gdjs.Main_32MenuCode.GDStartObjects1_1final = [];

gdjs.Main_32MenuCode.forEachIndex4 = 0;

gdjs.Main_32MenuCode.forEachObjects4 = [];

gdjs.Main_32MenuCode.forEachTemporary4 = null;

gdjs.Main_32MenuCode.forEachTotalCount4 = 0;

gdjs.Main_32MenuCode.GDGame_9595LogoObjects1= [];
gdjs.Main_32MenuCode.GDGame_9595LogoObjects2= [];
gdjs.Main_32MenuCode.GDGame_9595LogoObjects3= [];
gdjs.Main_32MenuCode.GDGame_9595LogoObjects4= [];
gdjs.Main_32MenuCode.GDGame_9595LogoObjects5= [];
gdjs.Main_32MenuCode.GDGame_9595LogoObjects6= [];
gdjs.Main_32MenuCode.GDStartObjects1= [];
gdjs.Main_32MenuCode.GDStartObjects2= [];
gdjs.Main_32MenuCode.GDStartObjects3= [];
gdjs.Main_32MenuCode.GDStartObjects4= [];
gdjs.Main_32MenuCode.GDStartObjects5= [];
gdjs.Main_32MenuCode.GDStartObjects6= [];
gdjs.Main_32MenuCode.GDAboutObjects1= [];
gdjs.Main_32MenuCode.GDAboutObjects2= [];
gdjs.Main_32MenuCode.GDAboutObjects3= [];
gdjs.Main_32MenuCode.GDAboutObjects4= [];
gdjs.Main_32MenuCode.GDAboutObjects5= [];
gdjs.Main_32MenuCode.GDAboutObjects6= [];
gdjs.Main_32MenuCode.GDExitObjects1= [];
gdjs.Main_32MenuCode.GDExitObjects2= [];
gdjs.Main_32MenuCode.GDExitObjects3= [];
gdjs.Main_32MenuCode.GDExitObjects4= [];
gdjs.Main_32MenuCode.GDExitObjects5= [];
gdjs.Main_32MenuCode.GDExitObjects6= [];
gdjs.Main_32MenuCode.GDBackObjects1= [];
gdjs.Main_32MenuCode.GDBackObjects2= [];
gdjs.Main_32MenuCode.GDBackObjects3= [];
gdjs.Main_32MenuCode.GDBackObjects4= [];
gdjs.Main_32MenuCode.GDBackObjects5= [];
gdjs.Main_32MenuCode.GDBackObjects6= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects2= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects3= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects4= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects5= [];
gdjs.Main_32MenuCode.GDAbout_9595TextObjects6= [];
gdjs.Main_32MenuCode.GDGround_959501Objects1= [];
gdjs.Main_32MenuCode.GDGround_959501Objects2= [];
gdjs.Main_32MenuCode.GDGround_959501Objects3= [];
gdjs.Main_32MenuCode.GDGround_959501Objects4= [];
gdjs.Main_32MenuCode.GDGround_959501Objects5= [];
gdjs.Main_32MenuCode.GDGround_959501Objects6= [];
gdjs.Main_32MenuCode.GDGround_959502Objects1= [];
gdjs.Main_32MenuCode.GDGround_959502Objects2= [];
gdjs.Main_32MenuCode.GDGround_959502Objects3= [];
gdjs.Main_32MenuCode.GDGround_959502Objects4= [];
gdjs.Main_32MenuCode.GDGround_959502Objects5= [];
gdjs.Main_32MenuCode.GDGround_959502Objects6= [];
gdjs.Main_32MenuCode.GDGround_959503Objects1= [];
gdjs.Main_32MenuCode.GDGround_959503Objects2= [];
gdjs.Main_32MenuCode.GDGround_959503Objects3= [];
gdjs.Main_32MenuCode.GDGround_959503Objects4= [];
gdjs.Main_32MenuCode.GDGround_959503Objects5= [];
gdjs.Main_32MenuCode.GDGround_959503Objects6= [];
gdjs.Main_32MenuCode.GDGround_959504Objects1= [];
gdjs.Main_32MenuCode.GDGround_959504Objects2= [];
gdjs.Main_32MenuCode.GDGround_959504Objects3= [];
gdjs.Main_32MenuCode.GDGround_959504Objects4= [];
gdjs.Main_32MenuCode.GDGround_959504Objects5= [];
gdjs.Main_32MenuCode.GDGround_959504Objects6= [];
gdjs.Main_32MenuCode.GDGround_959505Objects1= [];
gdjs.Main_32MenuCode.GDGround_959505Objects2= [];
gdjs.Main_32MenuCode.GDGround_959505Objects3= [];
gdjs.Main_32MenuCode.GDGround_959505Objects4= [];
gdjs.Main_32MenuCode.GDGround_959505Objects5= [];
gdjs.Main_32MenuCode.GDGround_959505Objects6= [];
gdjs.Main_32MenuCode.GDGround_959506Objects1= [];
gdjs.Main_32MenuCode.GDGround_959506Objects2= [];
gdjs.Main_32MenuCode.GDGround_959506Objects3= [];
gdjs.Main_32MenuCode.GDGround_959506Objects4= [];
gdjs.Main_32MenuCode.GDGround_959506Objects5= [];
gdjs.Main_32MenuCode.GDGround_959506Objects6= [];
gdjs.Main_32MenuCode.GDGround_959507Objects1= [];
gdjs.Main_32MenuCode.GDGround_959507Objects2= [];
gdjs.Main_32MenuCode.GDGround_959507Objects3= [];
gdjs.Main_32MenuCode.GDGround_959507Objects4= [];
gdjs.Main_32MenuCode.GDGround_959507Objects5= [];
gdjs.Main_32MenuCode.GDGround_959507Objects6= [];
gdjs.Main_32MenuCode.GDGround_959508Objects1= [];
gdjs.Main_32MenuCode.GDGround_959508Objects2= [];
gdjs.Main_32MenuCode.GDGround_959508Objects3= [];
gdjs.Main_32MenuCode.GDGround_959508Objects4= [];
gdjs.Main_32MenuCode.GDGround_959508Objects5= [];
gdjs.Main_32MenuCode.GDGround_959508Objects6= [];
gdjs.Main_32MenuCode.GDGround_959509Objects1= [];
gdjs.Main_32MenuCode.GDGround_959509Objects2= [];
gdjs.Main_32MenuCode.GDGround_959509Objects3= [];
gdjs.Main_32MenuCode.GDGround_959509Objects4= [];
gdjs.Main_32MenuCode.GDGround_959509Objects5= [];
gdjs.Main_32MenuCode.GDGround_959509Objects6= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects1= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects2= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects3= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects4= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects5= [];
gdjs.Main_32MenuCode.GDGood_9595WinObjects6= [];
gdjs.Main_32MenuCode.GDVoidObjects1= [];
gdjs.Main_32MenuCode.GDVoidObjects2= [];
gdjs.Main_32MenuCode.GDVoidObjects3= [];
gdjs.Main_32MenuCode.GDVoidObjects4= [];
gdjs.Main_32MenuCode.GDVoidObjects5= [];
gdjs.Main_32MenuCode.GDVoidObjects6= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects1= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects2= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects3= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects4= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects5= [];
gdjs.Main_32MenuCode.GDGood_9595GateObjects6= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects5= [];
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects6= [];
gdjs.Main_32MenuCode.GDCharacterObjects1= [];
gdjs.Main_32MenuCode.GDCharacterObjects2= [];
gdjs.Main_32MenuCode.GDCharacterObjects3= [];
gdjs.Main_32MenuCode.GDCharacterObjects4= [];
gdjs.Main_32MenuCode.GDCharacterObjects5= [];
gdjs.Main_32MenuCode.GDCharacterObjects6= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDMove_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects1= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects2= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects5= [];
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects6= [];
gdjs.Main_32MenuCode.GDMoveObjects1= [];
gdjs.Main_32MenuCode.GDMoveObjects2= [];
gdjs.Main_32MenuCode.GDMoveObjects3= [];
gdjs.Main_32MenuCode.GDMoveObjects4= [];
gdjs.Main_32MenuCode.GDMoveObjects5= [];
gdjs.Main_32MenuCode.GDMoveObjects6= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDSword_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects1= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects2= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects5= [];
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects6= [];
gdjs.Main_32MenuCode.GDSwordObjects1= [];
gdjs.Main_32MenuCode.GDSwordObjects2= [];
gdjs.Main_32MenuCode.GDSwordObjects3= [];
gdjs.Main_32MenuCode.GDSwordObjects4= [];
gdjs.Main_32MenuCode.GDSwordObjects5= [];
gdjs.Main_32MenuCode.GDSwordObjects6= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects1= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects2= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects5= [];
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects6= [];
gdjs.Main_32MenuCode.GDTeleportObjects1= [];
gdjs.Main_32MenuCode.GDTeleportObjects2= [];
gdjs.Main_32MenuCode.GDTeleportObjects3= [];
gdjs.Main_32MenuCode.GDTeleportObjects4= [];
gdjs.Main_32MenuCode.GDTeleportObjects5= [];
gdjs.Main_32MenuCode.GDTeleportObjects6= [];
gdjs.Main_32MenuCode.GDCurserObjects1= [];
gdjs.Main_32MenuCode.GDCurserObjects2= [];
gdjs.Main_32MenuCode.GDCurserObjects3= [];
gdjs.Main_32MenuCode.GDCurserObjects4= [];
gdjs.Main_32MenuCode.GDCurserObjects5= [];
gdjs.Main_32MenuCode.GDCurserObjects6= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects5= [];
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects6= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects1= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects2= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects5= [];
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects6= [];
gdjs.Main_32MenuCode.GDBackgroundObjects1= [];
gdjs.Main_32MenuCode.GDBackgroundObjects2= [];
gdjs.Main_32MenuCode.GDBackgroundObjects3= [];
gdjs.Main_32MenuCode.GDBackgroundObjects4= [];
gdjs.Main_32MenuCode.GDBackgroundObjects5= [];
gdjs.Main_32MenuCode.GDBackgroundObjects6= [];
gdjs.Main_32MenuCode.GDMonsterObjects1= [];
gdjs.Main_32MenuCode.GDMonsterObjects2= [];
gdjs.Main_32MenuCode.GDMonsterObjects3= [];
gdjs.Main_32MenuCode.GDMonsterObjects4= [];
gdjs.Main_32MenuCode.GDMonsterObjects5= [];
gdjs.Main_32MenuCode.GDMonsterObjects6= [];
gdjs.Main_32MenuCode.GDPadObjects1= [];
gdjs.Main_32MenuCode.GDPadObjects2= [];
gdjs.Main_32MenuCode.GDPadObjects3= [];
gdjs.Main_32MenuCode.GDPadObjects4= [];
gdjs.Main_32MenuCode.GDPadObjects5= [];
gdjs.Main_32MenuCode.GDPadObjects6= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects1= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects2= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects3= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects4= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects5= [];
gdjs.Main_32MenuCode.GDUI_9595TextObjects6= [];
gdjs.Main_32MenuCode.GDDebugObjects1= [];
gdjs.Main_32MenuCode.GDDebugObjects2= [];
gdjs.Main_32MenuCode.GDDebugObjects3= [];
gdjs.Main_32MenuCode.GDDebugObjects4= [];
gdjs.Main_32MenuCode.GDDebugObjects5= [];
gdjs.Main_32MenuCode.GDDebugObjects6= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDRenderObjects1= [];
gdjs.Main_32MenuCode.GDRenderObjects2= [];
gdjs.Main_32MenuCode.GDRenderObjects3= [];
gdjs.Main_32MenuCode.GDRenderObjects4= [];
gdjs.Main_32MenuCode.GDRenderObjects5= [];
gdjs.Main_32MenuCode.GDRenderObjects6= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects1= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects2= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects3= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects4= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects5= [];
gdjs.Main_32MenuCode.GDReset_9595buttonObjects6= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects1= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects2= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects3= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects4= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects5= [];
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects6= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects1= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects2= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects3= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects4= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects5= [];
gdjs.Main_32MenuCode.GDRight_9595ClickObjects6= [];
gdjs.Main_32MenuCode.GDGround_959510Objects1= [];
gdjs.Main_32MenuCode.GDGround_959510Objects2= [];
gdjs.Main_32MenuCode.GDGround_959510Objects3= [];
gdjs.Main_32MenuCode.GDGround_959510Objects4= [];
gdjs.Main_32MenuCode.GDGround_959510Objects5= [];
gdjs.Main_32MenuCode.GDGround_959510Objects6= [];
gdjs.Main_32MenuCode.GDGround_959511Objects1= [];
gdjs.Main_32MenuCode.GDGround_959511Objects2= [];
gdjs.Main_32MenuCode.GDGround_959511Objects3= [];
gdjs.Main_32MenuCode.GDGround_959511Objects4= [];
gdjs.Main_32MenuCode.GDGround_959511Objects5= [];
gdjs.Main_32MenuCode.GDGround_959511Objects6= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDSwap_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects1= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects2= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects3= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects4= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects5= [];
gdjs.Main_32MenuCode.GDBomb_9595CardObjects6= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects1= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects2= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects3= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects4= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects5= [];
gdjs.Main_32MenuCode.GDNPC_95951Objects6= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects1= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects2= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects3= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects4= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects5= [];
gdjs.Main_32MenuCode.GDBad_9595WinObjects6= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects1= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects2= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects3= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects4= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects5= [];
gdjs.Main_32MenuCode.GDBad_9595GateObjects6= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects1= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects2= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects3= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects4= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects5= [];
gdjs.Main_32MenuCode.GDWeight_9595PadObjects6= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects1= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects2= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects3= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects4= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects5= [];
gdjs.Main_32MenuCode.GDNPC_95952Objects6= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects1= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects2= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects3= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects4= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects5= [];
gdjs.Main_32MenuCode.GDCard_9595UIObjects6= [];
gdjs.Main_32MenuCode.GDSmokeObjects1= [];
gdjs.Main_32MenuCode.GDSmokeObjects2= [];
gdjs.Main_32MenuCode.GDSmokeObjects3= [];
gdjs.Main_32MenuCode.GDSmokeObjects4= [];
gdjs.Main_32MenuCode.GDSmokeObjects5= [];
gdjs.Main_32MenuCode.GDSmokeObjects6= [];


gdjs.Main_32MenuCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17629196);
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Looped Ambince sound.mp3", 1, true, 10, 1);
}}

}


};gdjs.Main_32MenuCode.eventsList1 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Tutorial";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(9174020);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Ambient - Dream World.mp3", 1, true, 25, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Main_32MenuCode.mapOfEmptyGDBomb_9595CardObjects = Hashtable.newFrom({"Bomb_Card": []});
gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Main_32MenuCode.eventsList2 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].activateBehavior("SmoothCamera", true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].activateBehavior("SmoothCamera", true);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getPointX("Point_Fix")) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getPointX("Point_Fix")) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getPointX("Point_Fix")),(( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getPointY("Point_Fix")) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getPointY("Point_Fix")) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getPointY("Point_Fix")));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.2, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Active"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].activateBehavior("SmoothCamera", false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].activateBehavior("SmoothCamera", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectOpacityTween2("InActive", 120, "linear", 0.2, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Main_32MenuCode.GDVoidObjects4);
gdjs.copyArray(runtimeScene.getObjects("Weight_Pad"), gdjs.Main_32MenuCode.GDWeight_9595PadObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects4[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDWeight_9595PadObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDWeight_9595PadObjects4[i].getBehavior("Scale").setScale(0.8);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Scale").setScale(0.9);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDVoidObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDVoidObjects4[i].rotate(10, runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDVoidObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDVoidObjects4[i].getBehavior("Scale").setScale(0.9);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Reset_button"), gdjs.Main_32MenuCode.GDReset_9595buttonObjects4);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Main_32MenuCode.GDVoidObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].getBehavior("Opacity").setOpacity(100);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDReset_9595buttonObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDReset_9595buttonObjects4[i].getBehavior("Opacity").setOpacity(200);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDVoidObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDVoidObjects4[i].getBehavior("Opacity").setOpacity(180);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bad_Win"), gdjs.Main_32MenuCode.GDBad_9595WinObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.Main_32MenuCode.GDGood_9595WinObjects4);
{gdjs.evtTools.input.hideCursor(runtimeScene);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDGood_9595WinObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGood_9595WinObjects4[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDBad_9595WinObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBad_9595WinObjects4[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Main_32MenuCode.GDBomb_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Main_32MenuCode.GDMoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Smoke"), gdjs.Main_32MenuCode.GDSmokeObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].setZOrder(9999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i].setZOrder(9999);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].setZOrder(999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].setZOrder(999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].setZOrder(999);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSmokeObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSmokeObjects4[i].setZOrder(1000);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMoveObjects4[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects4[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects4[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].setZOrder(99999);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].setZOrder(99999);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects4[i].setZOrder(999999);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Main_32MenuCode.GDMoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMoveObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDBomb_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Main_32MenuCode.GDBomb_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Main_32MenuCode.GDMoveObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMoveObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5))));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[0].getPointX("Contact")),(( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[0].getPointY("Contact")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6))));
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDBomb_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4[i].getBehavior("Text").setText(((gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32MenuCode.GDMove_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].getBehavior("Text").setText(((gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32MenuCode.GDSword_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].setPosition((( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[0].getPointX("Amount")),(( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[0].getPointY("Amount")) + 10);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].getBehavior("Text").setText(((gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[0].getVariables()).getFromIndex(0).getAsString());
}
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Main_32MenuCode.GDBomb_9595CardObjects3);
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDBomb_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBomb_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()) - 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595CardObjects3[0].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()), 0.05),gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].setPosition(gdjs.evtTools.common.lerp((( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterXInScene()) + 280, 0.05),gdjs.evtTools.common.lerp((( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[0].getCenterYInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects3.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects3[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects3[0].getCenterYInScene()) + 480, 0.05));
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBomb_95959595CardObjects4Objects = Hashtable.newFrom({"Move_Card": gdjs.Main_32MenuCode.GDMove_9595CardObjects4, "Sword_Card": gdjs.Main_32MenuCode.GDSword_9595CardObjects4, "Teleport_Card": gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4, "TeleportBlade_Card": gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4, "Swap_Card": gdjs.Main_32MenuCode.GDSwap_9595CardObjects4, "Bomb_Card": gdjs.Main_32MenuCode.GDBomb_9595CardObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBomb_95959595CardObjects4Objects = Hashtable.newFrom({"Move_Card": gdjs.Main_32MenuCode.GDMove_9595CardObjects4, "Sword_Card": gdjs.Main_32MenuCode.GDSword_9595CardObjects4, "Teleport_Card": gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4, "TeleportBlade_Card": gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4, "Swap_Card": gdjs.Main_32MenuCode.GDSwap_9595CardObjects4, "Bomb_Card": gdjs.Main_32MenuCode.GDBomb_9595CardObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959501Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959502Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959503Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959504Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959505Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959506Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959507Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959508Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959509Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595GateObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDVoidObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959510Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959511Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBad_95959595GateObjects4Objects = Hashtable.newFrom({"Ground_01": gdjs.Main_32MenuCode.GDGround_959501Objects4, "Ground_02": gdjs.Main_32MenuCode.GDGround_959502Objects4, "Ground_03": gdjs.Main_32MenuCode.GDGround_959503Objects4, "Ground_04": gdjs.Main_32MenuCode.GDGround_959504Objects4, "Ground_05": gdjs.Main_32MenuCode.GDGround_959505Objects4, "Ground_06": gdjs.Main_32MenuCode.GDGround_959506Objects4, "Ground_07": gdjs.Main_32MenuCode.GDGround_959507Objects4, "Ground_08": gdjs.Main_32MenuCode.GDGround_959508Objects4, "Ground_09": gdjs.Main_32MenuCode.GDGround_959509Objects4, "Good_Gate": gdjs.Main_32MenuCode.GDGood_9595GateObjects4, "Void": gdjs.Main_32MenuCode.GDVoidObjects4, "Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4, "Pad": gdjs.Main_32MenuCode.GDPadObjects4, "Ground_10": gdjs.Main_32MenuCode.GDGround_959510Objects4, "Ground_11": gdjs.Main_32MenuCode.GDGround_959511Objects4, "Bad_Gate": gdjs.Main_32MenuCode.GDBad_9595GateObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959501Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959502Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959503Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959504Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959505Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959506Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959507Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959508Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959509Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595GateObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDVoidObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959510Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959511Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBad_95959595GateObjects4Objects = Hashtable.newFrom({"Ground_01": gdjs.Main_32MenuCode.GDGround_959501Objects4, "Ground_02": gdjs.Main_32MenuCode.GDGround_959502Objects4, "Ground_03": gdjs.Main_32MenuCode.GDGround_959503Objects4, "Ground_04": gdjs.Main_32MenuCode.GDGround_959504Objects4, "Ground_05": gdjs.Main_32MenuCode.GDGround_959505Objects4, "Ground_06": gdjs.Main_32MenuCode.GDGround_959506Objects4, "Ground_07": gdjs.Main_32MenuCode.GDGround_959507Objects4, "Ground_08": gdjs.Main_32MenuCode.GDGround_959508Objects4, "Ground_09": gdjs.Main_32MenuCode.GDGround_959509Objects4, "Good_Gate": gdjs.Main_32MenuCode.GDGood_9595GateObjects4, "Void": gdjs.Main_32MenuCode.GDVoidObjects4, "Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4, "Pad": gdjs.Main_32MenuCode.GDPadObjects4, "Ground_10": gdjs.Main_32MenuCode.GDGround_959510Objects4, "Ground_11": gdjs.Main_32MenuCode.GDGround_959511Objects4, "Bad_Gate": gdjs.Main_32MenuCode.GDBad_9595GateObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCurserObjects4Objects = Hashtable.newFrom({"Curser": gdjs.Main_32MenuCode.GDCurserObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4});
gdjs.Main_32MenuCode.asyncCallback17881276 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects5);

{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects5[i].getBehavior("Animation").setAnimationName("Idle");
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects5.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects5[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.5, "bounce", 0.1, false, false);
}
}}
gdjs.Main_32MenuCode.eventsList3 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32MenuCode.GDCurserObjects4) asyncObjectsList.addObject("Curser", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.1), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17881276(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Main_32MenuCode.GDBomb_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBomb_95959595CardObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[k] = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(8210740);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDBomb_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDMove_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDSwap_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDSword_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.75, "linear", 0.1, false, false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Swipe.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bomb_Card"), gdjs.Main_32MenuCode.GDBomb_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBomb_95959595CardObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDBomb_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDMove_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDSwap_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDSword_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBomb_9595CardObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 0.7, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.Main_32MenuCode.GDBad_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Main_32MenuCode.GDGood_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.Main_32MenuCode.GDGround_959501Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.Main_32MenuCode.GDGround_959502Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.Main_32MenuCode.GDGround_959503Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.Main_32MenuCode.GDGround_959504Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.Main_32MenuCode.GDGround_959505Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.Main_32MenuCode.GDGround_959506Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.Main_32MenuCode.GDGround_959507Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.Main_32MenuCode.GDGround_959508Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.Main_32MenuCode.GDGround_959509Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.Main_32MenuCode.GDGround_959510Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.Main_32MenuCode.GDGround_959511Objects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Main_32MenuCode.GDPadObjects4);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Main_32MenuCode.GDVoidObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959501Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959502Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959503Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959504Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959505Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959506Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959507Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959508Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959509Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595GateObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDVoidObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959510Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959511Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBad_95959595GateObjects4Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDBad_9595GateObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDGood_9595GateObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959501Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959502Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959503Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959504Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959505Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959506Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959507Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959508Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959509Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959510Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959511Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDPadObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDVoidObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959501Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959501Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959502Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959502Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959503Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959503Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959504Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959504Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959505Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959505Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959506Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959506Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959507Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959507Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959508Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959508Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959509Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959509Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGood_9595GateObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGood_9595GateObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDVoidObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDVoidObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDPadObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPadObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959510Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959510Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959511Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959511Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDBad_9595GateObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBad_9595GateObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "148;148;148", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1.1, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Bad_Gate"), gdjs.Main_32MenuCode.GDBad_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Main_32MenuCode.GDGood_9595GateObjects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_01"), gdjs.Main_32MenuCode.GDGround_959501Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_02"), gdjs.Main_32MenuCode.GDGround_959502Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_03"), gdjs.Main_32MenuCode.GDGround_959503Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_04"), gdjs.Main_32MenuCode.GDGround_959504Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_05"), gdjs.Main_32MenuCode.GDGround_959505Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_06"), gdjs.Main_32MenuCode.GDGround_959506Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_07"), gdjs.Main_32MenuCode.GDGround_959507Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_08"), gdjs.Main_32MenuCode.GDGround_959508Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_09"), gdjs.Main_32MenuCode.GDGround_959509Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_10"), gdjs.Main_32MenuCode.GDGround_959510Objects4);
gdjs.copyArray(runtimeScene.getObjects("Ground_11"), gdjs.Main_32MenuCode.GDGround_959511Objects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Main_32MenuCode.GDPadObjects4);
gdjs.copyArray(runtimeScene.getObjects("Void"), gdjs.Main_32MenuCode.GDVoidObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959501Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959502Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959503Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959504Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959505Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959506Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959507Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959508Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959509Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595GateObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDVoidObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959510Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDGround_9595959511Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDBad_95959595GateObjects4Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDBad_9595GateObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDGood_9595GateObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959501Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959502Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959503Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959504Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959505Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959506Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959507Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959508Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959509Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959510Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDGround_959511Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDPadObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDVoidObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959501Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959501Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959502Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959502Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959503Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959503Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959504Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959504Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959505Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959505Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959506Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959506Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959507Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959507Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959508Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959508Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959509Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959509Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGood_9595GateObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGood_9595GateObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDVoidObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDVoidObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDPadObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPadObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959510Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959510Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDGround_959511Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGround_959511Objects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDBad_9595GateObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBad_9595GateObjects4[i].getBehavior("Tween").addObjectColorTween2("Touch", "255;255;255", "linear", 0.1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Tween").addObjectScaleTween3("Hover", 1, "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCurserObjects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCurserObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCurserObjects4[i].getBehavior("Animation").getAnimationName() == "Idle" ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCurserObjects4[k] = gdjs.Main_32MenuCode.GDCurserObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCurserObjects4.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCurserObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects4[i].getBehavior("Animation").setAnimationName("Click");
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects4[i].getBehavior("Tween").addObjectScaleTween3("Click", 0.4, "bounce", 0.1, false, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList3(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16144236);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").removeTween("Breath_Out");
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").removeTween("Breath_In");
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600924);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 0.5, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMonsterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").hasFinished("Breath_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMonsterObjects4[k] = gdjs.Main_32MenuCode.GDMonsterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMonsterObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMonsterObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_In", 1.05, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").removeTween("Breath_Out");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMonsterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").hasFinished("Breath_In") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMonsterObjects4[k] = gdjs.Main_32MenuCode.GDMonsterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMonsterObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMonsterObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").addObjectScaleTween3("Breath_Out", 1, "linear", 1, false, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].getBehavior("Tween").removeTween("Breath_In");
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4[i].getAnimationFrame() == 2 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4[k] = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4[i].getBehavior("Tween").addObjectScaleTween3("Slash", 1.2, "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Slash_Effect"), gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3[k] = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects5Objects = Hashtable.newFrom({"NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects4});
gdjs.Main_32MenuCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects5Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects5 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects5.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects5Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects4});
gdjs.Main_32MenuCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects5);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects5);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects5Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects5 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects5Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects5});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4Objects = Hashtable.newFrom({"NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects4});
gdjs.Main_32MenuCode.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects5);
gdjs.copyArray(gdjs.Main_32MenuCode.GDRenderObjects4, gdjs.Main_32MenuCode.GDRenderObjects5);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects5Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects5Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects5 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects5.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects5[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


{

/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
/* Reuse gdjs.Main_32MenuCode.GDRenderObjects4 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects4 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", true);
}
}}

}


};gdjs.Main_32MenuCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length = k;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList6(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects4 */
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4Objects, false, runtimeScene, false);
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(4), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}}

}


};gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects = Hashtable.newFrom({"TeleportBlade_Card": []});
gdjs.Main_32MenuCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects4);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects4[i].getBehavior("Text").setText("TeleportBlade");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(5)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects = Hashtable.newFrom({"Swap_Card": []});
gdjs.Main_32MenuCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) > 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects4[i].getBehavior("Text").setText("Swap");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(6)) <= 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


};gdjs.Main_32MenuCode.eventsList11 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Main_32MenuCode.GDMoveObjects3);
/* Reuse gdjs.Main_32MenuCode.GDMove_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMoveObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMoveObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Move"), gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move"), gdjs.Main_32MenuCode.GDMoveObjects3);
/* Reuse gdjs.Main_32MenuCode.GDMove_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMoveObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMoveObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects3);
/* Reuse gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Teleport"), gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport"), gdjs.Main_32MenuCode.GDTeleportObjects3);
/* Reuse gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getVariables().getFromIndex(0)) > 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects3);
/* Reuse gdjs.Main_32MenuCode.GDSword_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 150, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 210, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 255, "linear", 0.1, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getVariableNumber(gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Amount_Sword"), gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword"), gdjs.Main_32MenuCode.GDSwordObjects3);
/* Reuse gdjs.Main_32MenuCode.GDSword_9595CardObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Active", 0, "linear", 0.1, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDTeleportBlade_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfEmptyGDSwap_9595CardObjects) >= 1;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "184;233;134", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getBehavior("Tween").addObjectColorTween2("selected", "197;134;233", "linear", 0.1, false, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects2[i].getBehavior("Tween").addObjectColorTween2("selected", "255;255;255", "linear", 0.1, false, false);
}
}}

}


};gdjs.Main_32MenuCode.eventsList12 = function(runtimeScene) {

{


gdjs.Main_32MenuCode.eventsList1(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList2(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList4(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList8(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList11(runtimeScene);
}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects3, "NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects3, "NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects = Hashtable.newFrom({"Monster": gdjs.Main_32MenuCode.GDMonsterObjects3});
gdjs.Main_32MenuCode.asyncCallback17570068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Main_32MenuCode.eventsList13 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17570068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17478396 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Main_32MenuCode.eventsList14 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17478396(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17591172 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Main_32MenuCode.eventsList15 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17591172(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17590828 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Main_32MenuCode.eventsList16 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17590828(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17580308 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Main_32MenuCode.eventsList17 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17580308(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17588068 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Main_32MenuCode.eventsList18 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17588068(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17517908 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Main_32MenuCode.eventsList19 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17517908(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17555844 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Main_32MenuCode.eventsList20 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17555844(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17587268 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Main_32MenuCode.eventsList21 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17587268(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17589124 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Main_32MenuCode.eventsList22 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17589124(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList23 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList13(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList16(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList17(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList18(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList20(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList21(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects3, "NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects3, "NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595WinObjects3Objects = Hashtable.newFrom({"Good_Win": gdjs.Main_32MenuCode.GDGood_9595WinObjects3});
gdjs.Main_32MenuCode.asyncCallback17524412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Main_32MenuCode.eventsList24 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17524412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17531004 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Main_32MenuCode.eventsList25 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17531004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17547340 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Main_32MenuCode.eventsList26 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17547340(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17585228 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Main_32MenuCode.eventsList27 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17585228(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17569212 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Main_32MenuCode.eventsList28 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17569212(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17482412 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Main_32MenuCode.eventsList29 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17482412(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17653996 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Main_32MenuCode.eventsList30 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17653996(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17605492 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Main_32MenuCode.eventsList31 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17605492(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17582204 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Main_32MenuCode.eventsList32 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17582204(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17491628 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Main_32MenuCode.eventsList33 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17491628(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17548388 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Ending", false);
}}
gdjs.Main_32MenuCode.eventsList34 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17548388(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList35 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Start";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList24(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList25(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList26(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList27(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList28(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList29(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList30(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList31(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList32(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList33(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList36 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Good_Gate"), gdjs.Main_32MenuCode.GDGood_9595GateObjects3);
gdjs.copyArray(runtimeScene.getObjects("Good_Win"), gdjs.Main_32MenuCode.GDGood_9595WinObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDGood_9595GateObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDGood_9595GateObjects3[i].getBehavior("Opacity").getOpacity() > 200 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDGood_9595GateObjects3[k] = gdjs.Main_32MenuCode.GDGood_9595GateObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDGood_9595GateObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.distanceTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDGood_95959595WinObjects3Objects, 64, false);
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList35(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.asyncCallback17590284 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Tutorial", false);
}}
gdjs.Main_32MenuCode.eventsList37 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17590284(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17660820 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage1", false);
}}
gdjs.Main_32MenuCode.eventsList38 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17660820(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17594188 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage2", false);
}}
gdjs.Main_32MenuCode.eventsList39 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17594188(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17606556 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage3", false);
}}
gdjs.Main_32MenuCode.eventsList40 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17606556(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17614460 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage4", false);
}}
gdjs.Main_32MenuCode.eventsList41 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17614460(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17565716 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage5", false);
}}
gdjs.Main_32MenuCode.eventsList42 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17565716(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17474948 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage6", false);
}}
gdjs.Main_32MenuCode.eventsList43 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17474948(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17651364 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage7", false);
}}
gdjs.Main_32MenuCode.eventsList44 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17651364(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17544500 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage8", false);
}}
gdjs.Main_32MenuCode.eventsList45 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17544500(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17671588 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Stage9", false);
}}
gdjs.Main_32MenuCode.eventsList46 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17671588(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList47 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Tutorial";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList37(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage1";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList38(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage2";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList39(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage3";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList40(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage4";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList41(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage5";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList42(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage6";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList43(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage7";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList44(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2, gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage8";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList45(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "Stage9";
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList46(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList48 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList47(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList49 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects, 64, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMonsterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMonsterObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDMonsterObjects3[k] = gdjs.Main_32MenuCode.GDMonsterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMonsterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList23(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList36(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) != "Ending";
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList48(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects = Hashtable.newFrom({"Render": gdjs.Main_32MenuCode.GDRenderObjects3});
gdjs.Main_32MenuCode.eventsList50 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDRenderObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 140, "linear", 0.05, false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Show_Point", 0, "linear", 0.05, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{gdjs.Main_32MenuCode.GDCharacterObjects3_1final.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3, gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3, gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3, gdjs.Main_32MenuCode.GDNPC_95952Objects4);

for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects4[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects4[k] = gdjs.Main_32MenuCode.GDCharacterObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getVariables().get("Bomb_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects4[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDCharacterObjects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDCharacterObjects3_1final.indexOf(gdjs.Main_32MenuCode.GDCharacterObjects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDCharacterObjects3_1final.push(gdjs.Main_32MenuCode.GDCharacterObjects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95951Objects4[j]);
    }
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.indexOf(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]) === -1 )
            gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final.push(gdjs.Main_32MenuCode.GDNPC_95952Objects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDCharacterObjects3_1final, gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95951Objects3_1final, gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(gdjs.Main_32MenuCode.GDNPC_95952Objects3_1final, gdjs.Main_32MenuCode.GDNPC_95952Objects3);
}
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.Main_32MenuCode.GDRight_9595ClickObjects3);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.Main_32MenuCode.GDUI_9595TextObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDUI_9595TextObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDUI_9595TextObjects3[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRight_9595ClickObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRight_9595ClickObjects3[i].hide(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Bomb_Card"), false) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Right_Click"), gdjs.Main_32MenuCode.GDRight_9595ClickObjects2);
gdjs.copyArray(runtimeScene.getObjects("UI_Text"), gdjs.Main_32MenuCode.GDUI_9595TextObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDUI_9595TextObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDUI_9595TextObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRight_9595ClickObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRight_9595ClickObjects2[i].hide();
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects4, "NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects4, "NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects4});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4Objects = Hashtable.newFrom({"Pad": gdjs.Main_32MenuCode.GDPadObjects4});
gdjs.Main_32MenuCode.eventsList51 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17473404);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(1).add(1);
}}

}


};gdjs.Main_32MenuCode.eventsList52 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Pad"), gdjs.Main_32MenuCode.GDPadObjects3);

for (gdjs.Main_32MenuCode.forEachIndex4 = 0;gdjs.Main_32MenuCode.forEachIndex4 < gdjs.Main_32MenuCode.GDPadObjects3.length;++gdjs.Main_32MenuCode.forEachIndex4) {
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);
gdjs.Main_32MenuCode.GDPadObjects4.length = 0;


gdjs.Main_32MenuCode.forEachTemporary4 = gdjs.Main_32MenuCode.GDPadObjects3[gdjs.Main_32MenuCode.forEachIndex4];
gdjs.Main_32MenuCode.GDPadObjects4.push(gdjs.Main_32MenuCode.forEachTemporary4);
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDPadObjects4.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDPadObjects4[i].getBehavior("Animation").getAnimationName() == "Inactive" ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDPadObjects4[k] = gdjs.Main_32MenuCode.GDPadObjects4[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDPadObjects4.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects4ObjectsGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects4Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDPadObjects4Objects, false, runtimeScene, false);
isConditionTrue_0 = isConditionTrue_1;
}
}
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.Main_32MenuCode.GDPadObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDPadObjects4[i].getBehavior("Animation").setAnimationName("Active");
}
}
{ //Subevents: 
gdjs.Main_32MenuCode.eventsList51(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


{



}


};gdjs.Main_32MenuCode.eventsList53 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(3.1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(3);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(9);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(6.5);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects2[i].getBehavior("Scale").setScale(12);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects3Objects = Hashtable.newFrom({"Move_Card": gdjs.Main_32MenuCode.GDMove_9595CardObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCurserObjects3Objects = Hashtable.newFrom({"Curser": gdjs.Main_32MenuCode.GDCurserObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2});
gdjs.Main_32MenuCode.eventsList54 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595CardObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17600004);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCurserObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17599684);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects3);
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Moveing.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.5, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDMove_9595CardObjects3[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17694652);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects2);
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects2[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects3Objects = Hashtable.newFrom({"Teleport_Card": gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSmokeObjects4Objects = Hashtable.newFrom({"Smoke": gdjs.Main_32MenuCode.GDSmokeObjects4});
gdjs.Main_32MenuCode.asyncCallback17620180 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4);
gdjs.Main_32MenuCode.GDSmokeObjects4.length = 0;

{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSmokeObjects4Objects, (( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].hide(false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].hide(false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].returnVariable(gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4[i].getVariables().getFromIndex(0)).sub(1);
}
}}
gdjs.Main_32MenuCode.eventsList55 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32MenuCode.GDCharacterObjects3) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.Main_32MenuCode.GDNPC_95951Objects3) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.Main_32MenuCode.GDNPC_95952Objects3) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17620180(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects3Objects = Hashtable.newFrom({"Swap_Card": gdjs.Main_32MenuCode.GDSwap_9595CardObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3Objects = Hashtable.newFrom({"NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects3});
gdjs.Main_32MenuCode.eventsList56 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17554812);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects3});
gdjs.Main_32MenuCode.eventsList57 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17619252);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects = Hashtable.newFrom({"NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects3});
gdjs.Main_32MenuCode.eventsList58 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17615948);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3Objects = Hashtable.newFrom({"NPC_1": gdjs.Main_32MenuCode.GDNPC_95951Objects3});
gdjs.Main_32MenuCode.eventsList59 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17484196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3Objects = Hashtable.newFrom({"Character": gdjs.Main_32MenuCode.GDCharacterObjects3});
gdjs.Main_32MenuCode.eventsList60 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17608228);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects = Hashtable.newFrom({"NPC_2": gdjs.Main_32MenuCode.GDNPC_95952Objects3});
gdjs.Main_32MenuCode.eventsList61 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17627196);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
{gdjs.evtTools.sound.playSound(runtimeScene, "Swap.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(3).add(1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Effect").enableEffect("Swap", true);
}
}{runtimeScene.getGame().getVariables().getFromIndex(6).sub(1);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2});
gdjs.Main_32MenuCode.eventsList62 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleport_95959595CardObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17653100);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17695108);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].hide();
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].hide();
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].hide();
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17613716);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17546188);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Swap_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Swap_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17476508);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList56(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17685636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList57(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17479260);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList58(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595951Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17474636);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList59(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDCharacterObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17633124);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList60(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(4), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDNPC_959595952Objects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17579292);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(4), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().getFromIndex(6), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSwap_9595CardObjects3[i].getVariables().get("Amount")).sub(1);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList61(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17609988);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Swap_Card"), gdjs.Main_32MenuCode.GDSwap_9595CardObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSwap_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSwap_9595CardObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects2[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects3Objects = Hashtable.newFrom({"Sword_Card": gdjs.Main_32MenuCode.GDSword_9595CardObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects = Hashtable.newFrom({"Monster": gdjs.Main_32MenuCode.GDMonsterObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSlash_95959595EffectObjects3Objects = Hashtable.newFrom({"Slash_Effect": gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3});
gdjs.Main_32MenuCode.asyncCallback17665004 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects4);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.Main_32MenuCode.eventsList63 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32MenuCode.GDMonsterObjects3) asyncObjectsList.addObject("Monster", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17665004(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects3Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects = Hashtable.newFrom({"Monster": gdjs.Main_32MenuCode.GDMonsterObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSlash_95959595EffectObjects3Objects = Hashtable.newFrom({"Slash_Effect": gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3});
gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSmokeObjects4Objects = Hashtable.newFrom({"Smoke": gdjs.Main_32MenuCode.GDSmokeObjects4});
gdjs.Main_32MenuCode.asyncCallback17537804 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(asyncObjectsList.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects4);

gdjs.copyArray(asyncObjectsList.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects4);

gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects4);
gdjs.Main_32MenuCode.GDSmokeObjects4.length = 0;

{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4[0].getCenterYInScene()), "easeFromTo", 0.1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSmokeObjects4Objects, (( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getCenterXInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDNPC_95952Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDNPC_95951Objects4.length === 0 ) ? (( gdjs.Main_32MenuCode.GDCharacterObjects4.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDCharacterObjects4[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95951Objects4[0].getCenterYInScene()) :gdjs.Main_32MenuCode.GDNPC_95952Objects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects4[i].hide(false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects4[i].hide(false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects4[i].hide(false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Teleport.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects4[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects4.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects4[i].getBehavior("Scale").setScale(1);
}
}}
gdjs.Main_32MenuCode.eventsList64 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
for (const obj of gdjs.Main_32MenuCode.GDCharacterObjects3) asyncObjectsList.addObject("Character", obj);
for (const obj of gdjs.Main_32MenuCode.GDMonsterObjects3) asyncObjectsList.addObject("Monster", obj);
for (const obj of gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3) asyncObjectsList.addObject("Move_Trigger", obj);
for (const obj of gdjs.Main_32MenuCode.GDNPC_95951Objects3) asyncObjectsList.addObject("NPC_1", obj);
for (const obj of gdjs.Main_32MenuCode.GDNPC_95952Objects3) asyncObjectsList.addObject("NPC_2", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.5), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17537804(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects = Hashtable.newFrom({"Move_Trigger": gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2});
gdjs.Main_32MenuCode.eventsList65 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSword_95959595CardObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDSword_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17507548);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17665324);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDMonsterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length = 0;

{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].returnVariable(gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getVariables().getFromIndex(0)).sub(1);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSlash_95959595EffectObjects3Objects, (( gdjs.Main_32MenuCode.GDMonsterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMonsterObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMonsterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMonsterObjects3[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList63(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17466468);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects3);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects3);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects3[i].getBehavior("Scale").setScale(1);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);
gdjs.copyArray(runtimeScene.getObjects("TeleportBlade_Card"), gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[k] = gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17529924);
}
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Select.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Main_32MenuCode.GDMonsterObjects3);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects3);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, runtimeScene, true, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMonsterObjects3Objects, gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects3Objects, false, runtimeScene, false);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects3[k] = gdjs.Main_32MenuCode.GDCharacterObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects3[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i].isVisible() ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = k;
}
}
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17467148);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDMonsterObjects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects3 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects3 */
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length = 0;

{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].getVariables().get("TeleportBlade_Card"), false);
}
}{runtimeScene.getGame().getVariables().getFromIndex(5).sub(1);
}{gdjs.evtTools.sound.playSound(runtimeScene, "Sword.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMonsterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMonsterObjects3[i].getBehavior("Tween").addObjectOpacityTween2("Death", 0, "easeFromTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects3[i].hide();
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects3[i].hide();
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects3.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects3[i].hide();
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSlash_95959595EffectObjects3Objects, (( gdjs.Main_32MenuCode.GDMonsterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMonsterObjects3[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMonsterObjects3.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMonsterObjects3[0].getCenterYInScene()) + 12, "");
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList64(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDMove_95959595TriggerObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Right");
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i].getBehavior("Opacity").getOpacity() > 99 ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[k] = gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length = k;
}
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17624076);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Render"), gdjs.Main_32MenuCode.GDRenderObjects2);
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects2[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 2, 2, 2, 0.04, false, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Cancel.mp3", false, 50, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDRenderObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDRenderObjects2[i].getBehavior("Scale").setScale(1);
}
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects2Objects = Hashtable.newFrom({"TeleportBlade_Card": gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects2});
gdjs.Main_32MenuCode.eventsList66 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(10633164);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
gdjs.copyArray(runtimeScene.getObjects("Sword_Card"), gdjs.Main_32MenuCode.GDSword_9595CardObjects2);
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2);
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDTeleportBlade_95959595CardObjects2Objects, (( gdjs.Main_32MenuCode.GDSword_9595CardObjects2.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects2[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDSword_9595CardObjects2.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDSword_9595CardObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Sword_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDSword_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDSword_9595CardObjects2[i].returnVariable(gdjs.Main_32MenuCode.GDSword_9595CardObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2[i].returnVariable(gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects1Objects = Hashtable.newFrom({"Swap_Card": gdjs.Main_32MenuCode.GDSwap_9595CardObjects1});
gdjs.Main_32MenuCode.eventsList67 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(17497196);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Move_Card"), gdjs.Main_32MenuCode.GDMove_9595CardObjects1);
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects1 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects1 */
gdjs.copyArray(runtimeScene.getObjects("Teleport_Card"), gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1);
gdjs.Main_32MenuCode.GDSwap_9595CardObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Main_32MenuCode.mapOfGDgdjs_9546Main_959532MenuCode_9546GDSwap_95959595CardObjects1Objects, (( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Teleport_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1[i].returnVariable(gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDMove_9595CardObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDMove_9595CardObjects1[i].returnVariable(gdjs.Main_32MenuCode.GDMove_9595CardObjects1[i].getVariables().getFromIndex(0)).sub(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Upgrad.mp3", false, 50, 0.85);
}}

}


};gdjs.Main_32MenuCode.eventsList68 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Sword_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Sword_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Move_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Move_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Swap_Card"), false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Sword_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects2[k] = gdjs.Main_32MenuCode.GDCharacterObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects2[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects2 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects2 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects2[i].getVariables().get("TeleportBlade_Card"), false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList66(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects1[k] = gdjs.Main_32MenuCode.GDCharacterObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Move_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects1[k] = gdjs.Main_32MenuCode.GDCharacterObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Teleport_Card"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects1.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDCharacterObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDCharacterObjects1[k] = gdjs.Main_32MenuCode.GDCharacterObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDCharacterObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95951Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95951Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95951Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Active"), true) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDNPC_95952Objects1[k] = gdjs.Main_32MenuCode.GDNPC_95952Objects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDNPC_95952Objects1.length = k;
}
}
isConditionTrue_0 = isConditionTrue_1;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDCharacterObjects1 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95951Objects1 */
/* Reuse gdjs.Main_32MenuCode.GDNPC_95952Objects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDCharacterObjects1[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getVariables().get("Swap_Card"), false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].setVariableBoolean(gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getVariables().get("Swap_Card"), false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList69 = function(runtimeScene) {

{


gdjs.Main_32MenuCode.eventsList52(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList53(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList54(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList62(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList65(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList68(runtimeScene);
}


};gdjs.Main_32MenuCode.eventsList70 = function(runtimeScene) {

{


gdjs.Main_32MenuCode.eventsList49(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList50(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList69(runtimeScene);
}


};gdjs.Main_32MenuCode.eventsList71 = function(runtimeScene) {

{


gdjs.Main_32MenuCode.eventsList12(runtimeScene);
}


{


gdjs.Main_32MenuCode.eventsList70(runtimeScene);
}


};gdjs.Main_32MenuCode.asyncCallback17114732 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("Game_Logo"), gdjs.Main_32MenuCode.GDGame_9595LogoObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDGame_9595LogoObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDGame_9595LogoObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.5, false);
}
}}
gdjs.Main_32MenuCode.eventsList72 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17114732(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.asyncCallback17469924 = function (runtimeScene, asyncObjectsList) {
gdjs.copyArray(runtimeScene.getObjects("About_Text"), gdjs.Main_32MenuCode.GDAbout_9595TextObjects2);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDAbout_9595TextObjects2.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAbout_9595TextObjects2[i].getBehavior("Tween").addObjectOpacityTween2("Start", 255, "linear", 0.5, false);
}
}}
gdjs.Main_32MenuCode.eventsList73 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(0.2), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback17469924(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList74 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDAboutObjects1 */
/* Reuse gdjs.Main_32MenuCode.GDExitObjects1 */
/* Reuse gdjs.Main_32MenuCode.GDStartObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDStartObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").isPlaying("Fade") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDStartObjects1[k] = gdjs.Main_32MenuCode.GDStartObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDStartObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").isPlaying("Fade") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAboutObjects1[k] = gdjs.Main_32MenuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAboutObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").isPlaying("Fade") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDExitObjects1[k] = gdjs.Main_32MenuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDExitObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32MenuCode.GDBackObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBackObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList73(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList75 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDAboutObjects1 */
/* Reuse gdjs.Main_32MenuCode.GDExitObjects1 */
/* Reuse gdjs.Main_32MenuCode.GDStartObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDStartObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").isPlaying("Brighten") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDStartObjects1[k] = gdjs.Main_32MenuCode.GDStartObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDStartObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").isPlaying("Brighten") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAboutObjects1[k] = gdjs.Main_32MenuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAboutObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").isPlaying("Brighten") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDExitObjects1[k] = gdjs.Main_32MenuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDExitObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About_Text"), gdjs.Main_32MenuCode.GDAbout_9595TextObjects1);
/* Reuse gdjs.Main_32MenuCode.GDBackObjects1 */
{for(var i = 0, len = gdjs.Main_32MenuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBackObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.5, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAbout_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAbout_9595TextObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.5, false);
}
}}

}


};gdjs.Main_32MenuCode.asyncCallback16837140 = function (runtimeScene, asyncObjectsList) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}
gdjs.Main_32MenuCode.eventsList76 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.Main_32MenuCode.asyncCallback16837140(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.Main_32MenuCode.eventsList77 = function(runtimeScene) {

{

/* Reuse gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1[i].getBehavior("Tween").isPlaying("Fade_Out") ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1[k] = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Main_32MenuCode.eventsList76(runtimeScene);} //End of subevents
}

}


};gdjs.Main_32MenuCode.eventsList78 = function(runtimeScene) {

{



}


{


gdjs.Main_32MenuCode.eventsList71(runtimeScene);
}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About_Text"), gdjs.Main_32MenuCode.GDAbout_9595TextObjects1);
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32MenuCode.GDBackObjects1);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Curser"), gdjs.Main_32MenuCode.GDCurserObjects1);
{gdjs.evtTools.window.setWindowSize(runtimeScene, 1280, 720, false);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCurserObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCurserObjects1[i].getBehavior("Scale").setScale(0.5);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "", 0);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("Start");
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects1[i].getBehavior("Effect").enableEffect("Swap", false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDBackObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDBackObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAbout_9595TextObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAbout_9595TextObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.1, false);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16069428);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Fade_In", 0, "linear", 2, false);
}
}}

}


{



}


{



}


{

gdjs.Main_32MenuCode.GDAboutObjects1.length = 0;

gdjs.Main_32MenuCode.GDBackObjects1.length = 0;

gdjs.Main_32MenuCode.GDExitObjects1.length = 0;

gdjs.Main_32MenuCode.GDStartObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.Main_32MenuCode.GDAboutObjects1_1final.length = 0;
gdjs.Main_32MenuCode.GDBackObjects1_1final.length = 0;
gdjs.Main_32MenuCode.GDExitObjects1_1final.length = 0;
gdjs.Main_32MenuCode.GDStartObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32MenuCode.GDStartObjects2);
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDStartObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDStartObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDStartObjects2[k] = gdjs.Main_32MenuCode.GDStartObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDStartObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDStartObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDStartObjects1_1final.indexOf(gdjs.Main_32MenuCode.GDStartObjects2[j]) === -1 )
            gdjs.Main_32MenuCode.GDStartObjects1_1final.push(gdjs.Main_32MenuCode.GDStartObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32MenuCode.GDAboutObjects2);
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAboutObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAboutObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDAboutObjects2[k] = gdjs.Main_32MenuCode.GDAboutObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAboutObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDAboutObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDAboutObjects1_1final.indexOf(gdjs.Main_32MenuCode.GDAboutObjects2[j]) === -1 )
            gdjs.Main_32MenuCode.GDAboutObjects1_1final.push(gdjs.Main_32MenuCode.GDAboutObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32MenuCode.GDBackObjects2);
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDBackObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDBackObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDBackObjects2[k] = gdjs.Main_32MenuCode.GDBackObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDBackObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDBackObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDBackObjects1_1final.indexOf(gdjs.Main_32MenuCode.GDBackObjects2[j]) === -1 )
            gdjs.Main_32MenuCode.GDBackObjects1_1final.push(gdjs.Main_32MenuCode.GDBackObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32MenuCode.GDExitObjects2);
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDExitObjects2.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDExitObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_1 = true;
        gdjs.Main_32MenuCode.GDExitObjects2[k] = gdjs.Main_32MenuCode.GDExitObjects2[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDExitObjects2.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.Main_32MenuCode.GDExitObjects2.length; j < jLen ; ++j) {
        if ( gdjs.Main_32MenuCode.GDExitObjects1_1final.indexOf(gdjs.Main_32MenuCode.GDExitObjects2[j]) === -1 )
            gdjs.Main_32MenuCode.GDExitObjects1_1final.push(gdjs.Main_32MenuCode.GDExitObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Main_32MenuCode.GDAboutObjects1_1final, gdjs.Main_32MenuCode.GDAboutObjects1);
gdjs.copyArray(gdjs.Main_32MenuCode.GDBackObjects1_1final, gdjs.Main_32MenuCode.GDBackObjects1);
gdjs.copyArray(gdjs.Main_32MenuCode.GDExitObjects1_1final, gdjs.Main_32MenuCode.GDExitObjects1);
gdjs.copyArray(gdjs.Main_32MenuCode.GDStartObjects1_1final, gdjs.Main_32MenuCode.GDStartObjects1);
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16851540);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Click.mp3", false, 50, 1);
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32MenuCode.GDStartObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDStartObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDStartObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDStartObjects1[k] = gdjs.Main_32MenuCode.GDStartObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDStartObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDStartObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDStartObjects1[k] = gdjs.Main_32MenuCode.GDStartObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDStartObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32MenuCode.GDAboutObjects1);
gdjs.copyArray(runtimeScene.getObjects("Character"), gdjs.Main_32MenuCode.GDCharacterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32MenuCode.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Move_Trigger"), gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1);
gdjs.copyArray(runtimeScene.getObjects("NPC_1"), gdjs.Main_32MenuCode.GDNPC_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("NPC_2"), gdjs.Main_32MenuCode.GDNPC_95952Objects1);
/* Reuse gdjs.Main_32MenuCode.GDStartObjects1 */
{gdjs.evtTools.sound.fadeSoundVolume(runtimeScene, 1, 0, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.1, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Start", 0, "linear", 0.1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDCharacterObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDCharacterObjects1[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterYInScene()), "easeFromTo", 0.8, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95951Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95951Objects1[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterYInScene()), "easeFromTo", 0.8, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDNPC_95952Objects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDNPC_95952Objects1[i].getBehavior("Tween").addObjectPositionTween2("Walk", (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterXInScene()), (( gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length === 0 ) ? 0 :gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1[0].getCenterYInScene()), "easeFromTo", 0.8, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList72(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32MenuCode.GDAboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAboutObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAboutObjects1[k] = gdjs.Main_32MenuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAboutObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDAboutObjects1[k] = gdjs.Main_32MenuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDAboutObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.Main_32MenuCode.GDAboutObjects1 */
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32MenuCode.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32MenuCode.GDStartObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDStartObjects1[i].getX()) - 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDAboutObjects1[i].getX()) - 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDExitObjects1[i].getX()) - 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Fade", 0, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Fade", 0, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Fade", 0, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList74(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.Main_32MenuCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDBackObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDBackObjects1[k] = gdjs.Main_32MenuCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDBackObjects1[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDBackObjects1[k] = gdjs.Main_32MenuCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDBackObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.Main_32MenuCode.GDAboutObjects1);
gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32MenuCode.GDExitObjects1);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Main_32MenuCode.GDStartObjects1);
{for(var i = 0, len = gdjs.Main_32MenuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDStartObjects1[i].getX()) + 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDAboutObjects1[i].getX()) + 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").addObjectPositionXTween2("Walk", (gdjs.Main_32MenuCode.GDExitObjects1[i].getX()) + 224, "swingTo", 1, false);
}
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDStartObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDStartObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Brighten", 255, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDAboutObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDAboutObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Brighten", 255, "linear", 0.5, false);
}
for(var i = 0, len = gdjs.Main_32MenuCode.GDExitObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Brighten", 255, "linear", 0.5, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList75(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Exit"), gdjs.Main_32MenuCode.GDExitObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDExitObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDExitObjects1[k] = gdjs.Main_32MenuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDExitObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Main_32MenuCode.GDExitObjects1.length;i<l;++i) {
    if ( gdjs.Main_32MenuCode.GDExitObjects1[i].getBehavior("Opacity").getOpacity() > 100 ) {
        isConditionTrue_0 = true;
        gdjs.Main_32MenuCode.GDExitObjects1[k] = gdjs.Main_32MenuCode.GDExitObjects1[i];
        ++k;
    }
}
gdjs.Main_32MenuCode.GDExitObjects1.length = k;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Fade_Screen"), gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1);
{gdjs.evtTools.sound.fadeSoundVolume(runtimeScene, 1, 0, 1);
}{for(var i = 0, len = gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1.length ;i < len;++i) {
    gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1[i].getBehavior("Tween").addObjectOpacityTween2("Fade_Out", 255, "linear", 1, false);
}
}
{ //Subevents
gdjs.Main_32MenuCode.eventsList77(runtimeScene);} //End of subevents
}

}


};

gdjs.Main_32MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Main_32MenuCode.GDGame_9595LogoObjects1.length = 0;
gdjs.Main_32MenuCode.GDGame_9595LogoObjects2.length = 0;
gdjs.Main_32MenuCode.GDGame_9595LogoObjects3.length = 0;
gdjs.Main_32MenuCode.GDGame_9595LogoObjects4.length = 0;
gdjs.Main_32MenuCode.GDGame_9595LogoObjects5.length = 0;
gdjs.Main_32MenuCode.GDGame_9595LogoObjects6.length = 0;
gdjs.Main_32MenuCode.GDStartObjects1.length = 0;
gdjs.Main_32MenuCode.GDStartObjects2.length = 0;
gdjs.Main_32MenuCode.GDStartObjects3.length = 0;
gdjs.Main_32MenuCode.GDStartObjects4.length = 0;
gdjs.Main_32MenuCode.GDStartObjects5.length = 0;
gdjs.Main_32MenuCode.GDStartObjects6.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects1.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects2.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects3.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects4.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects5.length = 0;
gdjs.Main_32MenuCode.GDAboutObjects6.length = 0;
gdjs.Main_32MenuCode.GDExitObjects1.length = 0;
gdjs.Main_32MenuCode.GDExitObjects2.length = 0;
gdjs.Main_32MenuCode.GDExitObjects3.length = 0;
gdjs.Main_32MenuCode.GDExitObjects4.length = 0;
gdjs.Main_32MenuCode.GDExitObjects5.length = 0;
gdjs.Main_32MenuCode.GDExitObjects6.length = 0;
gdjs.Main_32MenuCode.GDBackObjects1.length = 0;
gdjs.Main_32MenuCode.GDBackObjects2.length = 0;
gdjs.Main_32MenuCode.GDBackObjects3.length = 0;
gdjs.Main_32MenuCode.GDBackObjects4.length = 0;
gdjs.Main_32MenuCode.GDBackObjects5.length = 0;
gdjs.Main_32MenuCode.GDBackObjects6.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects3.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects4.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects5.length = 0;
gdjs.Main_32MenuCode.GDAbout_9595TextObjects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959501Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959502Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959503Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959504Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959505Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959506Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959507Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959508Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959509Objects6.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects1.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects2.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects3.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects4.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects5.length = 0;
gdjs.Main_32MenuCode.GDGood_9595WinObjects6.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects1.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects2.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects3.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects4.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects5.length = 0;
gdjs.Main_32MenuCode.GDVoidObjects6.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects1.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects2.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects3.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects4.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects5.length = 0;
gdjs.Main_32MenuCode.GDGood_9595GateObjects6.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects1.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects2.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects3.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects4.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects5.length = 0;
gdjs.Main_32MenuCode.GDMove_9595TriggerObjects6.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects1.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects2.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects3.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects4.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects5.length = 0;
gdjs.Main_32MenuCode.GDCharacterObjects6.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDMove_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects1.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects2.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects3.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects4.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects5.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595MoveObjects6.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects1.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects2.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects3.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects4.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects5.length = 0;
gdjs.Main_32MenuCode.GDMoveObjects6.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDSword_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects1.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects2.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects3.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects4.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects5.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595SwordObjects6.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects1.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects2.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects3.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects4.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects5.length = 0;
gdjs.Main_32MenuCode.GDSwordObjects6.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDTeleport_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects1.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects2.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects3.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects4.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects5.length = 0;
gdjs.Main_32MenuCode.GDAmount_9595TeleportObjects6.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects1.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects2.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects3.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects4.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects5.length = 0;
gdjs.Main_32MenuCode.GDTeleportObjects6.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects1.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects2.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects3.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects4.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects5.length = 0;
gdjs.Main_32MenuCode.GDCurserObjects6.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects1.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects2.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects3.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects4.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects5.length = 0;
gdjs.Main_32MenuCode.GDFade_9595ScreenObjects6.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects1.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects2.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects3.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects4.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects5.length = 0;
gdjs.Main_32MenuCode.GDSlash_9595EffectObjects6.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects1.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects2.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects3.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects4.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects5.length = 0;
gdjs.Main_32MenuCode.GDBackgroundObjects6.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects1.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects2.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects3.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects4.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects5.length = 0;
gdjs.Main_32MenuCode.GDMonsterObjects6.length = 0;
gdjs.Main_32MenuCode.GDPadObjects1.length = 0;
gdjs.Main_32MenuCode.GDPadObjects2.length = 0;
gdjs.Main_32MenuCode.GDPadObjects3.length = 0;
gdjs.Main_32MenuCode.GDPadObjects4.length = 0;
gdjs.Main_32MenuCode.GDPadObjects5.length = 0;
gdjs.Main_32MenuCode.GDPadObjects6.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects1.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects2.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects3.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects4.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects5.length = 0;
gdjs.Main_32MenuCode.GDUI_9595TextObjects6.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects1.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects2.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects3.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects4.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects5.length = 0;
gdjs.Main_32MenuCode.GDDebugObjects6.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDTeleportBlade_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects1.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects2.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects3.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects4.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects5.length = 0;
gdjs.Main_32MenuCode.GDRenderObjects6.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects1.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects2.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects3.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects4.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects5.length = 0;
gdjs.Main_32MenuCode.GDReset_9595buttonObjects6.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects1.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects2.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects3.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects4.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects5.length = 0;
gdjs.Main_32MenuCode.GDUI_9595Text_95952Objects6.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects1.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects2.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects3.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects4.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects5.length = 0;
gdjs.Main_32MenuCode.GDRight_9595ClickObjects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959510Objects6.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects1.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects2.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects3.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects4.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects5.length = 0;
gdjs.Main_32MenuCode.GDGround_959511Objects6.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDSwap_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects1.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects2.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects3.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects4.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects5.length = 0;
gdjs.Main_32MenuCode.GDBomb_9595CardObjects6.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects1.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects2.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects3.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects4.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects5.length = 0;
gdjs.Main_32MenuCode.GDNPC_95951Objects6.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects1.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects2.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects3.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects4.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects5.length = 0;
gdjs.Main_32MenuCode.GDBad_9595WinObjects6.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects1.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects2.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects3.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects4.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects5.length = 0;
gdjs.Main_32MenuCode.GDBad_9595GateObjects6.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects1.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects2.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects3.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects4.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects5.length = 0;
gdjs.Main_32MenuCode.GDWeight_9595PadObjects6.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects1.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects2.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects3.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects4.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects5.length = 0;
gdjs.Main_32MenuCode.GDNPC_95952Objects6.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects1.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects2.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects3.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects4.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects5.length = 0;
gdjs.Main_32MenuCode.GDCard_9595UIObjects6.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects1.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects2.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects3.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects4.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects5.length = 0;
gdjs.Main_32MenuCode.GDSmokeObjects6.length = 0;

gdjs.Main_32MenuCode.eventsList78(runtimeScene);

return;

}

gdjs['Main_32MenuCode'] = gdjs.Main_32MenuCode;
